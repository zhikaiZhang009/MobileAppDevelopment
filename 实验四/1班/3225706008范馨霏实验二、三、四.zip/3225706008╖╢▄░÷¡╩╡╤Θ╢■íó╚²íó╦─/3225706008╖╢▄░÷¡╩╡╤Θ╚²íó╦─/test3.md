# 实验三、四报告

> 学号：3225706008
> 
> 姓名：范馨霏
> 
> 指导老师：张凯斌
> 
> 实验日期：<2025-03-23>

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；
  - 注意：UML图只是OOAD中的一部分（代码相关的部分），并不是OOAD的全部。例如：
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习；

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；
  

## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图

![alt text](用例图.png)

#### 1.2 用例规约

<在此处填写你的用例规约>

用例规约格式示例：   

| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 增加账户信息 | 
| 执行者 | 用户 | 
| 前置条件 | 用户已登录系统 | 
| 触发事件 | 用户点击“增加”按钮 | 
| 主成功场景 | 用户输入账户信息，系统保存信息 | 
| 扩展场景 | 输入信息不完整，系统提示错误 | 
| 最小保证 | 系统记录操作日志| 
| 后置条件 | 账户信息成功保存 | 
| 优先级 | 高 | 
| 频度 | 每周 | 
| 输入 | 账户类型、账户文本、金额 | 
| 输出 | 保存成功/失败消息 | 
| 异常 | 系统错误 | 
| 附加信息 | 无 | 

| 字段 | 内容 |
| ---- | ---- |
| 用例名	| 查询账户信息 |
| 执行者	| 用户 |
| 前置条件	| 用户已登录系统 |
| 触发事件	| 用户点击“查询”按钮 |
| 主成功场景	| 用户输入查询条件，系统显示匹配的账户信息 |
| 扩展场景	| 查询条件不匹配，系统提示无结果 |
| 最小保证	| 系统记录操作日志 |
| 后置条件	| 显示查询结果 |
| 优先级	| 中 |
| 频度	| 每周 |
| 输入	| 查询条件 |
| 输出	| 查询结果列表 |
| 异常	| 系统错误 |
| 附加信息	| 支持模糊查询 |

| 字段 | 内容 |
| ---- | ---- |
| 用例名	| 修改账户信息 |
| 执行者	| 用户 |
| 前置条件	| 用户已登录系统，且已查询到需要修改的账户信息 |
| 触发事件	| 用户点击“修改”按钮 |
| 主成功场景	| 用户修改账户信息，系统保存更新 |
| 扩展场景	| 修改信息不完整，系统提示错误 |
| 最小保证	| 系统记录操作日志 |
| 后置条件	| 账户信息成功更新 |
| 优先级	| 中 |
| 频度	| 每周 |
| 输入	| 修改后的账户信息 |
| 输出	| 更新成功/失败消息 |
| 异常	| 系统错误 |
| 附加信息	| 无 |

| 字段 | 内容 |
| ---- | ---- |
| 用例名	| 删除账户信息 |
| 执行者	| 用户 |
| 前置条件	| 用户已登录系统，且已查询到需要删除的账户信息 |
| 触发事件	| 用户点击“删除”按钮 |
| 主成功场景	| 系统删除账户信息 |
| 扩展场景	| 删除失败，系统提示错误 |
| 最小保证	| 系统记录操作日志 |
| 后置条件	| 账户信息成功删除 |
| 优先级	| 低 |
| 频度	| 每周 |
| 输入	| 账户ID |
| 输出	| 删除成功/失败消息 |
| 异常	| 系统错误 |
| 附加信息	| 无 |

### 2. 总体设计

#### 2.1 类图（静态视图）

![alt text](类图.png)

#### 2.2 活动图（动态视图）

![alt text](活动图.png)

### 3. 详细设计

#### 3.1 详细类图

![alt text](详细类图.png)

#### 3.2 包图

![alt text](包图.png)

### 4. 编码（实验四的内容）

#### 4.1 代码实现


RdbUtil.ets页面代码
```typescript {.line-numbers}
// 导入rdb模块，用于操作关系型数据库。
import data_rdb from '@ohos.data.rdb';
import relationalStore from '@ohos.data.relationalStore';
// 导入context模块，用于获取应用上下文。
import context from '@ohos.app.ability.common';

// 定义数据库存储配置接口
interface StoreConfig {
  name: string; // 数据库文件名
}

// 定义RdbStore接口，声明数据库操作方法
interface RdbStore {
  insert(tableName: string, valueBucket: data_rdb.ValuesBucket, callback: (err: Error | null, ret: void) => void): void;
  query(predicates: data_rdb.RdbPredicates, columns: Array<string>, callback: (err: Error | null, resultSet: data_rdb.ResultSet) => void): void;
  update(valueBucket: data_rdb.ValuesBucket, predicates: data_rdb.RdbPredicates, callback: (err: Error | null, ret: void) => void): void;
  delete(predicates: data_rdb.RdbPredicates, callback: (err: Error | null, ret: void) => void): void;
  executeSql(sql: string): void;
}

// 数据库配置
const STORE_CONFIG: StoreConfig = { name: "rdbstore.db" };

export default class RdbUtil {
  private rdbStore: data_rdb.RdbStore | null = null; // RDB存储实例
  private tableName: string; // 表名
  private sqlCreateTable: string; // 创建表的SQL语句
  private columns: Array<string>; // 表列名数组

  /**
   * 构造函数，初始化RdbUtil实例
   * @param tableName 数据库表名
   * @param sqlCreateTable 创建表的SQL语句
   * @param columns 表列名数组
   */
  constructor(tableName: string, sqlCreateTable: string, columns: Array<string>) {
    this.tableName = tableName;
    this.sqlCreateTable = sqlCreateTable;
    this.columns = columns;
  }

  /**
   * 获取RdbStore实例
   * @param callback 回调函数，用于在获取RdbStore后执行操作
   */
  getRdbStore(callback: () => void) {
    // 如果已经获取到RdbStore则不做操作
    if (this.rdbStore != null) {
      console.info('The rdbStore exists.');
      callback();
      return;
    }

    // 应用上下文，本例子是使用API9 Stage模型的Context
    let context: context.Context = getContext(this) as context.Context;
    data_rdb.getRdbStore(context, STORE_CONFIG, 1, (err, rdb) => {
      if (err) {
        console.error('getRdbStore() failed, err: ' + err);
        return;
      }
      this.rdbStore = rdb;

      // 获取到RdbStore后，需使用executeSql接口初始化数据库表结构和相关数据
      this.rdbStore.executeSql(this.sqlCreateTable);
      console.info('getRdbStore() finished.');
      callback();
    });
  }

  /**
   * 插入数据到数据库
   * @param data 要插入的数据
   * @param callback 回调函数，用于处理插入结果
   */
  insertData(data: data_rdb.ValuesBucket, callback: (resFlag: boolean) => void) {
    if (!this.rdbStore) {
      console.error('RdbStore is not initialized.');
      return;
    }

    this.rdbStore.insert(this.tableName, data, (err, ret) => {
      if (err) {
        console.error(`Failed to insert data. Code:${err.code}, message:${err.message}`);
        callback(false);
        return;
      }
      callback(true);
    });
  }

  /**
   * 从数据库中删除数据
   * @param predicates 删除条件
   * @param callback 回调函数，用于处理删除结果
   */
  deleteData(predicates: data_rdb.RdbPredicates, callback: (resFlag: boolean) => void) {
    if (!this.rdbStore) {
      console.error('RdbStore is not initialized.');
      return;
    }

    this.rdbStore.delete(predicates, (err, ret) => {
      if (err) {
        console.error(`Failed to delete data. Code:${err.code}, message:${err.message}`);
        callback(false);
        return;
      }
      callback(true);
    });
  }

  /**
   * 更新数据库中的数据
   * @param predicates 更新条件
   * @param data 要更新的数据
   * @param callback 回调函数，用于处理更新结果
   */
  updateData(predicates: data_rdb.RdbPredicates, data: data_rdb.ValuesBucket, callback: (resFlag: boolean) => void) {
    if (!this.rdbStore) {
      console.error('RdbStore is not initialized.');
      return;
    }

    this.rdbStore.update(data, predicates, (err, ret) => {
      if (err) {
        console.error(`Failed to update data. Code:${err.code}, message:${err.message}`);
        callback(false);
        return;
      }
      callback(true);
    });
  }

  /**
   * 从数据库中查询数据
   * @param predicates 查询条件
   * @param callback 回调函数，用于处理查询结果
   */
  query(predicates: data_rdb.RdbPredicates, callback: (resultSet: data_rdb.ResultSet) => void) {
    if (!this.rdbStore) {
      console.error('RdbStore is not initialized.');
      return;
    }

    this.rdbStore.query(predicates, this.columns, (err, resultSet) => {
      if (err) {
        console.error(`Failed to query data. Code:${err.code}, message:${err.message}`);
        return;
      }
      callback(resultSet);
      resultSet.close(); // 关闭结果集
    });
  }

  /**
   * 添加示例数据到数据库
   */
  public addData() {
    let u8 = new Uint8Array([1, 2, 3]); // 示例二进制数据

    // 定义要插入的数据
    const valueBucket: data_rdb.ValuesBucket = {
      "name": "Tom",
      "age": 18,
      "salary": 100.5,
      "blobType": u8
    };

    if (this.rdbStore) {
      this.rdbStore.insert("test", valueBucket);
    }
  }

  /**
   * 查询数据库中的数据
   */
  public queryData() {
    let predicates = new data_rdb.RdbPredicates("test");
    predicates.equalTo("name", "Tom"); // 设置查询条件：name等于"Tom"

    if (this.rdbStore) {
      this.rdbStore.query(predicates).then((resultSet) => {
        resultSet.goToFirstRow(); // 移动到第一条结果
        const id = resultSet.getLong(resultSet.getColumnIndex("id")); // 获取id列的值
        const name = resultSet.getString(resultSet.getColumnIndex("name")); // 获取name列的值
        const age = resultSet.getLong(resultSet.getColumnIndex("age")); // 获取age列的值
        const salary = resultSet.getDouble(resultSet.getColumnIndex("salary")); // 获取salary列的值
        const blobType = resultSet.getBlob(resultSet.getColumnIndex("blobType")); // 获取blobType列的值
        resultSet.close(); // 关闭结果集
      });
    }
  }

  /**
   * 初始化数据库存储
   */
  public initStore() {
    // 定义创建表的SQL语句
    const CREATE_TABLE_TEST =
      "CREATE TABLE IF NOT EXISTS test (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
        "name TEXT NOT NULL, " +
        "age INTEGER, " +
        "salary REAL, " +
        "blobType BLOB)";

    let context: context.Context = getContext(this) as context.Context;

    // 获取RdbStore实例
    data_rdb.getRdbStore(context, STORE_CONFIG, 1, (err, rdbStore) => {
      if (err) {
        console.error('getRdbStore() failed, err: ' + err);
        return;
      }
      this.rdbStore = rdbStore;

      // 执行创建表的SQL语句
      this.rdbStore.executeSql(CREATE_TABLE_TEST);
      console.info('create table done.');
    });
  }
}
```
AccountTable.ets页面代码
```typescript {.line-numbers}
// 导入关系型数据库模块
import data_rdb from '@ohos.data.rdb';
// 导入自定义的RdbUtil工具类
import RdbUtil from '../common/RdbUtil';
// 导入AccountData接口，定义账户数据结构
import { AccountData } from '../database/AccountData';

// 显式定义字段类型，移除索引签名
interface AccountDataFields {
  accountType: number; // 账户类型
  typeText: string; // 类型文本
  amount: number; // 金额
}

// 定义表结构接口
interface GeneratedObjectLiteralInterface_1 {
  tableName: string; // 表名
  sqlCreate: string; // 创建表的SQL语句
  columns: string[]; // 表列名数组
}

// 定义账户表的结构
const ACCOUNT_TABLE: GeneratedObjectLiteralInterface_1 = {
  tableName: 'accountTable', // 表名
  sqlCreate: 'CREATE TABLE IF NOT EXISTS accountTable(' +
    'id INTEGER PRIMARY KEY AUTOINCREMENT, accountType INTEGER, ' +
    'typeText TEXT, amount INTEGER)', // 创建表的SQL语句
  columns: ['id', 'accountType', 'typeText', 'amount'] // 表列名数组
};

// 定义回调函数类型
type RdbCallback = () => void;
// 定义查询回调函数类型
type QueryCallback = (result: AccountData[]) => void;

// 定义表列名常量
const COLUMN_ID = 'id';
const COLUMN_ACCOUNT_TYPE = 'accountType';
const COLUMN_TYPE_TEXT = 'typeText';
const COLUMN_AMOUNT = 'amount';

// 定义AccountTable类，封装账户表的操作
export default class AccountTable {
  private accountTable: RdbUtil; // RdbUtil实例

  /**
   * 构造函数，初始化AccountTable实例
   * @param callback 回调函数，用于在初始化完成后执行
   */
  constructor(callback: RdbCallback = () => {}) {
    // 初始化RdbUtil实例
    this.accountTable = new RdbUtil(
      ACCOUNT_TABLE.tableName, // 表名
      ACCOUNT_TABLE.sqlCreate, // 创建表的SQL语句
      [...ACCOUNT_TABLE.columns] // 表列名数组
    );
    // 获取RdbStore实例
    this.accountTable.getRdbStore(callback);
  }

  /**
   * 获取RdbStore实例
   * @param callback 回调函数，用于在获取RdbStore后执行
   */
  getRdbStore(callback: RdbCallback = () => {}) {
    this.accountTable.getRdbStore(callback);
  }

  /**
   * 插入账户数据到数据库
   * @param account 要插入的账户数据
   * @param callback 回调函数，用于处理插入结果
   */
  insertData(account: AccountData, callback: RdbCallback) {
    // 将AccountData对象转换为ValuesBucket
    const valueBucket = generateBucket(account);
    // 调用RdbUtil的insertData方法插入数据
    this.accountTable.insertData(valueBucket, callback);
  }

  /**
   * 从数据库中删除账户数据
   * @param account 要删除的账户数据
   * @param callback 回调函数，用于处理删除结果
   */
  deleteData(account: AccountData, callback: RdbCallback) {
    // 创建RdbPredicates对象，设置删除条件
    const predicates = new data_rdb.RdbPredicates(ACCOUNT_TABLE.tableName);
    predicates.equalTo('id', account.id); // 根据id删除
    // 调用RdbUtil的deleteData方法删除数据
    this.accountTable.deleteData(predicates, callback);
  }

  /**
   * 更新数据库中的账户数据
   * @param account 要更新的账户数据
   * @param callback 回调函数，用于处理更新结果
   */
  updateData(account: AccountData, callback: RdbCallback) {
    // 将AccountData对象转换为ValuesBucket
    const valueBucket = generateBucket(account);
    // 创建RdbPredicates对象，设置更新条件
    const predicates = new data_rdb.RdbPredicates(ACCOUNT_TABLE.tableName);
    predicates.equalTo('id', account.id); // 根据id更新
    // 调用RdbUtil的updateData方法更新数据
    this.accountTable.updateData(predicates, valueBucket, callback);
  }

  /**
   * 从数据库中查询账户数据
   * @param amount 查询条件：金额
   * @param callback 回调函数，用于处理查询结果
   * @param isAll 是否查询所有数据，默认为true
   */
  query(amount: number, callback: QueryCallback, isAll: boolean = true) {
    // 创建RdbPredicates对象，设置查询条件
    const predicates = new data_rdb.RdbPredicates(ACCOUNT_TABLE.tableName);
    if (!isAll) {
      predicates.equalTo('amount', amount); // 根据金额查询
    }
    // 调用RdbUtil的query方法查询数据
    this.accountTable.query(predicates, (resultSet) => {
      const count = resultSet.rowCount; // 获取结果集行数
      if (count === 0) {
        console.log('Query no results!'); // 没有查询结果
        callback([]); // 返回空数组
      } else {
        resultSet.goToFirstRow(); // 移动到第一条结果
        const result: AccountData[] = []; // 存储查询结果
        for (let i = 0; i < count; i++) {
          // 使用显式类型转换确保类型安全
          const tmp: AccountData = {
            id: resultSet.getLong(resultSet.getColumnIndex(COLUMN_ID)) as number,
            accountType: resultSet.getLong(resultSet.getColumnIndex(COLUMN_ACCOUNT_TYPE)) as number,
            typeText: resultSet.getString(resultSet.getColumnIndex(COLUMN_TYPE_TEXT)) as string,
            amount: resultSet.getLong(resultSet.getColumnIndex(COLUMN_AMOUNT)) as number
          };
          result.push(tmp); // 将结果添加到数组中
          resultSet.goToNextRow(); // 移动到下一条结果
        }
        callback(result); // 返回查询结果
      }
    });
  }
}

/**
 * 将AccountData对象转换为ValuesBucket
 * @param account 要转换的AccountData对象
 * @returns 转换后的ValuesBucket
 */
function generateBucket(account: AccountData): data_rdb.ValuesBucket {
  return {
    accountType: account.accountType,
    typeText: account.typeText,
    amount: account.amount
  } as data_rdb.ValuesBucket;
}
```
AccountData.ets页面
```typescript {.line-numbers}
//定义账户数据接口，用于描述账户表中的数据结构。
export interface AccountData {
  //账户的唯一标识符，主键，自动生成。
  id: number;

  //账户类型，用于区分不同类型的账户
  accountType: number;

  // 账户类型的文本描述，用于提供更友好的显示信息。
  typeText: string;

  //账户金额
  amount: number;
}
```
index.ets页面
```typescript {.line-numbers}
// Index.ets
// 导入AccountData接口
import { AccountData } from '../database/AccountData';

// 导入AccountTable类
import AccountTable from '../database/AccountTable';

// 导入页面路由模块
import { router } from '@kit.ArkUI';

// 导入业务错误处理模块（用于捕获路由错误）
import { BusinessError } from '@kit.BasicServicesKit';

// 定义账户数据类型接口
interface Account {
  id: number; // 账户ID
  name: string; // 账户名称
}

// @Entry 装饰器：标记本组件为页面入口
@Entry
// @Component 装饰器：声明本结构体为UI组件
@Component
struct Index {
  // @State 装饰器：声明响应式状态变量，用于动态更新UI
  @State message: AccountData[] = []; // 存储查询结果
  @State showReturnButton: boolean = false; // 控制返回按钮的显示状态
  private accountTable = new AccountTable(); // 创建AccountTable实例

  // 页面即将显示时调用
  aboutToAppear() {
    // 初始化数据库
    this.accountTable.getRdbStore(() => {
      // 查询所有账户数据
      this.accountTable.query(0, (result: AccountData[]) => {
        this.message = result; // 更新查询结果
      }, true);
    });
  }

  // 状态存储输入内容
  @State inputContent: string = '123'; // 输入框的默认值

  // 构建UI结构的方法
  build() {
    // 创建垂直布局容器
    Column() {
      // 创建水平布局容器
      Row() {
        // 显示时间组件
        TextClock()
          // 日期格式化
          .margin({ left: 30 })
          .fontSize(25)
          .format('yyyy/MM/dd HH:mm:ss');
      }
      // 固定高度或改用百分比
      .height('6%')
      // 可选背景色
      .backgroundColor('#FFFFFF')
      // 设置内容的对齐方式为起始对齐
      .justifyContent(FlexAlign.Start);
      // 分隔线组件
      Divider()
        // 设置分隔线的宽度为15
        .strokeWidth(15)
        // 设置分隔线的颜色
        .color(0X2788D9)
        // 设置分隔线的端点样式为圆角
        .lineCap(LineCapStyle.Round);
      // 按钮组容器
      Row() {
        // 四个按钮水平排列
        Column() {
          // 增加按钮
          Button('增加')
            .type(ButtonType.Capsule)
            .width(120)
            .fontSize(32)
            .onClick(() => {
              const newAccount: AccountData = {
                id: 0,
                accountType: 0,
                typeText: '苹果',
                amount: 0
              };
              this.accountTable.insertData(newAccount, () => {}); // 插入新账户数据
            });
          // 查询按钮
          Button('查询')
            .type(ButtonType.Capsule)
            .width(120)
            .fontSize(32)
            .onClick(() => {
              this.accountTable.query(0, (result: AccountData[]) => {
                this.message = result; // 更新查询结果
                this.showReturnButton = true; // 显示返回按钮
              }, true);
            });
        }
        .layoutWeight(1); // 平均分配宽度
        Column() {
          // 修改按钮
          Button('修改')
            .type(ButtonType.Capsule)
            .width(120)
            .fontSize(32)
            .onClick(() => {
              let newAccount: AccountData = {
                id: 1,
                accountType: 1,
                typeText: '栗子',
                amount: 1
              };
              this.accountTable.updateData(newAccount, () => {}); // 更新账户数据
            });
          // 删除按钮
          Button('删除')
            .type(ButtonType.Capsule)
            .width(120)
            .fontSize(32)
            .onClick(() => {
              let newAccount: AccountData = {
                id: 2,
                accountType: 1,
                typeText: '栗子',
                amount: 1
              };
              this.accountTable.deleteData(newAccount, () => {}); // 删除账户数据
            });
          // 返回按钮（动态显示）
          if (this.showReturnButton) {
            Button(('返回'), { type: ButtonType.Capsule })
              .width(140)
              .fontSize(40)
              .fontWeight(FontWeight.Medium)
              .margin({ top: 20, bottom: 20 })
              .onClick(() => {
                this.showReturnButton = false; // 隐藏返回按钮
                // 重新显示增删改查按钮
              });
          }
        }
        .layoutWeight(1);
      }
      .height('auto') // 根据内容自动调整高度
      .margin({ top: 20 }); // 与上方内容保持距离
      Text(JSON.stringify(this.message))
        // 设置字体大小为50
        .fontSize(50)
        // 设置字体加粗
        .fontWeight(FontWeight.Bold);

      // 创建水平布局容器，设置高度为100%
      Row() {
        // 创建垂直布局容器，设置宽度为100%
        Column() {
          // TextInput组件，设置无输入时的提示文本
          TextInput({ placeholder: '请输入您的姓名' })
            // 设置文本颜色
            .placeholderColor(Color.Grey)
            // 设置文本样式
            .placeholderFont({ size: 14, weight: FontWeight.Normal })
            // 设置输入框光标颜色
            .caretColor(Color.Blue)
            // 设置输入框的宽度
            .width(300)
            // 设置输入框的高度
            .height(40)
            // 设置输入框的外边距
            .margin(20)
            // 设置输入框中文字的颜色
            .fontColor(Color.Black)
            // 设置输入框的值发生变化时的回调函数
            .onChange((value: string) => {
              // 当输入框的内容发生变化时，将新的输入值赋值给 this.inputContent
              // 用于实时更新输入内容
              this.inputContent = value;
            });
          // 添加按钮，以响应用户点击
          Button() {
            // 按钮内文本内容
            Text('登录')
              // 设置字体大小为30
              .fontSize(30)
              // 设置字体加粗
              .fontWeight(FontWeight.Bold);
          }
          // 设置按钮
          .type(ButtonType.Capsule)
          // 设置外边距（上20）
          .margin({ top: 20 })
          // 设置背景颜色为蓝色
          .backgroundColor('#0D9FFB')
          // 设置按钮宽度为父容器的40%
          .width('40%')
          // 设置按钮高度为父容器的5%
          .height('15%')
          // 跳转按钮绑定onClick事件，点击时跳转到第二页
          .onClick(() => {
            // 点击时输出日志信息
            console.info('Succeeded in clicking the "load" button.');
            // 跳转到第二页
            router.pushUrl({ url: 'pages/Second',
              params: { content: this.inputContent }
            })
              // 跳转成功回调
              .then(() => {
                console.info('Succeeded in jumping to the second page.');
              })
              // 跳转失败回调
              .catch((err: BusinessError) => {
                // 输出错误日志（使用模板字符串拼接错误码和消息）
                console.error('Failed to jump to the second page. Code is ${err.code}, message is ${err.message}');
              });
          });
        }
        // 设置Column容器宽度为100%
        .width('100%');
      }
      .layoutWeight(1);
    }
    // 设置Row容器高度为100%
    .height('100%')
    // 设置背景颜色
    .backgroundColor('#FFFFFF');
  }
}
```

#### 4.2 结果验证
应用初始界面（把之前的加载动态的组件移动到跳转后的第二个页面了），点击增加后进行查询（点击查询后会出现一个返回的按钮）、点击修改后进行查询、再点击增加后进行查询，点击删除后进行查询的操作
![alt text](初始界面.png){width=150px height=300px} ![alt text](增加后查询.png){width=150px height=300px} ![alt text](修改后查询.png){width=150px height=300px} ![alt text](再增加查询.png){width=150px height=300px} ![alt text](删除后查询.png){width=150px height=300px}
