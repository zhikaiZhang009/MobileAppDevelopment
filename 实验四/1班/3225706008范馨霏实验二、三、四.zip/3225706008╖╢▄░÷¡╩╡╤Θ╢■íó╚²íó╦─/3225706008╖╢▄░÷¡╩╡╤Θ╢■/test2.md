# <font ><center>移动应用开发 </font>
## <center>实验二:页面信息传递及新增UI控件
> 学号：3225706008
> 
> 姓名：范馨霏
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-03-17
#### 一、实验演示： 
我给我的两个页面添加了TextClock、Divider、LoadingProgress、TextInput、Text、TextTimer，共6个UI控件，这两个页面通过页面路由的参数（params）来实现页面信息传递。
当未输入信息直接跳转时，第二页显示默认的“Welcome！”字样。
![image-未输入信息时页面一](未输入信息时页面一.png){width=150px height=300px} ![image-未输入信息跳转页面二](未输入信息跳转页面二.png){width=150px height=300px}
当输入姓名的信息时，第二页会接收到，并显示“Hello，xx”字样
![image-输入信息后页面一](输入信息后页面一.png){width=150px height=300px} ![image-输入信息后页面二](输入信息后页面二.png){width=150px height=300px}
当进行页面跳转时，log显示的信息内容
![image-进行页面跳转时的log日志](进行页面跳转时的log日志.png){width=700px height=150px}
#### 二：实验代码：
页面一Index.ets：
```typescript{.line-numbers}
//Index.ets
//导入页面路由模块
import {router} from '@kit.ArkUI';
// 导入业务错误处理模块（用于捕获路由错误）
import {BusinessError} from '@kit.BasicServicesKit'
// @Entry 装饰器：标记本组件为页面入口
@Entry
  // @Component 装饰器：声明本结构体为UI组件
@Component
struct Index {
  // @State 装饰器：声明响应式状态变量，用于动态更新UI
  @State message: string = '';
  // 新增状态存储输入内容
  @State inputContent: string = ''
  // 构建UI结构的方法
  build() {
    // 创建垂直布局容器
    Column() {
      // 创建水平布局容器
      Row() {
        //显示时间组件
        TextClock()
          //日期格式化
          .margin({ left: 30 }).fontSize(25).format('yyyy/MM/dd HH:mm:ss')
      }
      // 固定高度或改用百分比
      .height('6%')
      // 可选背景色
      .backgroundColor('#FFFFFF')
      // 设置内容的对齐方式为起始对齐
      .justifyContent(FlexAlign.Start)
      //分隔线组件
      Divider()
        // 设置分隔线的宽度为
        .strokeWidth(15)
          // 设置分隔线的颜色
        .color(0X2788D9)
          // 设置分隔线的端点样式为圆角
        .lineCap(LineCapStyle.Round)
      // 加载进度条组件
      LoadingProgress()
        // 设置加载进度条的颜色
        .color(Color.Blue)

      // 创建水平布局容器，设置高度为100%
      Row() {
        // 创建垂直布局容器，设置宽度为100%
        Column() {
          // TextInput组件，设置无输入时的提示文本
          TextInput({placeholder: '请输入您的姓名'})
            //设置文本颜色
            .placeholderColor(Color.Grey)
            //设置文本样式
            .placeholderFont({size: 14, weight: FontWeight.Normal})
            //设置输入框光标颜色
            .caretColor(Color.Blue)
              // 设置输入框的宽度
            .width(300)
              // 设置输入框的高度
            .height(40)
              // 设置输入框的外边距
            .margin(20)
              // 设置输入框中文字的颜色
            .fontColor(Color.Black)
              // 设置输入框的值发生变化时的回调函数
            .onChange((value: string) => {
              // 当输入框的内容发生变化时，将新的输入值赋值给 this.inputContent
              // 用于实时更新输入内容
              this.inputContent = value
            })
          // 显示文本组件，绑定message状态变量
          Text(this.message)
            // 设置字体大小为50
            .fontSize(50)
              // 设置字体加粗
            .fontWeight(FontWeight.Bold)
          //添加按钮，以响应用户点击
          Button() {
            // 按钮内文本内容
            Text('登录')
              // 设置字体大小为30
              .fontSize(30)
                // 设置字体加粗
              .fontWeight(FontWeight.Bold)
          }
          // 设置按钮
          .type(ButtonType.Capsule)
          // 设置外边距（上20）
          .margin({ top: 20 })
          // 设置背景颜色为蓝色
          .backgroundColor('#0D9FFB')
          // 设置按钮宽度为父容器的40%
          .width('40%')
          // 设置按钮高度为父容器的5%
          .height('15%')
          //跳转按钮绑定onClick事件，点击时跳转到第二页
          .onClick(() => {
            // 点击时输出日志信息
            console.info('Succeeded in clicking the "load" button.')
            //跳转到第二页
            router.pushUrl({ url: 'pages/Second',
              params: { content: this.inputContent }
            })
              // 跳转成功回调
              .then(() => {
                console.info('Succeeded in jumping to the second page.')
            })
                // 跳转失败回调
              .catch((err: BusinessError) => {
                // 输出错误日志（使用模板字符串拼接错误码和消息）
              console.error('Failed to jump to the second page. Code is ${err.code}, message is ${err.message}')
            })
          })
        }
        // 设置Column容器宽度为100%
        .width('100%')
      }
      .layoutWeight(1)
    }
    // 设置Row容器高度为100%
    .height('100%')
    //设置背景颜色
    .backgroundColor('#FFFFFF')
    }
  }
```
页面二Second.ets：
```typescript{.line-numbers}
// Second.ets
// 导入页面路由模块（用于页面导航）
import { router } from '@kit.ArkUI';
// 导入业务错误处理模块（用于捕获路由错误）
import { BusinessError } from '@kit.BasicServicesKit';


// 定义页面参数类型
interface PageParams {
  content?: string;
}
// @Entry 装饰器：标记本组件为页面入口
// @Component 装饰器：声明本结构体为UI组件
// 装饰器直接修饰组件类
@Entry
@Component

struct Second {
  // @State 装饰器：声明响应式状态变量，用于动态更新UI
  @State message: string = 'Hi There';
  // params属性声明
  private params: PageParams = {};
  //TextTimer组件的控制器
  private textTimerController: TextTimerController = new TextTimerController()

  // aboutToAppear 方法：页面即将显示时触发
  aboutToAppear() {
    // 通过 router 获取参数
    const params = router.getParams() as PageParams;
    // 调用 handleMessageParams 方法处理获取到的参数
    this.handleMessageParams(params);
  }

  // handleMessageParams 方法：处理页面参数
  handleMessageParams(params: PageParams) {
    // 直接访问 this.params
    if (params.content) {
      // 如果有 content 属性，将内容拼接
      // 添加接收内容
      this.message = `Hello, ${params.content}`;
    } else {
      // 没有内容时显示默认
      this.message = 'Welcome!';
    }
  }

  // 构建UI结构的方法
  build() {
    // 获取页面参数
    // 创建水平布局容器，设置高度为100%
    Row() {
      // 创建垂直布局容器，设置宽度为100%
      Column() {
        //单行文本
        Text('开始计时吧！').fontSize(24)
          //文本颜色
          .fontColor(Color.Blue)
          //文本位置
          .textAlign(TextAlign.Center)
        //定义TextTimer组件
        TextTimer({controller:this.textTimerController,
          //是否倒计时，默认值为false
          isCountDown:true,
          //倒计时时间，单位为毫秒
          count:30000})
          //格式化
          .format('mm:ss.SS')
          //字体颜色
          .fontColor(Color.Black)
          //字体大小
          .fontSize(50)
       //控制按钮
        Row(){
          // 创建一个按钮，显示文本 "开始"，设置按钮的点击事件回调函数
          Button("开始").onClick(()=>{
            // 当按钮被点击时，开始计时器
            this.textTimerController.start()
          })
          // 创建一个按钮，显示文本 "暂停"，设置按钮的点击事件回调函数
          Button("暂停").onClick(()=>{
            // 当按钮被点击时，暂停计时器
            this.textTimerController.pause()
          })
          // 创建一个按钮，显示文本 "重置"，设置按钮的点击事件回调函数
          Button("重置").onClick(()=>{
            // 当按钮被点击时，重置计时器
            this.textTimerController.reset()
          })
        }
        // 显示文本组件，绑定message状态变量
        Text(this.message)
          // 设置字体大小为50
          .fontSize(50)
            // 设置字体加粗
          .fontWeight(FontWeight.Bold)
            // 添加顶部间距
          .margin({ top: 40 })
        // 创建按钮
        Button() {
          // 按钮内文本内容
          Text('退出')
            // 设置字体大小为30
            .fontSize(30)
              // 设置字体加粗
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮
        .type(ButtonType.Capsule)
        // 设置外边距（上20）
        .margin({
          top: 20
        })
        // 设置背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        // 设置按钮宽度为父容器的40%
        .width('40%')
        // 设置按钮高度为父容器的5%
        .height('5%')

        //返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(()=>{
          // 点击时输出日志信息
          console.info('Succeeded in clicking the "退出" button.')
          try{
            //返回第一页
            //此函数完成页面跳转
            router.back()
            // 返回成功日志
            console.info('Succeeded in returning to the first page.')
          }
          catch(err) {
            // 错误处理（尝试将错误转换为BusinessError类型）
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            // 输出错误日志（使用模板字符串拼接错误码和消息）
            console.error('Failed to return to the first page. Code is ${code}, message is ${message}')
          }
          })
      }
      // 设置Column容器宽度为100%
      .width('100%')
    }
    // 设置Row容器高度为100%
    .height('100%')
    // 添加背景色
    .backgroundColor('#FFFFFF')
  }
}
```
#### 三：对函数的总结说明：
1. 导航相关 API
`router.back()`
功能：关闭当前页面并返回上一页。
说明：属于 `@kit.ArkUI` 的路由管理模块，用于页面栈的导航操作。若页面栈中无上一页，可能触发异常。
参考：
HarmonyOS API - router.back()
`router.pushUrl()`
功能：实现页面跳转，将目标页压入页面栈，保留当前页状态。
说明：属于`@kit.ArkUI`的路由管理模块，支持应用内不同页面间的跳转。通过params属性可传递参数至目标页面。
参考：
HarmonyOS API - router.pushUrl()
`router.getParams()`
功能：获取页面跳转时传递的参数。
说明：在目标页面通过此方法获取源页面传递的参数，需配合router.pushUrl()使用。
参考：
HarmonyOS API - router.getParams()
1. 错误处理 API
`BusinessError`
功能：表示业务逻辑层抛出的错误类型，包含错误码（code）和错误信息（message）。
说明：属于 `@kit.BasicServicesKit`，用于统一错误处理。通过 (err as BusinessError) 类型断言提取错误详情。
参考：
HarmonyOS API - BusinessError
1. 组件与装饰器
`@Entry`
功能：标记组件为页面入口，使组件可被路由加载。
说明：必须与 `@Component `配合使用，定义页面的根组件。
参考：
HarmonyOS API - @Entry
`@Component`
功能：声明一个 UI 组件，定义组件的生命周期和模板。
说明：所有可视化组件均需通过此装饰器注册。
参考：
HarmonyOS API - @Component
`@State`
功能：声明组件的响应式状态变量，数据变化时自动触发 UI 更新。
说明：需初始值，修改时需通过 setState 方法（本例直接赋值可能依赖框架隐式更新）。
参考：
HarmonyOS API - @State
1. UI 组件与布局
`Row() / Column()`
功能：定义水平（Row）或垂直（Column）布局容器，自动排列子组件。
说明：通过 `.width('100%')` 和` .height('100%') `设置布局尺寸，适配父容器。
参考：
HarmonyOS API - Row/Column
`Text()`
功能：显示文本内容，支持样式定制。
说明：通过 `.fontSize(50) `和 `.fontWeight(FontWeight.Bold)` 设置字体大小和粗细。
参考：
HarmonyOS API - Text
`Button()`
功能：创建可交互按钮，支持点击事件和样式配置。
关键属性：
`.type(ButtonType.Capsule)`：设置按钮形状为胶囊样式。
`.margin({ top: 20 })`：设置外边距。
`.backgroundColor('#0D9FFB')`：设置背景色。
`.onClick(() => { ... })`：绑定点击事件。
参考：
HarmonyOS API - Button
`TextClock`
功能：显示系统时间的文本组件。
说明：支持不同时区的时间显示，最高精度到秒级。可通过format属性设置时间格式，如`"yyyy/MM/dd HH:mm:ss"`。
参考：
HarmonyOS API - TextClock
`Divider`
功能：分隔器组件，用于分隔不同内容块。
说明：支持横向和纵向分割线，可通过strokeWidth和color属性设置分隔线的宽度和颜色。
参考：
HarmonyOS API - Divider
`LoadingProgress`
功能：显示加载动效的组件。
说明：用于表示加载状态，可通过color属性设置动效颜色。
参考：
HarmonyOS API - LoadingProgress
`TextInput`
功能：文本框组件，支持用户输入文本。
说明：可通过placeholder属性设置输入提示文本，onChange事件监听输入内容变化。
参考：
HarmonyOS API - TextInput
`TextTimer`
功能：显示计时信息的文本组件。
说明：支持控制计时器状态（如开始、暂停、重置），可通过format属性设置时间格式。
参考：
HarmonyOS API - TextTimer

1. 样式与布局属性
`.fontSize() / .fontWeight()`
功能：设置字体大小和粗细，参数为数值或枚举值（如 FontWeight.Bold）。
说明：属于 TextStyle 属性，影响文本显示效果。
参考：
HarmonyOS API - TextStyle
`.margin() / .width() / .height()`
功能：设置组件的外边距、宽度和高度，支持百分比或固定值。
说明：`.width('40%')` 表示按钮宽度为父容器的 40%。
参考：
HarmonyOS API - LayoutStyle
`FlexAlign`
功能：设置布局的对齐方式。
说明：用于控制子组件在布局容器中的对齐方式，如FlexAlign.Start表示起始端对齐。
参考：
HarmonyOS API - FlexAlign
`LineCapStyle`
功能：设置线条的端点样式。
说明：用于控制分隔线等组件的端点样式，如LineCapStyle.Round表示圆角端点。
参考：
HarmonyOS API - LineCapStyle
`Color`
功能：设置组件的颜色。
说明：支持多种颜色格式，如十六进制（#0D9FFB）、RGB等。
参考：
HarmonyOS API - Color
`ButtonType`
功能：设置按钮的类型。
说明：支持多种按钮类型，如ButtonType.Capsule表示胶囊样式按钮。
参考：
HarmonyOS API - ButtonType
`TextAlign`
功能：设置文本的对齐方式。
说明：支持多种对齐方式，如TextAlign.Center表示居中对齐。
参考：
HarmonyOS API - TextAlign
`backgroundColor`
功能：设置组件的背景颜色。
说明：支持多种颜色格式，如十六进制（#FFFFFF）。
参考：
HarmonyOS API - backgroundColor
1. 事件处理
`.onClick(() => { ... })`
功能：为按钮绑定点击事件回调函数。
说明：用户点击按钮时触发，内部调用 router.back() 并处理异常。
参考：
HarmonyOS API - onClick
1. 生命周期方法
`aboutToAppear`
功能：页面即将显示时触发的方法。
说明：可用于获取页面参数或执行初始化操作。
参考：
HarmonyOS API - aboutToAppear