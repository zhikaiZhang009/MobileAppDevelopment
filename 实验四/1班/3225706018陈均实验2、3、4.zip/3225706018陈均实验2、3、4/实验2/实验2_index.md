// 导入ArkUI框架中的路由模块，用于页面跳转。  
import { router } from '@kit.ArkUI'  
// 导入BusinessError类，用于处理业务错误。  
import { BusinessError } from  '@kit.BasicServicesKit'  

// 使用@Entry装饰器标记该组件为应用的入口组件。  
@Entry  
  // 使用@Component装饰器定义一个ArkUI组件。  
@Component  
struct Index {  
  // 使用@State装饰器定义一个响应式状态变量message，并初始化为'Index页面'。  
  @State message: string = 'Index页面'  
  // build函数定义了组件的UI结构。  
  build(){  
    // 使用Row组件创建一个水平排列的布局。  
    Row(){  
      // 使用Column组件创建一个垂直排列的布局。  
      Column(){  
        Search({ placeholder: '输入内容......'})  
          .searchButton('搜索')  
          .width(300)  
          .height(40)  
          .placeholderColor(Color.Grey)  
          .placeholderFont({ size: 24, weight: 400})  
          .textFont({size: 24, weight: 400})  
        // 添加一个Text组件显示message变量的内容。  
        Text(this.message)  
          // 设置文本的字体大小为50。  
          .fontSize(50)  
            // 设置文本的字体权重为Bold。  
          .fontWeight(FontWeight.Bold)  
        TextClock().margin(20).fontSize(30)  
          .format('yyyy/MM/dd hh:mm:ss')  
        LoadingProgress()  
          .height(200)  
          .color(Color.Blue)  
        DatePicker({  
          start: new Date('1970-1-1'),  
          end: new Date('2100-1-1'),  
          selected: new Date('2025-3-17')  
        })  
        // 添加一个按钮，用于响应用户的点击事件。  
        Button(){  
          // 在按钮内添加一个Text组件显示'Next'。  
          Text('Next')  
            // 设置按钮内文本的字体大小为30。  
            .fontSize(30)  
              // 设置按钮内文本的字体权重为Bold。  
            .fontWeight(FontWeight.Bold)  
        }//Button函数括号  
        // 设置按钮的类型为Capsule（胶囊型）。  
        .type(ButtonType.Capsule)  
        // 设置按钮的外边距，上边距为20。  
        .margin({  
          top: 20  
        })//margin函数  
        // 设置按钮的背景颜色。  
        .backgroundColor('#0D9FFB')  
        // 设置按钮的宽度为父组件宽度的30%。  
        .width('30%')  
        // 设置按钮的高度为父组件高度的5%。  
        .height('10%')  
        // 为按钮添加点击事件监听器。  
        .onClick(() => {  
          console.info('Succeeded in clicking the ‘Next’ button.')  
          // 使用router.pushUrl方法跳转到第二页。  
          router.pushUrl({ url: 'pages/Second',params: {src:'Index页面传来的数据',}  
          }).then(() => {  
            console.info('Succeeded in jumping to second page.')  
          }).catch((err: BusinessError) => {  
            // 如果跳转失败，打印错误信息。  
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);  
          })//catch函数  
        })//.onClick函数  
      }//Column函数  
      // 设置Column组件的宽度为100%。  
      .width('100%')  
    }//Row函数  
    // 设置Row组件的高度为100%。  
    .height('50%')  
  }//build函数  
}//Index
