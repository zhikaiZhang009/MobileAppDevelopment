# 实验二   页面信息传递及新增UI控件
## 一、实验代码
### 1、Index页面
```typescript
// 导入页面路由模块，用于页面跳转
import { router } from '@kit.ArkUI';
// 导入业务错误类，用于处理路由跳转失败时的错误
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器定义一个页面组件，表示这是一个入口页面
@Entry
  // 使用 @Component 装饰器定义一个页面组件，表示这是一个可复用的组件
@Component
struct Index { // 定义一个名为 Index 的页面组件
  // 定义一个状态变量 message，用于显示页面的文本内容
  @State message: string = 'Hello World'; // 初始化状态变量，值为 'Hello World'
  // 定义一个状态变量 inputText，用于存储用户输入的文本
  @State inputText: string = ''; // 初始化状态变量，值为空字符串

  // 定义页面的构建逻辑
  build() { // 定义页面的构建方法
    // 使用 Row 布局组件，将页面内容水平排列
    Row() { // 开始 Row 布局组件的定义
      // 使用 Column 布局组件，将内容垂直排列
      Column() { // 开始 Column 布局组件的定义

        // 添加一个 TextClock 组件，用于显示当前日期和时间
        TextClock().margin(20).fontSize(50) // 设置外边距20单位，字体大小50单位
          .format(`yyyy/MM/dd hh:mm`) //日期格式化，通过format属性设置显示时间

        Text(this.message) // 创建一个 Text 组件，内容为状态变量 message 的值
          .fontSize(50) // 设置字体大小为 50
          .fontWeight(FontWeight.Bold); // 设置字体为加粗

        // 添加图片显示组件
        Image($r('app.media.cat'))  // 加载resources目录下的cat图片
          .width(150) // 设置宽度150单位
          .height(150) // 设置高度150单位
          .margin({ top: 50, bottom: 30 }) // 设置上下外边距

        // 添加一个 TextInput 组件，用于接收用户输入
        TextInput({ placeholder: '请输入内容' }) // 设置占位提示文字
          .width('80%') // 宽度占父容器80%
          .height(50)  // 高度50单位
          .margin({ top: 20, bottom: 20 }) // 设置上下外边距
            // 绑定输入变化事件，value是当前输入内容
          .onChange((value: string) => {
            this.inputText = value; // 当用户输入时，更新 inputText 状态变量
          });

        // 添加一个按钮组件，用于响应用户点击
        Button() {
          Text("Next") // 按钮内部的文本为“next"
            .fontSize(30) // 字体大小30单位
            .fontWeight(FontWeight.Bold); // 字体加粗
        }  //结束按钮的定义
        .type(ButtonType.Capsule)  // 设置按钮样式为胶囊形状
        .margin({ top: 10 })  // 上外边距10单位
        .backgroundColor('#0D9FFB') // 背景颜色设置为蓝色
        .width('40%') // 设置按钮的宽度为页面宽度的 40%
        .height('5%') // 设置按钮的高度为页面高度的 5%
        // 绑定点击事件
        .onClick(() => {
          // 路由跳转到 Second 页面，并传递用户输入的参数
          router.pushUrl({
            url: 'pages/Second', // 目标页面路径
            params: { inputText: this.inputText } // 将 inputText 作为参数传递
          })
            .then(() => { // 定义跳转成功的回调
              // 如果跳转成功，在控制台打印成功日志
              console.info('Succeeded in jumping to the second page.'); // 打印跳转成功的日志
            })
            .catch((err: BusinessError) => { // 定义跳转失败的回调
              // 如果跳转失败，捕获错误并在控制台打印错误信息
              console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`); // 打印错误信息
            });
        }); // 结束按钮的点击事件定义
      } // 结束 Column 布局组件的定义
      .width('100%'); // 设置 Column 的宽度为 100%
    } // 结束 Row 布局组件的定义
    .height('100%'); // 设置 Row 的高度为 100%
  } // 结束页面的构建方法定义
```
---
### 2、Second页面
```typescript
// 导入页面路由模块，用于页面跳转
import { router } from '@kit.ArkUI';
// 导入业务错误类，用于处理路由跳转失败时的错误
import { BusinessError } from '@kit.BasicServicesKit';
// 定义路由参数接口，用于类型检查
interface GeneratedTypeLiteralInterface_1 {
  inputText: string; // 接收从首页传递过来的文本参数
}

@Entry // @Entry 装饰器，表示这是一个页面的入口点
@Component // @Component 装饰器，表示这是一个可复用的组件
struct Second { // 定义一个名为 Second 的页面组件
  // 定义一个状态变量 receivedText，用于存储从 Index 页面传递过来的参数
  @State receivedText: string = ''; // 初始化状态变量，值为空字符串

  // 生命周期函数：在组件即将显示时触发
  aboutToAppear() {
    // 获取路由传递的参数
    const params = router.getParams() as GeneratedTypeLiteralInterface_1; // 检查参数是否存在且包含inputText属性
    if (params && params.inputText) {
      this.receivedText = params.inputText; // 将传递过来的参数赋值给 receivedText
    }
  }

  // 定义页面的构建逻辑
  build() { // 定义页面的构建方法，用于构建页面的 UI 结构
    Row() { // 创建一个 Row 布局组件，用于水平排列子组件
      Column() { // 创建一个 Column 布局组件，用于垂直排列子组件
        //添加选择日期的滑动选择器组件DatePicker
        DatePicker({
          start: new Date('1970-1-1'), //指定选择器的起始日期。默认值为Date('1970-1-1')
          end: new Date('2100-1-1'), //指定选择器的结束日期。默认值为Date('2100-1-1')
          selected: new Date('2025-3-24'), //设置选中项的日期。默认值为当前系统日期
        }) .lunar(true)  //设置农历
          .onChange((value: DatePickerResult) => {  // 日期变化回调函数，选择日期时触发该事件
            console.info('select current date is: ' + JSON.stringify(value))
          })
          .position({x:10,y:-250})  // 设置组件位置（x:水平位置，y:垂直位置）

        // 添加分割线组件
        Divider()
          .strokeWidth(15) // 设置分割线粗细
          .color(0x2788D9) // 设置分割线颜色
          .lineCap(LineCapStyle.Round)// 设置线帽样式为圆角
          .position({x:5,y:-20})// 设置分割线位置

        // 欢迎文本组件
        Text(`欢迎您，${this.receivedText}`) //显示 "欢迎您" 加上接收的参数
          .fontSize(30) // 设置字体大小
          .fontWeight(FontWeight.Bold) // 设置字体加粗
          .margin({ bottom: 20 })  // 设置下边距
          .position({x:90,y:20}); // 设置文本位置

        // 添加一个按钮组件，用于响应用户点击
        Button() {
          Text('Back')  // 按钮文本为”Back“
            .fontSize(30) // 设置字体大小
            .fontWeight(FontWeight.Bold)  // 设置字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮样式为胶囊形状
        .margin({ top: 20 }) // 设置上边距
        .backgroundColor('#0D9FFB')// 设置背景颜色
        .width('40%')// 设置宽度为父容器的40%
        .height('5%')// 设置高度为父容器的5%
        .position({x:100,y:100})// 设置按钮位置
        // 按钮点击事件处理
        .onClick(() => {
          console.info('Succeeded in clicking the "Back" button.');// 在控制台打印点击按钮成功的日志
          try {
            router.back();// 调用路由模块的 back 方法，返回上一页
            console.info('Succeeded in returning to the first page.');// 打印返回成功的日志
          } catch (err) { // 使用 try...catch 捕获可能出现的错误
            let code = (err as BusinessError).code; // 将 err 断言为 BusinessError 类型，并提取错误代码
            let message = (err as BusinessError).message; // 提取错误消息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`);// 在控制台打印错误信息
          }
        });// 结束按钮的点击事件定义
      }// 结束 Column 布局组件的定义
      .width('100%');// 调用 Column 组件的 width 方法，设置宽度为 100%
    }// 结束 Row 布局组件的定义
    .height('100%');// 调用 Row 组件的 height 方法，设置高度为 100%
  }// 结束页面的构建方法定义
}// 结束页面组件 Second 的定义
```
---
## 二、应用界面介绍及截图以及日志截图
### 1、Index页面
在Index页面中添加了三个组件，一个是可以显示当前系统时间的TimeClock组件，一个是图片组件，一个是文本输入组件，在这里的文本输入组件用来实现页面间的传参

<img src="Index.png" width="250" alt="Index页面">

通过在文本输入框输入“zlj”，会在Second页面接收到参数，并显示定义的“欢迎您，”加上接收的参数

| ![test页面1](test1.png) | ![test页面2](test2.png) |
|-------------------------|-------------------------|

### 2、Second页面
在Second页面中添加了一个选择日期的滑动选择器组件以及分割线组件

<img src="test2.png" width="250" alt="Second页面">

### 3、日志截图 
在页面实现了成功跳转

![log页面](log.png)