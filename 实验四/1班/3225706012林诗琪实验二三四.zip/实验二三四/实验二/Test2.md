# 实验二 添加组件实现页面传参

## 代码实现过程
```typescript
// index.etc
// 导入页面路由模块
import { router } from '@kit.ArkUI'; // 导入路由模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理模块

@Entry // 标记为入口组件
@Component // 标记为自定义组件
struct Index { // 定义 Index 组件
  @State message: string = 'Hello World'; // 定义状态变量 message，初始值为 'Hello World'
  @State currentTime: string = this.getCurrentTime(); // 定义状态变量 currentTime，初始值为当前时间
  @State searchValue: string = ''; // 定义状态变量 searchValue，用于存储搜索框内容
  @State patternValue: string = ''; // 定义状态变量 patternValue，用于存储密码框内容

  // 获取当前时间
  getCurrentTime(): string { // 定义方法 getCurrentTime，返回当前时间的字符串
    const now = new Date(); // 获取当前时间
    return now.toLocaleTimeString(); // 返回格式化的时间字符串
  } // getCurrentTime 方法结束

  // 定时更新当前时间
  aboutToAppear() { // 生命周期方法，组件加载时调用
    setInterval(() => { // 设置定时器，每秒执行一次
      this.currentTime = this.getCurrentTime(); // 更新 currentTime 状态变量
    }, 1000); // 定时器间隔为 1000 毫秒（1 秒）
  } // aboutToAppear 方法结束

  // 处理搜索框内容
  onSearchSubmit(value: string) { // 定义方法 onSearchSubmit，处理搜索框提交事件
    this.searchValue = value; // 更新 searchValue 状态变量
    console.info(`搜索内容: ${value}`); // 打印搜索内容到控制台
  } // onSearchSubmit 方法结束

  // 处理密码框内容
  onPatternComplete(value: number[]) { // 定义方法 onPatternComplete，处理密码框绘制完成事件
    this.patternValue = value.join(','); // 将数组转换为字符串，并更新 patternValue 状态变量
    console.info(`密码框内容: ${this.patternValue}`); // 打印密码框内容到控制台
  } // onPatternComplete 方法结束

  build() { // 定义 build 方法，用于构建 UI
    Stack() { // 使用 Stack 布局
      Image($r('app.media.xx')) // 添加背景图片
        .width('100%') // 设置宽度为 100%
        .height('100%') // 设置高度为 100%
        .objectFit(ImageFit.Cover) // 设置图片填充方式为 Cover

      Column() { // 使用 Column 布局
        Text(this.message) // 添加文本组件，显示 message
          .fontSize(50) // 设置字体大小为 50
          .fontWeight(FontWeight.Bold) // 设置字体加粗

        // 搜索框
        Search({ placeholder: "输入内容..." }) // 添加搜索框组件
          .searchButton('搜索') // 设置搜索按钮文本
          .onSubmit((value: string) => { // 设置搜索框提交事件回调
            this.onSearchSubmit(value); // 调用 onSearchSubmit 方法处理搜索内容
          })
          .width(300) // 设置搜索框宽度
          .height(80) // 设置搜索框高度
          .placeholderColor(Color.Grey) // 设置占位符颜色
          .placeholderFont({ size: 24, weight: 400 }) // 设置占位符字体
          .textFont({ size: 24, weight: 400 }) // 设置输入文本字体

        Text(`当前时间: ${this.currentTime}`) // 添加文本组件，显示当前时间
          .fontSize(30) // 设置字体大小为 30
          .margin({ top: 20 }) // 设置上边距为 20
          .fontWeight(FontWeight.Bold) // 设置字体加粗

        // 密码框
        PatternLock() // 添加密码框组件
          .sideLength(200) // 设置密码框边长
          .circleRadius(9) // 设置圆圈半径
          .pathStrokeWidth(18) // 设置路径宽度
          .activeColor('#B0C4DE') // 设置激活颜色
          .selectedColor('#228B22') // 设置选中颜色
          .pathColor('#90EE90') // 设置路径颜色
          .autoReset(true) // 设置自动重置
          .onPatternComplete((value: number[]) => { // 设置密码框绘制完成事件回调
            this.onPatternComplete(value); // 调用 onPatternComplete 方法处理密码框内容
          })

        // 跳转按钮
        Button() { // 添加按钮组件
          Text('Next') // 添加文本组件，显示 'Next'
            .fontSize(30) // 设置字体大小为 30
            .fontWeight(FontWeight.Bold) // 设置字体加粗
        } // Button 组件结束
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊按钮
        .margin({ top: 20 }) // 设置上边距为 20
        .backgroundColor('#0D9FFB') // 设置背景颜色
        .width('40%') // 设置宽度为 40%
        .height('5%') // 设置高度为 5%
        .onClick(() => { // 设置按钮点击事件回调
          console.info('Succeeded in clicking the "Next" button.'); // 打印日志

          // 跳转到第二页，并传递参数
          try {
            router.pushUrl({ // 调用路由跳转方法
              url: 'pages/Second', // 跳转到 Second 页面
              params: { // 传递参数
                time: this.currentTime, // 传递时间
                search: this.searchValue, // 传递搜索框内容
                pattern: this.patternValue // 传递密码框内容
              }
            }).then(() => { // 跳转成功回调
              console.info('Succeeded in jumping to the second page.'); // 打印日志
            }).catch((err: BusinessError) => { // 跳转失败回调
              console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`); // 打印错误日志
            });
          } catch (err) { // 捕获异常
            console.error(`Failed to push URL. Error: ${err}`); // 打印错误日志
          }
        }) // onClick 回调结束
      } // Column 组件结束
      .width('100%') // 设置宽度为 100%
      .alignItems(HorizontalAlign.Center) // 设置水平居中对齐
    } // Stack 组件结束
    .width('100%') // 设置宽度为 100%
    .height('100%') // 设置高度为 100%
  } // build 方法结束
} // Index 组件结束


// 导入页面路由模块
import { router } from '@kit.ArkUI'; // 导入路由模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理模块

@Entry // 标记为入口组件
@Component // 标记为自定义组件
struct Second { // 定义 Second 组件
  @State message: string = 'Hi there'; // 定义状态变量 message，初始值为 'Hi there'
  @State time: string = ''; // 定义状态变量 time，用于接收传递的时间
  @State search: string = ''; // 定义状态变量 search，用于接收传递的搜索框内容
  @State pattern: string = ''; // 定义状态变量 pattern，用于接收传递的密码框内容

  // 生命周期函数：组件加载时获取路由参数
  aboutToAppear() { // 生命周期方法，组件加载时调用
    try {
      const params = router.getParams() as Record<string, string>; // 获取路由参数
      if (params) { // 如果参数存在
        this.time = params['time'] || ''; // 获取时间参数，如果不存在则赋值为空字符串
        this.search = params['search'] || ''; // 获取搜索框内容参数，如果不存在则赋值为空字符串
        this.pattern = params['pattern'] || ''; // 获取密码框内容参数，如果不存在则赋值为空字符串
      }
    } catch (err) { // 捕获异常
      console.error(`Failed to get params. Error: ${err}`); // 打印错误日志
    }
  } // aboutToAppear 方法结束

  build() { // 定义 build 方法，用于构建 UI
    Stack() { // 使用 Stack 布局
      Image($r('app.media.xx')) // 添加背景图片
        .width('100%') // 设置宽度为 100%
        .height('100%') // 设置高度为 100%
        .objectFit(ImageFit.Cover) // 设置图片填充方式为 Cover

      Column() { // 使用 Column 布局
        Text(this.message) // 添加文本组件，显示 message
          .fontSize(50) // 设置字体大小为 50
          .fontWeight(FontWeight.Bold) // 设置字体加粗

        // 显示传递的时间
        Text(`时间: ${this.time}`) // 添加文本组件，显示传递的时间
          .fontSize(30) // 设置字体大小为 30
          .margin({ top: 20 }) // 设置上边距为 20
          .fontWeight(FontWeight.Bold) // 设置字体加粗

        // 显示传递的搜索框内容
        Text(`搜索内容: ${this.search}`) // 添加文本组件，显示传递的搜索框内容
          .fontSize(30) // 设置字体大小为 30
          .margin({ top: 20 }) // 设置上边距为 20
          .fontWeight(FontWeight.Bold) // 设置字体加粗

        // 显示传递的密码框内容
        Text(`密码框内容: ${this.pattern}`) // 添加文本组件，显示传递的密码框内容
          .fontSize(30) // 设置字体大小为 30
          .margin({ top: 20 }) // 设置上边距为 20
          .fontWeight(FontWeight.Bold) // 设置字体加粗

        // 返回按钮
        Button() { // 添加按钮组件
          Text('Back') // 添加文本组件，显示 'Back'
            .fontSize(30) // 设置字体大小为 30
            .fontWeight(FontWeight.Bold) // 设置字体加粗
        } // Button 组件结束
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊按钮
        .margin({ top: 20 }) // 设置上边距为 20
        .backgroundColor('#0D9FFB') // 设置背景颜色
        .width('40%') // 设置宽度为 40%
        .height('5%') // 设置高度为 5%
        .onClick(() => { // 设置按钮点击事件回调
          console.info('Succeeded in clicking the "Back" button.'); // 打印日志
          try {
            router.back(); // 调用路由返回方法，返回上一页
            console.info('Succeeded in returning to the first page.'); // 打印日志
          } catch (err) { // 捕获异常
            let code = (err as BusinessError).code; // 获取错误码
            let message = (err as BusinessError).message; // 获取错误信息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`); // 打印错误日志
          }
        }) // onClick 回调结束
      } // Column 组件结束
      .width('100%') // 设置宽度为 100%
    } // Stack 组件结束
    .height('100%') // 设置高度为 100%
  } // build 方法结束
} // Second 组件结束
```
## 插入第一个代码实现的截图
![](1.png)
## 插入第二个代码实现的截图
![](2.png)
