## 3225706029 陈威 实验二

### First_Page

```typescript
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Index {
  @State message: string = 'Index页面';

  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //TextClock组件
        TextClock().margin(20).fontSize(30)
          .format('yyyyMMdd hh:mm:ss')
        //Divider组件.分隔器
        Divider()
        //Search组件
        Search({ placeholder: '输入内容...'})
          .searchButton('搜索')
          .width(300)
          .height(80)
          .placeholderColor(Color.Gray)
          .placeholderFont({ size:24, weight:400})
          .textFont({size:24, weight:400})
        //Textarea组件
        TextArea({
          placeholder: '暂无内容'
        })
          .placeholderFont({ size:24, weight:400,})
          .width(336)
          .height(100)
          .margin(20)
          .fontSize(16)
          .fontColor('#182431')
          .backgroundColor('#FFFFFF')
        //按钮
        Button() {
          Text('Next')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#BD9FFB')
        .width('40%')
        .height('5%')
        //跳转
        .onClick(() => {
          console.info('Succeeded in clicking the Next button.')
          router.pushUrl({ url: 'pages/SecondPage',params:{ src:'我是数据'} }).then(() => {
            console.info('Succeeded in jumping to the second page.')

          }).catch((err: BusinessError) => {
            console.error('Failed to jump to the second page. Code is${err,code}. message is ${err.message}')
          })
        })
        .width('100%')
      }
      .height('100%')
    }

  }
}
```

![](C:\Users\Lulualways\AppData\Roaming\marktext\images\2025-04-07-11-54-43-d8cbfd2a-661a-4d73-bb1e-2cb92e3664c1.png)
