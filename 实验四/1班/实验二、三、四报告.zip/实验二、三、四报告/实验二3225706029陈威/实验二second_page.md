## 3225706029 陈威 实验二

### Second_Page

```typescript
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Second {
  @State message: string = 'SecondPage';
  //传参
  @State src: string = (router.getParams() as Record<string, string>)?.src;
  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)

        Text(this.src)
          .fontSize(30)
        Button() {
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#BD9FFB')
        .width('40%')
        .height('5%')
        .onClick(() => {
          console.info('Succeeded in clicking the Back button')
          try {
            router.back()
            console.info('Succeeded in returning to the first page.')
          }catch(err) {
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            console.error('Failed to return to the first page. Code is ${code}. message is ${message}')
          }
        })
      }
      .width('100%')
    }
    .height('100%')

  }
}
```

![](C:\Users\Lulualways\AppData\Roaming\marktext\images\2025-04-07-11-54-56-5d66e53e-89fe-459b-9ab0-50fc11103ca4.png)
