# 实验三报告

> 学号：<3225706015>
> 
> 姓名：<郭佳欣>
> 
> 指导老师：<张凯斌>
> 
> 实验日期：<2025-03-23>

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；
  - 注意：UML图只是OOAD中的一部分（代码相关的部分），并不是OOAD的全部。例如：
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习；

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；
  - <font color=red>实验步骤部分需严格按模板要求撰写；</font>
  - <font color=red>提交时删除掉上文中的“UML提纲.png“图片；</font>

## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图

<img
src="D:\vscode\实验三\用例图.png">

#### 1.2 用例规约

#### 1.2.1 初始化数据库

#### 1.2.1.1 基本信息
| 项目 | 说明 |
|------|------|
| **用例名称** | 初始化数据库 |
| **参与者** | 系统管理员 |
| **触发条件** | 系统启动时自动执行 |
| **前置条件** | 无 |
| **后置条件** | 数据库和表结构准备就绪 |

#### 1.2.1.2 基本事件流
1. 系统调用`RdbUtil.setGlobalContext()`设置上下文
2. 调用`AccountTable.initDatabase()`方法
3. 执行`AccountData.SQL_CREATE_TABLE`建表语句
4. 显示"数据库初始化成功"状态

#### 1.2.1.3 异常事件流
- **E1: 上下文未设置**
  1. 系统显示"Context not set"错误
  2. 终止初始化流程

- **E2: 数据库初始化失败**
  1. 记录错误日志
  2. 显示"数据库初始化失败"状态

#### 1.2.2 添加学生信息

#### 1.2.2.1 基本信息
| 项目 | 说明 |
|------|------|
| **用例名称** | 添加学生选课信息 |
| **参与者** | 管理员 |
| **触发条件** | 管理员点击"添加"按钮 |
| **前置条件** | 数据库已初始化 |
| **后置条件** | 新增学生记录 |

#### 1.2.2.2 基本事件流
1. 管理员填写表单字段：
   - 学号(student_id)
   - 姓名(student_name)
   - 课程(course)
   - 学分(credit)
   - 性别(gender)
2. 点击"添加"按钮
3. 系统执行输入验证(`validateInput()`)
4. 调用`AccountTable.addAccount()`
5. 显示操作结果

#### 1.2.2.3 异常事件流
- **E1: 字段验证失败**
  1. 显示"请填写所有字段"或"学分必须是数字"
  2. 返回表单填写状态

- **E2: 数据库插入失败**
  1. 显示"添加失败: [错误详情]"
  2. 保留已输入数据

#### 1.2.3. 删除学生信息

#### 1.2.3.1 基本信息
| 项目 | 说明 |
|------|------|
| **用例名称** | 删除学生信息 |
| **参与者** | 管理员 |
| **触发条件** | 管理员点击"删除"按钮 |
| **前置条件** | 数据库已初始化 |
| **后置条件** | 指定学生记录被删除 |

#### 1.2.3.2 基本事件流
1. 输入要删除的学生学号
2. 点击"删除"按钮
3. 调用`AccountTable.deleteAccount()`
4. 显示删除记录数

#### 1.2.3.3 异常事件流
- **E1: 学号为空**
  1. 显示"请输入学号"
  2. 返回输入状态

- **E2: 记录不存在**
  1. 显示"未找到该学号记录"
  2. 清空输入字段

#### 1.2.4. 更新学生信息

#### 1.2.4.1 基本信息
| 项目 | 说明 |
|------|------|
| **用例名称** | 更新学生信息 |
| **参与者** | 管理员 |
| **触发条件** | 管理员点击"更新"按钮 |
| **前置条件** | 数据库已初始化 |
| **后置条件** | 学生记录被更新 |

#### 1.2.4.2 基本事件流
1. 填写完整表单（必须包含学号）
2. 点击"更新"按钮
3. 执行输入验证
4. 调用`AccountTable.updateAccount()`
5. 显示更新记录数

#### 1.2.4.3 异常事件流
- **E1: 学号不存在**
  1. 显示"更新失败: Account not found"
  2. 清空表单

#### 1.2.5. 查询学生信息

#### 1.2.5.1 基本信息
| 项目 | 说明 |
|------|------|
| **用例名称** | 查询学生信息 |
| **参与者** | 管理员 |
| **触发条件** | 管理员点击"查询"按钮 |
| **前置条件** | 数据库已初始化 |
| **后置条件** | 显示查询结果 |

#### 1.2.5.2 基本事件流
1. 点击"查询"按钮
2. 调用`AccountTable.queryAllAccounts()`
3. 格式化查询结果
4. 在Scroll组件中显示

#### 1.2.5.3 异常事件流
- **E1: 查询失败**
  1. 显示"查询失败: [错误详情]"

- **E2: 无数据**
  1. 显示"没有找到任何记录"

#### 非功能性需求

1. **数据有效性**：
   - 学分字段必须为数字
   - 所有字段不能为空

2. **操作反馈**：
   - 所有数据库操作需显示成功/失败状态
   - 查询结果需格式化显示

3. **界面交互**：
   - 操作后自动清空输入字段（成功时）
   - 错误时保留原输入内容

4. **性能要求**：
   - 数据库操作响应时间<1秒
   - 支持50条以上记录流畅显示

### 数据字典

| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| student_id | TEXT | PRIMARY KEY | 学生学号 |
| student_name | TEXT | NOT NULL | 学生姓名 |
| course | TEXT | NOT NULL | 课程名称 |
| credit | INTEGER | NOT NULL | 课程学分 |
| gender | TEXT | NOT NULL | 学生性别 |

### 2. 总体设计

#### 2.1 类图（静态视图）

<img
src="D:\vscode\实验三\类图（静态）.png">

#### 2.2 活动图（动态视图）

<img
src="D:\vscode\实验三\活动图.png">

### 3. 详细设计

#### 3.1 详细类图

<img
src="D:\vscode\实验三\详细类图.png">

#### 3.2 包图

<img
src="D:\vscode\实验三\包图.png">

#### 4.1 代码实现

#RdbUtil.ts
```typescript {.line-numbers}
import relationalStore from '@ohos.data.relationalStore';
import common from '@ohos.app.ability.common';

export class RdbUtil {
  private rdbStore: relationalStore.RdbStore | null = null;
  private context: common.Context | null = null;

  // 设置全局上下文
  setGlobalContext(context: common.Context) {
    this.context = context;
  }

  // 初始化数据库
  initDatabase(config: relationalStore.StoreConfig, callback: (err: Error) => void) {
    if (!this.context) {
      callback(new Error('Context not set'));
      return;
    }

    relationalStore.getRdbStore(this.context, config, (err, store) => {
      if (err) {
        callback(err);
        return;
      }
      this.rdbStore = store;
      callback(null);
    });
  }

  // 创建RdbPredicates对象
  createPredicates(table: string): relationalStore.RdbPredicates {
    return new relationalStore.RdbPredicates(table);
  }

  // 创建ValuesBucket对象
  createValuesBucket(): relationalStore.ValuesBucket {
    return {};
  }

  // 执行SQL语句
  executeSql(sql: string, args: Array<relationalStore.ValueType> = [], callback: (err: Error) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'));
      return;
    }
    this.rdbStore.executeSql(sql, args, callback);
  }

  // 查询数据
  query(predicates: relationalStore.RdbPredicates,
    columns?: Array<string>,
    callback?: (err: Error, resultSet: relationalStore.ResultSet) => void) {
    if (!this.rdbStore) {
      callback?.(new Error('RdbStore is not initialized'), null);
      return;
    }
    if (callback) {
      this.rdbStore.query(predicates, columns, callback);
    }
  }

  // 插入数据
  insert(table: string, values: relationalStore.ValuesBucket,
    callback: (err: Error, rowId: number) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'), -1);
      return;
    }
    this.rdbStore.insert(table, values, callback);
  }

  // 更新数据
  update(values: relationalStore.ValuesBucket,
    predicates: relationalStore.RdbPredicates,
    callback: (err: Error, rowsAffected: number) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'), 0);
      return;
    }
    this.rdbStore.update(values, predicates, callback);
  }

  // 删除数据
  delete(predicates: relationalStore.RdbPredicates,
    callback: (err: Error, rowsAffected: number) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'), 0);
      return;
    }
    this.rdbStore.delete(predicates, callback);
  }
}
```
#AccountData.ts
```typescript {.line-numbers}
import relationalStore from '@ohos.data.relationalStore';

export class AccountData {
  // 数据库配置
  static STORE_CONFIG: relationalStore.StoreConfig = {
    name: 'AccountData.db',
    securityLevel: relationalStore.SecurityLevel.S1,
    encrypt: false
  };

  // 表名
  static TABLE_NAME: string = 'account';

  // 创建表的SQL语句
  static SQL_CREATE_TABLE: string = `
    CREATE TABLE IF NOT EXISTS ${AccountData.TABLE_NAME} (
      student_id TEXT PRIMARY KEY,
      student_name TEXT NOT NULL,
      course TEXT NOT NULL,
      credit INTEGER NOT NULL,
      gender TEXT NOT NULL
    )`;
}
```
#AccountTable.ts
```typescript {.line-numbers}
import { AccountData } from './AccountData';
import { RdbUtil } from '../common/RdbUtil';

export class AccountTable {
  private rdbUtil: RdbUtil;

  constructor(rdbUtil: RdbUtil) {
    this.rdbUtil = rdbUtil;
  }

  // 初始化数据库
  initDatabase(callback: (err: Error) => void) {
    this.rdbUtil.initDatabase(AccountData.STORE_CONFIG, (err) => {
      if (err) {
        callback(err);
        return;
      }
      // 创建表
      this.rdbUtil.executeSql(AccountData.SQL_CREATE_TABLE, [], callback);
    });
  }

  // 添加学生选课信息
  addAccount(studentId: string, studentName: string, course: string, credit: number, gender: string,
    callback: (err: Error, rowId: number) => void) {
    const values = this.rdbUtil.createValuesBucket();
    values.student_id = studentId;
    values.student_name = studentName;
    values.course = course;
    values.credit = credit;
    values.gender = gender;

    this.rdbUtil.insert(AccountData.TABLE_NAME, values, callback);
  }

  // 删除学生选课信息
  deleteAccount(studentId: string, callback: (err: Error, rowsAffected: number) => void) {
    const predicates = this.rdbUtil.createPredicates(AccountData.TABLE_NAME);
    predicates.equalTo('student_id', studentId);
    this.rdbUtil.delete(predicates, callback);
  }

  // 更新学生选课信息
  updateAccount(studentId: string, studentName: string, course: string, credit: number, gender: string,
    callback: (err: Error, rowsAffected: number) => void) {
    const predicates = this.rdbUtil.createPredicates(AccountData.TABLE_NAME);
    predicates.equalTo('student_id', studentId);

    const values = this.rdbUtil.createValuesBucket();
    values.student_name = studentName;
    values.course = course;
    values.credit = credit;
    values.gender = gender;

    this.rdbUtil.update(values, predicates, callback);
  }

  // 查询所有学生选课信息
  queryAllAccounts(callback: (err: Error, result: Array<AccountInfo>) => void) {
    const predicates = this.rdbUtil.createPredicates(AccountData.TABLE_NAME);

    this.rdbUtil.query(predicates, null, (err, resultSet) => {
      if (err) {
        callback(err, null);
        return;
      }

      const accounts: Array<AccountInfo> = [];
      while (resultSet.goToNextRow()) {
        accounts.push({
          studentId: resultSet.getString(resultSet.getColumnIndex('student_id')),
          studentName: resultSet.getString(resultSet.getColumnIndex('student_name')),
          course: resultSet.getString(resultSet.getColumnIndex('course')),
          credit: resultSet.getLong(resultSet.getColumnIndex('credit')),
          gender: resultSet.getString(resultSet.getColumnIndex('gender'))
        });
      }
      resultSet.close();
      callback(null, accounts);
    });
  }

  // 根据学号查询学生选课信息
  queryAccountById(studentId: string, callback: (err: Error, account: AccountInfo) => void) {
    const predicates = this.rdbUtil.createPredicates(AccountData.TABLE_NAME);
    predicates.equalTo('student_id', studentId);

    this.rdbUtil.query(predicates, null, (err, resultSet) => {
      if (err) {
        callback(err, null);
        return;
      }

      if (resultSet.goToFirstRow()) {
        const account = {
          studentId: resultSet.getString(resultSet.getColumnIndex('student_id')),
          studentName: resultSet.getString(resultSet.getColumnIndex('student_name')),
          course: resultSet.getString(resultSet.getColumnIndex('course')),
          credit: resultSet.getLong(resultSet.getColumnIndex('credit')),
          gender: resultSet.getString(resultSet.getColumnIndex('gender'))
        };
        resultSet.close();
        callback(null, account);
      } else {
        resultSet.close();
        callback(new Error('Account not found'), null);
      }
    });
  }
}

interface AccountInfo {
  studentId: string;
  studentName: string;
  course: string;
  credit: number;
  gender: string;
}
```
#Index.ets
```typescript {.line-numbers}
import { AccountData } from '../database/AccountData';
import { AccountTable } from '../database/AccountTable';
import { RdbUtil } from '../common/RdbUtil';

@Entry
@Component
struct Index {
  @State message: string = '数据库操作';
  @State studentId: string = '';
  @State studentName: string = '';
  @State course: string = '';
  @State credit: string = '';
  @State gender: string = '';
  @State queryResult: string = '';

  private rdbUtil: RdbUtil = new RdbUtil();
  private accountTable: AccountTable = new AccountTable(this.rdbUtil);

  aboutToAppear() {
    // 设置全局上下文
    this.rdbUtil.setGlobalContext(getContext(this));

    // 初始化数据库
    this.accountTable.initDatabase((err) => {
      if (err) {
        console.error('Failed to initialize database');
        this.message = '数据库初始化失败';
      } else {
        this.message = '数据库初始化成功';
      }
    });
  }

  build() {
    Column() {
      // 添加"学生管理系统"标题
      Text('学生管理系统')
        .fontSize(30)
        .fontWeight(FontWeight.Bold)
        .margin(20)

      Text(this.message)
        .fontSize(20)
        .margin(10)

      // 输入字段（已改为中文提示）
      TextInput({ placeholder: '学号' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.studentId = value;
        })

      TextInput({ placeholder: '学生姓名' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.studentName = value;
        })

      TextInput({ placeholder: '课程名称' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.course = value;
        })

      TextInput({ placeholder: '学分' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.credit = value;
        })

      TextInput({ placeholder: '性别' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.gender = value;
        })

      // 操作按钮
      Row() {
        Button('添加')
          .onClick(() => {
            this.addAccount();
          })
          .margin(5)

        Button('删除')
          .onClick(() => {
            this.deleteAccount();
          })
          .margin(5)
      }

      Row() {
        Button('更新')
          .onClick(() => {
            this.updateAccount();
          })
          .margin(5)

        Button('查询')
          .onClick(() => {
            this.queryAllAccounts();
          })
          .margin(5)
      }

      // 查询结果显示
      Scroll() {
        Text(this.queryResult)
          .fontSize(16)
          .width('90%')
          .margin(10)
      }
      .height(200)
      .width('100%')
      .margin(10)
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Start)
  }

  // 添加账户
  private addAccount() {
    if (!this.validateInput()) {
      return;
    }

    const creditNum = parseInt(this.credit);
    this.accountTable.addAccount(
      this.studentId,
      this.studentName,
      this.course,
      creditNum,
      this.gender,
      (err, rowId) => {
        if (err) {
          this.message = `添加失败: ${err.message}`;
          return;
        }
        this.message = `添加成功, 行ID: ${rowId}`;
        this.clearInputs();
      }
    );
  }

  // 删除账户
  private deleteAccount() {
    if (!this.studentId) {
      this.message = '请输入学号';
      return;
    }

    this.accountTable.deleteAccount(this.studentId, (err, rowsAffected) => {
      if (err) {
        this.message = `删除失败: ${err.message}`;
        return;
      }
      this.message = `已删除 ${rowsAffected} 条记录`;
      this.clearInputs();
    });
  }

  // 更新账户
  private updateAccount() {
    if (!this.validateInput()) {
      return;
    }

    const creditNum = parseInt(this.credit);
    this.accountTable.updateAccount(
      this.studentId,
      this.studentName,
      this.course,
      creditNum,
      this.gender,
      (err, rowsAffected) => {
        if (err) {
          this.message = `更新失败: ${err.message}`;
          return;
        }
        this.message = `已更新 ${rowsAffected} 条记录`;
        this.clearInputs();
      }
    );
  }

  // 查询所有账户
  private queryAllAccounts() {
    this.accountTable.queryAllAccounts((err, accounts) => {
      if (err) {
        this.message = `查询失败: ${err.message}`;
        return;
      }

      if (accounts.length === 0) {
        this.queryResult = '没有找到任何记录';
        return;
      }
      let result = '数据库中的学生信息:\n\n';
      accounts.forEach(account => {
        result += `学号: ${account.studentId}\n`;
        result += `姓名: ${account.studentName}\n`;
        result += `课程: ${account.course}\n`;
        result += `学分: ${account.credit}\n`;
        result += `性别: ${account.gender}\n\n`;
      });

      this.queryResult = result;
      this.message = `找到 ${accounts.length} 条记录`;
    });
  }

  // 验证输入
  private validateInput(): boolean {
    if (!this.studentId || !this.studentName || !this.course || !this.credit || !this.gender) {
      this.message = '请填写所有字段';
      return false;
    }

    if (isNaN(parseInt(this.credit))) {
      this.message = '学分必须是数字';
      return false;
    }

    return true;
  }

  // 清空输入
  private clearInputs() {
    this.studentId = '';
    this.studentName = '';
    this.course = '';
    this.credit = '';
    this.gender = '';
  }
}
```
#### 4.2 结果验证
一开始点击查询，数据库中没有结果
<img
src="D:\vscode\实验三\1.png">
插入两条数据后，再点击查询
<img
src="D:\vscode\实验三\2.png">
<img
src="D:\vscode\实验三\3.png">
<img
src="D:\vscode\实验三\4.png">
输入学号001，更新相关信息后，点击查询
<img
src="D:\vscode\实验三\5.png">
<img
src="D:\vscode\实验三\6.png">
输入学号002，点击删除，再点击查询
<img
src="D:\vscode\实验三\7.png">
<img
src="D:\vscode\实验三\8.png">