#Index.ets
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';
@Entry
@Component
struct Index {
  @State message: string = 'Hello';
  // 组件的构建方法，用于定义组件的 UI 结构和布局
  build() {
    // 创建一个 Column 布局容器，用于垂直排列其子组件
    Column() {
      // 创建一个 TextVisual Studio Code 组件，显示提示文字
      Text('你好')
        .fontSize(40) // 字号大一点
        .fontColor('#ff4c90f3') //
DatePicker({
  start:new Date('1970-1-1'),
  end:new Date('2100-1-1'),
  selected:new Date('2025-3-18')
})
      // 创建一个 Row 布局容器，用于水平排列其子组件
      Row() {
        // 创建一个 Column 布局容器，用于垂直排列其子组件，该 Column 是上面 Row 的子组件
        Column() {
          // 创建一个 Text 组件，显示状态变量 message 的值
          Text(this.message)
            // 设置 Text 组件的字体大小为 50
            .fontSize(50)
              // 设置 Text 组件的字体加粗
            .fontWeight(FontWeight.Bold)
          // 创建一个 Button 组件，用于触发特定操作

          Button() {
            // 在 Button 组件内部创建一个 Text 组件，显示文本 'Next'
            Text('Next')
              // 设置 Text 组件的字体大小为 30
              .fontSize(30)
                // 设置 Text 组件的字体加粗
              .fontWeight(FontWeight.Bold)
          }
          // 设置 Button 组件的形状为胶囊形状
          .type(ButtonType.Capsule)
          // 设置 Button 组件的外边距，这里只设置了顶部外边距为 20
          .margin({
            top: 20
          })
          // 设置 Button 组件的背景颜色为 '#0D9FFB'
          .backgroundColor('#0D9FFB')
          // 设置 Button 组件的宽度为父容器宽度的 40%
          .width('40%')
          // 设置 Button 组件的高度为父容器高度的 5%
          .height('5%')
          // 为 Button 组件添加点击事件监听器，当按钮被点击时执行回调函数
          .onClick(() => {
            // 打印一条信息到控制台，表示成功点击了 'Next' 按钮
            console.info('Succeeded in clicking the ‘Next’ button.')
            // 使用 router 对象的 pushUrl 方法跳转到指定页面，这里是 'pages/Second'
            router.pushUrl({ url: 'pages/Second' }).then(() => {
              // 跳转成功后的回调函数，这里为空
            })
              .catch((err: BusinessError) => {
                // 跳转失败时的回调函数，打印错误信息，包含错误码和错误消息
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
              })
          })
        }
        // 设置 Column 组件的宽度为父容器宽度的 100%
        .width('100%')
      }
      // 设置 Row 组件的高度为父容器高度的 100%
      .height('100%')
    }
    // 设置 Column 组件的高度为父容器高度的 100%
    .height('100%')
  }
}
```
#Second.etc
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Second {
  @State name: string = '';
  @State phone: string = '';
  @State gender: string = '男';
  @State date: Date = new Date();

  build() {
    Column() {
      TextInput({
        placeholder: '请输入姓名',

      })
        //设置无输入时的提示文本
        .placeholderColor(Color.Grey)
        .placeholderFont({size:14, weight:400})
        .caretColor(Color.Blue)
        .width(300)
        .height(40)
        .margin(20)
        .fontColor(Color.Black)
Text('分割线').fontSize(29)
      Divider()
        .strokeWidth(15)
        .color(0x2788D9)
        .lineCap(LineCapStyle.Round)
      Text('分割线').fontSize(29)
      TextInput({
        placeholder: '请输入电话',})
        .placeholderColor(Color.Grey)
        .placeholderFont({size:14, weight:400})
        .caretColor(Color.Blue)
        .width(300)
        .height(40)
        .margin(20)
        .fontColor(Color.Black)
      Button() {
        Text('Back')
          .fontSize(30)
          .fontWeight(FontWeight.Bold)
      }
      .type(ButtonType.Capsule)
      .margin({ top: 20 })
      .backgroundColor('#0D9FFB')
      .width('40%')
      .height('5%')
      .onClick(() => {
        console.info('Succeeded in clicking the ‘Back’ button.')
        try {
          router.back()
          console.info('Succeeded in returning to the first page.')
        } catch (err) {
          let code = (err as BusinessError).code;
          let message = (err as BusinessError).message;
          console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
        }
      })
    }
    .width('100%')
    .height('100%')
  }
}
```
##运行结果图片
<img
src="D:\vscode\3225706015郭佳欣第二次实验\111.png">
<img
src="D:\vscode\3225706015郭佳欣第二次实验\222.png">
<img
src="D:\vscode\3225706015郭佳欣第二次实验\333.png">
