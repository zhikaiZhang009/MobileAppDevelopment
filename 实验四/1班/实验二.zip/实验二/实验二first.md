## 3225706020 张涵韬 实验二

### First_Page

```typescript{.line-numbers}
//导入页面路由模块  
import  router  from '@ohos.router';  
import { BusinessError } from '@kit.BasicServicesKit';  

@Entry  
@Component  
struct Index {  
  @State message: string = 'FIRST'  
  @State inputValue: string = ''  
  @State selectedDate: string = ''  

  build() {  
    Column() {  
      Progress({ value: 20, total: 100, type: ProgressType.Linear }).width(150)  

      TextClock()  
        .margin(10)  
        .fontSize(30)  
        .format('yyyy/MM/dd hh:mm:ss')  

      Search({placeholder: '输入内容...'})  
        .searchButton('搜索')  
        .width(300)  
        .height(60)  
        .placeholderColor(Color.Grey)  
        .placeholderFont({size: 30,weight: 500})  
        .textFont({size: 30,weight: 500})  



      // 新增输入组件  
      TextInput({ placeholder: '输入参数' })  
        .placeholderFont({ size:40,weight:500})  
        .width(300)  
        .height(100)  
        .margin(10)  
        .fontSize(40)  
        .onChange((value: string) => {  
          this.inputValue = value  
        })  

      // 新增日期组件  
      DatePicker({  
        start: new Date('1970-1-1'),  
        end: new Date('2100-12-31')  
      })  
        .margin(40)  
        .onChange((date: DatePickerResult) => {  
          this.selectedDate = `${date.year}-${date.month}-${date.day}`  
        })  

      Row() {  
        Column() {  
          Text(this.message)  
            .fontSize(40)  
            .fontWeight(FontWeight.Bold)  

          Button() {  
            Text('Next').fontSize(30)  
          }  
          .onClick(() => {  
            router.pushUrl({  
              url: 'pages/Second_Page',  
              params: {  
                src: '基础数据',  
                inputParam: this.inputValue,  
                dateParam: this.selectedDate  
              }  
            }).then(() => {  
              console.info('Succeeded in jumping to the second page.')  

            }).catch((err: BusinessError) => {  
              console.error(`Failed to return to the first page. Code is ${err.code}, message is ${err.message}`)  
            })  
          })  
        }  
        .width('100%')  
      }  
    }    .height('100%')  

  }  
}
```
