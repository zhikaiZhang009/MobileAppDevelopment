## 3225706020 张涵韬 实验二

### Second_Page

```typescript{.line-numbers}
import router from '@ohos.router';  
import { BusinessError } from '@kit.BasicServicesKit';  

@Entry  
@Component  
struct TwoPage {  
  @State message: string = 'TWO'  
  @State params: Record<string, string> = router.getParams() as Record<string, string>  

  build() {  
    Column() {  
      // 标题区域  
      Column() {  
        Text(this.message)  
          .fontSize(40)  
          .fontWeight(FontWeight.Bold)  
          .fontColor('#1A1A1A')  
          .margin({ top: 20 })  

        Divider()  
          .strokeWidth(2)  
          .color('#8D9FFB')  
          .margin({ top: 10, bottom: 20 })  
      }  

      // 参数展示区  
      Column() {  
        Text('数据列表')  
          .fontSize(35)  
          .fontWeight(FontWeight.Medium)  
          .textAlign(TextAlign.Start)  
          .width('90%')  
          .margin({ bottom: 20 })  

        Column() {  
          this.buildParamItem('基础参数', this.params?.src)  
          this.buildParamItem('输入参数', this.params?.inputParam)  
          this.buildParamItem('日期参数', this.params?.dateParam)  
        }  
        .padding(20)  
        .backgroundColor('#F5F7FA')  
        .borderRadius(12)  
        .width('90%')  
      }  

      // 返回按钮  
      Button() {  
        Text('返回首页')  
          .fontSize(30)  
          .fontColor('#FFF')  
      }  
      .type(ButtonType.Capsule)  
      .margin({ top: 40 })  
      .width('50%')  
      .height(45)  
      .backgroundColor('#8D9FFB')  
      .onClick(() => this.handleBack())  
    }  
    .padding(20)  
    .width('100%')  
    .height('100%')  
    .backgroundColor('#FFFFFF')  

  }  

  @Builder  
  buildParamItem(label: string, value: string) {  
    Row() {  
      Text(label + '：')  
        .fontSize(28)  
        .fontColor('#666')  
        .flexShrink(0)  

      Text(value || '--')  
        .fontSize(28)  
        .fontColor('#333')  
        .maxLines(1)  
        .textOverflow({ overflow: TextOverflow.Ellipsis })  
    }  
    .margin(30)  
    .width('100%')  

  }  

  private handleBack() {  
    try {  
      router.back()  
      console.info('返回成功')  
    } catch (err) {  
      const error = err as BusinessError  
      console.error(`返回失败 [${error.code}] ${error.message}`)  
    }  
  }}
```
