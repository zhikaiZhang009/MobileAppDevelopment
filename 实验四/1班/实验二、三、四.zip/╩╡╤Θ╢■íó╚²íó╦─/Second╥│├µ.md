## 3225706022 董雄逵 实验二

### Second_Page

```typescript{.line-numbers}
import { router } from '@kit.ArkUI';

import {BusinessError} from '@kit.BasicServicesKit';

@Entry  
@Component  
struct Second {  
@State message: string = 'Second页面';  
@State src: string = (router.getParams() as Record<string, string>)?.src;

build() {  
Row(){  
Column(){

Text(this.message)  
.fontSize(50)  
.fontWeight(FontWeight.Bold)  
Text(this.src)  
.fontSize(30)  
Button(){  
Text('back')  
.fontSize(50)  
.fontWeight(FontWeight.Bold)  
}

.type(ButtonType.Capsule)  
.margin({  
top:20  
})  
.backgroundColor('#0D9FFB')  
.width('40%')  
.height('10%')

.onClick(()=>{

console.info('Succeeded in clicking the back button')  
try{

router.back()  
console.info('Succeeded in jumping to the Index page. ')  
}catch(err) {  
let code = (err as BusinessError).code;  
let message = (err as BusinessError).message;

console.error('Failed to return to the Index page. Code is {code}, message is {message}')  
}  
})  
}

.width('100%')  
}  
.height('100%')  
}  
}
```
