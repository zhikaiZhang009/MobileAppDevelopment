## 3225706022 董雄逵 实验二

### First_Page

```typescript{.line-numbers}

import { router } from '@kit.ArkUI';  
import {BusinessError} from '@kit.BasicServicesKit';  
@Entry  
@Component  

struct Index {  
 @State message: string = 'First页面';  

 build() {  
 Row() {  
 Column() {  
 ColumnSplit() {  
 Badge({  
 value: '1',  
 position: BadgePosition.RightTop,  
 style: { badgeSize: 16, badgeColor: '#FA2A2D' }  
 })  
 {  
 Text(this.message)  
 .width('60%').height('15%').backgroundColor(0xAFEEEE)  
 .fontSize(50)  
 .fontWeight(FontWeight.Bold)  
 }  
 Text('1').width('60%').height('5%').backgroundColor(0xF5DEB3)  
 Text('2').width('60%').height('5%').backgroundColor(0xD2B48C)  

 }  
 Flex({direction:FlexDirection.Row}){  
 Text('A').width('40%').height(30).backgroundColor(0xF5DEB3)  
 Text('B').width('40%').height(30).backgroundColor(0XD2B48C)  
 }  
 .width('100%').height('10%').backgroundColor(0xAFEEEE).padding('5%')  

 Button() {  
 Text('next')  
 .fontSize(50)  
 .fontWeight(FontWeight.Bold)  
 }  
 .type(ButtonType.Capsule)  
 .margin({  
 top: 20  
 })  
 .backgroundColor('#0D9FFB')  
 .width('40%')  
 .height('10%')  
 .onClick(() => {  
 console.info('Succeeded in clicking the next button.')  
 router.pushUrl({ url: 'pages/Second',params:{src:'First页面传来的数据'}, }).then(() => {  
 console.info('Succeeded in jumping to the Second page. ')  

 })  
 .catch((err: BusinessError) => {  
 console.error('Failed to jump to the second page.Code is ${err.code},message is ${err.message}')  
 })  
 })  
 }  
 .width('100%')  
 }  
 .height('100%')  
 }  
}
