# <center> <font face="仿宋">实验二实验报告</font></center>
  <center><font face ="楷体">3225706010 空数1班 黄境琴</font></center>   
  
  ***
### 实验过程与内容
#### 一、增加组件

<center>新增组件清单</center>   

| 序号 | 组件名称 | 所在页面 | 功能说明 |
|:-----:|:-------:|:-------:|:--------:|
|1|TextClock| Index  |动态时间显示 |
|2|Divider|Index、Secnd|分隔不同内容块/内容元素|
|3|LoadingProgress|Index|显示加载动效|
|4|TextInput | Index | 单行文本输入 |
|5| Search|Second |内容搜索功能 |
|6|Row|Second|沿水平方向布局|
|7|TextTimer|Second| 倒计时功能  |
|8|SideBarContainer|Second|侧边导航容器 |


#### 1.各组件详细说明与展示
- #### **TextClock**
  TextClock组件通过文本将当前系统时间显示在设备上，支持不同地区的时间显示，最高精确到秒级

```Json5 {.line-numbers}
// 创建垂直布局容器
Column() {  // Column组件开始括号，用于包裹内部组件
  // 创建动态时间显示组件
  TextClock()  // TextClock组件初始化
    .fontSize(20)  // 设置时钟字体大小
    .fontColor('#000000')  // 设置纯黑色字体颜色
    .format('yyyy年MM月dd日     HH:mm:ss')  // 设置日期时间格式
}  // Column组件结束括号

// 设置容器样式
.height(60)  // 设置容器高度为60vp
.width('90%')  // 设置容器宽度为父容器的90%
.backgroundColor('#F8FAFF')  // 设置浅蓝背景色
.borderRadius(20)  // 设置20vp圆角半径（形成圆角矩形效果）
.shadow({  // 设置阴影效果
  radius: 8,  // 阴影模糊半径8vp（控制阴影模糊程度）
  color: '#152E6D1A',  // 带透明度的深蓝色（最后两位1A表示约10%透明度）
  offsetX: 2,  // 水平向右偏移2vp
  offsetY: 4  // 垂直向下偏移4vp
})  // shadow属性设置结束括号
.margin({  // 设置外边距
  top: 20,  // 顶部外边距20vp（与上方元素间隔）
  bottom: 25  // 底部外边距25vp（与下方元素间隔）
})  // margin属性设置结束括号
.justifyContent(FlexAlign.Center)  // 垂直方向居中对齐（控制子组件在Column中的纵向位置）
.alignItems(HorizontalAlign.Center)  // 水平方向居中对齐（控制子组件在Column中的横向位置）
```

- #### **Divider**
  Divider是分隔器组件，用于分隔不同内容块/内容元素
  
```Json5 {.line-numbers}
  // 创建水平分隔线组件
 Divider()  // Divider组件初始化
  .strokeWidth(2)  // 设置分隔线粗细为2vp
  .color('#2788D9')  // 设置分隔线颜色为品牌蓝色
  .margin({  // 设置外边距
    bottom: 30,  // 底部间距30vp（与下方元素间隔）
    left: 20,  // 左侧间距20vp（保持左右对称留白）
    right: 20  // 右侧间距20vp（适配屏幕边缘间距）
  })  // margin属性设置结束括号

```

- #### **LoadingProgress**
  LoadingProgress是用于显示加载动效的组件

```Json5 {.line-numbers}
 // 创建加载进度指示器组件
 LoadingProgress()  // 初始化加载动画组件（默认显示旋转圆圈）
  .color('#2788D9')  // 设置加载动画颜色为品牌蓝色（与分隔线颜色保持设计系统统一）
  .size({  // 设置组件尺寸
    width: '70%',  // 宽度设为父容器的70%（
    height: 63  // 固定高度63vp
  })  // size属性设置结束括号
  .margin({  // 设置外边距
    bottom: 25  // 底部间距25vp（与下方元素保持安全距离）
  })  // margin属性设置结束括号

```

- #### **TextInput**
  TextInput是单行文本输入框组件

```Json5 {.line-numbers}
// 用户名输入框组件
TextInput({ placeholder: '请输入用户名...' })  // 创建文本输入框
  .onChange((value: string) => {            // 注册输入变化监听
    this.username = value                   // 更新用户名状态变量
  })                                        // onChange回调函数结束的右括号
  .placeholderColor('#999999')              // 设置提示文字颜色（标准灰色）
  .placeholderFont({                        // 设置提示文字字体样式
    size: 16,                               // 字体大小16fp
    weight:400                              // 字体权重400
  })                                        // placeholderFont对象参数结束的右括号
  .caretColor('#2788D9')                    // 设置输入光标颜色（品牌主色）
  .height(56)                               // 设置组件高度：8pt栅格56vp
  .margin(13)                               // 设置外边距13vp（四边等距）
  .fontSize(18)                             // 设置输入文字大小18fp
  .fontColor('#333333')                     // 设置文字颜色（深灰色）
  .borderRadius(8)                          // 设置8vp圆角半径


// 密码输入框组件
TextInput({ placeholder: '请输入密码...' })  // 创建密码输入框
  .onChange((value: string) => {            // 注册输入变化监听
    this.password = value                   // 更新密码状态变量
  })                                        // onChange回调函数结束的右括号
  .height(56)                               // 设置组件高度：8pt栅格56vp
  .margin(13)                               // 设置外边距13vp（四边等距）
  .fontSize(18)                             // 设置输入文字大小18fp
  .type(InputType.Password)                 // 设置输入类型为密码（星号隐藏）
  .maxLength(9)                             // 限制最大输入长度9字符
  .showPasswordIcon(true)                   // 显示密码可见切换图标
  .borderRadius(8)                          //设置8vp圆角半径

```

- #### **Search**
   Search是搜索框组件
```Json5 {.line-numbers}
// 创建搜索框组件
Search({ placeholder: '搜索内容...' })  // 构造函数参数开始，设置提示文本
  .searchButton('搜索')               // 设置搜索按钮文字（参数为字符串）
  .width('90%')                      // 设置宽度为父容器的90%（字符串参数）
  .height(52)                        // 设置固定高度52vp（数值参数）
  .placeholderFont({                 // 设置提示文字样式
    size: 16,                        // 字体大小16fp
    weight:400                       // 字体权重400
  })                                 // placeholderFont对象参数结束的右括号
  .textFont({                        // 设置输入文字样式
    size: 16                         // 字体大小16fp
  })                                 // textFont对象参数结束的右括号
  .margin({                          // 设置外边距
    top: 20,                         // 顶部间距20vp
    bottom: 30                       // 底部间距30vp（与首页统一）
  })                                 // margin对象参数结束的右括号
  .borderRadius(26)                  // 设置26vp圆角
  .backgroundColor('#FFFFFF')        // 设置白色背景
```

- #### **Row**
  Row是沿水平方向布局的容器组件

```Json5 {.line-numbers}
// 创建彩色装饰条组件容器
Row(){  // 主Row容器开始（构造函数参数）
  // 子Row组件集合（5个彩色条）
  Row()  // 第1个彩色条开始
    .width('15%')    // 宽度占父容器的15% 
    .height(10)      // 高度10vp（最短）
    .backgroundColor('#88FF3333')  // 半透明红色（ARGB:88=0.54透明度）

  Row()  // 第2个彩色条开始
    .width('15%') // 宽度占父容器的15% 
    .height(20)      // 高度20vp
    .backgroundColor('#88FF6F00')  // 半透明橙色

  Row()  //  第3个彩色条开始
    .width('15%') // 宽度占父容器的15% 
    .height(30)      // 高度30vp
    .backgroundColor('#88FFD700')  // 半透明金色

  Row()  // 第4个彩色条开始
    .width('15%')   // 宽度占父容器的15% 
    .height(40)      // 高度40vp
    .backgroundColor('#8833CC33')  // 半透明绿色

  Row()  // 第5个彩色条开始
    .width('15%')   // 宽度占父容器的15% 
    .height(50)      // 高度50vp（最高）
    .backgroundColor('#880066FF')  // 半透明蓝色
}  // 主Row容器构造函数参数结束的右括号

// 容器样式设置
.width('50%')       // 设置容器宽度为父容器的50%
.height(60)         // 固定容器高度60vp
.alignItems(VerticalAlign.Bottom)  // 子项底部对齐（产生高度阶梯效果）
.border({           // 边框样式对象参数开始
  width: 1,         // 边框宽度1vp
  color: '#EEEEEE', // 浅灰色边框
  radius: 12        // 12vp圆角半径
})                  // border对象参数结束的右括号
.justifyContent(FlexAlign.Center)  // 主轴居中排列子项
.backgroundColor('#FFFFFF')       // 白色背景（与页面风格统一）
.margin({ bottom: 25 })           // 底部外边距25vp

```

- #### **TextTimer**
  TextTimer是通过文本显示计时信息并控制其计时器状态的组件，TextTimer组件支持绑定一个控制器TextTimerController原来控制文本计时器

```Json5 {.line-numbers}
// 计时器区域开始，使用Column布局组件
Column() { // Column组件的开始括号，用于垂直排列子组件
  // 创建一个TextTimer组件，用于显示计时/倒计时
  TextTimer({controller: this.textTimerController,isCountDown:true,count:30000}) // 初始化TextTimer，controller控制计时器，isCountDown设置倒计时，count设置初始时间30秒（30000毫秒）
    .format('mm:ss.SS') // 设置显示格式为分钟:秒.毫秒
    .fontColor('#1A1A1A') // 设置字体颜色为深灰色
    .fontSize(48) // 设置字体大小为48vp
    .margin({ bottom: 15 })  // 设置底部外边距为15vp

  // 在Column内部创建一个Row布局组件，用于水平排列按钮
  Row(){ // Row组件的开始括号
    // 创建一个“开始”按钮
    Button("开始")
      .width(80) // 设置按钮宽度为80vp
      .height(36) // 设置按钮高度为36vp
      .fontSize(14) // 设置按钮内文字大小为14vp
      .backgroundColor('#2788D9') // 设置按钮背景颜色为蓝色
      .onClick(()=>{ this.textTimerController.start() }) // 设置点击事件，调用textTimerController的start方法开始计时

    // 创建一个“暂停”按钮
    Button("暂停")
      .width(80) // 设置按钮宽度为80vp
      .height(36) // 设置按钮高度为36vp
      .fontSize(14) // 设置按钮内文字大小为14vp
      .backgroundColor('#2788D9') // 设置按钮背景颜色为蓝色
      .margin({left:10,right:10}) // 设置按钮左右外边距为10vp
      .onClick(()=>{ this.textTimerController.pause() }) // 设置点击事件，调用textTimerController的pause方法暂停计时

    // 创建一个“重置”按钮
    Button("重置")
      .width(80) // 设置按钮宽度为80vp
      .height(36) // 设置按钮高度为36vp
      .fontSize(14) // 设置按钮内文字大小为14vp
      .backgroundColor('#2788D9') // 设置按钮背景颜色为蓝色
      .onClick(()=>{ this.textTimerController.reset() }) // 设置点击事件，调用textTimerController的reset方法重置计时器
  } // Row组件的结束括号
} // Column组件的结束括号
.margin({ top:5,bottom: 18 }) // 设置顶部外边距为5vp，底部外边距为18vp
```

- #### **SideBarContainer**
   SideBarContainer是提供侧边栏可以显示和隐藏的侧边栏容器，通过子组件定义侧边栏和内容区  

```Json5 {.line-numbers}

SideBarContainer(SideBarContainerType.Embed){  // 创建一个SideBarContainer组件，类型为Embed
  
  Column(){ // 在SideBarContainer内部创建一个Column布局组件，用于垂直排列子组件
    
    Text('菜单1').fontSize(15).padding(8) // 添加一个Text组件，显示文本“菜单1”，设置字体大小为15vp，内边距为8vp
    
    Text('菜单2').fontSize(15).padding(8) // 添加另一个Text组件，显示文本“菜单2”，设置字体大小为15vp，内边距为8vp
  } // 第一个Column的结束括号
  .width('100%') // 设置第一个Column的宽度为100%
  .backgroundColor('#F0F4FF') // 设置第一个Column的背景颜色为浅蓝色

  
  Column(){ // 在SideBarContainer内部再创建一个Column布局组件，用于垂直排列子组件
    
    Text('内容1').fontSize(15).padding(12)  // 添加一个Text组件，显示文本“内容1”，设置字体大小为15vp，内边距为12vp
    
    Text('内容2').fontSize(15).padding(12)  // 添加另一个Text组件，显示文本“内容2”，设置字体大小为15vp，内边距为12vp
  } // 第二个Column的结束括号
} // SideBarContainer的结束括号
.height(180)  // 限制SideBarContainer的高度为180vp
.margin({ top: 20 }) // 设置SideBarContainer的顶部外边距为20vp
```

#### 二、页面信息传递
##### **2.1 Index页面**

```Json5 {.line-numbers}
@State username: string = ''  // 定义一个状态变量，用于存储用户名输入，初始值为空字符串
@State password: string = ''  // 定义一个状态变量，用于存储密码输入，初始值为空字符串

.onClick(() => {  // 定义一个点击事件处理器
  // 带参数跳转到第二页
  router.pushUrl({  // 调用路由的pushUrl方法
    url: 'pages/Second',  // 指定要跳转到的页面路径
    params: {  // 定义一个对象，用于传递参数
      username: this.username,  // 将当前的用户名状态作为参数传递
      password: this.password  // 将当前的密码状态作为参数传递
    }  // 结束params对象的定义
  }).catch((err: BusinessError) => {  // 捕获pushUrl方法可能抛出的异常
    console.error(`跳转失败: ${err.code}, ${err.message}`)  // 在控制台输出错误信息
  })  // 结束catch块，也结束了pushUrl方法的调用
})  // 结束onClick事件处理器的定义

```

##### **2.2 Second页面**
```Json5 {.line-numbers}
  @State receivedUsername: string = ''  // 定义一个状态变量，用于接收用户名，初始值为空字符串
@State receivedPassword: string = ''  // 定义一个状态变量，用于接收密码，初始值为空字符串

aboutToAppear() {  // 定义一个生命周期方法，当页面即将出现时执行
  // 获取路由参数
  const params = router.getParams() as Record<string, string>  // 调用router的getParams方法获取路由参数，并断言为字符串键值对记录类型
  if (params) {  // 如果获取到了参数
    this.receivedUsername = params['username'] || ''  // 将参数中的用户名赋值给状态变量，如果不存在则默认为空字符串
    this.receivedPassword = params['password'] || ''  // 将参数中的密码赋值给状态变量，如果不存在则默认为空字符串
    this.message = `欢迎用户${this.receivedUsername}`  // 设置欢迎信息，包含接收到的用户名
  }  // 结束if语句
}  // 结束aboutToAppear方法的定义

Column() {  // 定义一个布局容器，用于组织页面元素
  // 用户信息区域
  Column() {  // 嵌套一个布局容器，用于展示用户信息
    Text(this.message)  // 显示欢迎信息
      .fontSize(38)  // 设置字体大小为38vp
      .fontColor('#1A1A1A')  // 设置字体颜色为深灰色
      .fontWeight(FontWeight.Medium)  // 设置字体粗细为中等
      .margin({ bottom: 20 })  // 设置底部外边距为20vp
    // 参数显示区域
    Column() {  // 嵌套另一个布局容器，用于展示参数信息
      // 新增信息展示容器
      Column() {  // 再嵌套一个布局容器，用于组织参数信息的展示
        Text(`用户名：${this.receivedUsername}`)  // 显示用户名
          .fontSize(16)  // 设置字体大小为16vp
          .fontColor('#666666')  // 设置字体颜色为深灰色
          .margin({ bottom: 4 })  // 设置底部外边距为4vp

        Text(`密码长度：${this.receivedPassword.length}`)  // 显示密码长度
          .fontSize(16)  // 设置字体大小为16vp
          .fontColor('#666666')  // 设置字体颜色为深灰色
      }  // 结束内部Column的定义
      .padding(12)  // 设置内边距为12vp
      .width('70%')  // 设置宽度为父容器宽度的70%
      .backgroundColor('#FFFFFF')  // 设置背景颜色为白色
      .border({  // 设置边框样式
        width: 1,  // 边框宽度为1vp
        color: '#EEEEEE',  // 边框颜色为浅灰色
        radius: 8  // 边框圆角半径为8vp
      })  // 结束border方法的调用
      .shadow({  // 设置阴影样式
        radius: 4,  // 阴影模糊半径为4vp
        color: '#152E6D0D',  // 阴影颜色为淡蓝色
        offsetX: 1,  // 阴影在X轴方向的偏移量为1vp
        offsetY: 2  // 阴影在Y轴方向的偏移量为2vp
      })  // 结束shadow方法的调用
    }  // 结束外部Column的定义
    .margin({ bottom: 18 })  // 设置底部外边距为18vp
    .alignItems(HorizontalAlign.Center)  // 设置子元素水平居中对齐
  }  // 结束最外层Column的定义
}  // 结束Column方法的定义

```

#### 三、页面预览

##### **3.1 Index页面与Second页面**

![图3](<)Y}JZAL%_HA52GHWQ}[A0%5.png>)


##### **3.2 页面信息传递效果**
![图4]({VPW7VQ4`HTRGZV]8{8LUFO.png)