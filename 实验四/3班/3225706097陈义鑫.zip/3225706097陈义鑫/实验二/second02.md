//Second.ets

``` java{.line-numbers}
import { router } from '@kit.ArkUI'; // 导入路由模块，用于页面导航和参数传递

interface GeneratedTypeLiteralInterface_1 {
  progress: number; // 定义一个接口，包含 progress 属性，类型为 number
  text: string; // 定义一个接口，包含 text 属性，类型为 string
}

@Entry // 装饰器，表示这是应用的入口页面
@Component // 装饰器，表示这是一个自定义组件
struct Second {
  @State progress: number = 0; // 使用 @State 装饰器定义一个响应式变量 progress，初始值为 0
  @State text: string = ''; // 使用 @State 装饰器定义一个响应式变量 text，初始值为空字符串

  onPageShow() {
    // 生命周期方法，当页面显示时触发
    const params = router.getParams() as GeneratedTypeLiteralInterface_1; // 获取从 Index 页面传递过来的参数，并断言为 GeneratedTypeLiteralInterface_1 类型
    if (params) {
      this.progress = params.progress; // 如果参数存在，将传递过来的 progress 赋值给 this.progress
      this.text = params.text; // 如果参数存在，将传递过来的 text 赋值给 this.text
    }
  }

  build() {
    // build 方法，用于定义组件的 UI 结构
    Column() {
      // 创建一个垂直布局的 Column 组件
      Text(`Progress: ${this.progress}`) // 创建一个 Text 组件，显示传递过来的 progress 值
        .fontSize(50) // 设置字体大小为 50
        .fontWeight(FontWeight.Bold) // 设置字体加粗
        .margin({ bottom: 40 }); // 设置底部外边距为 40

      Text(`Text: ${this.text}`) // 创建一个 Text 组件，显示传递过来的 text 内容
        .fontSize(50) // 设置字体大小为 50
        .fontWeight(FontWeight.Bold) // 设置字体加粗
        .margin({ bottom: 40 }); // 设置底部外边距为 40

      Button('Back') // 创建一个 Button 组件，显示文本为 'Back'
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状
        .backgroundColor('#809FFB') // 设置按钮背景颜色为 #809FFB
        .fontSize(40) // 设置字体大小为 40
        .fontWeight(FontWeight.Bold) // 设置字体加粗
        .width('50%') // 设置按钮宽度为父容器的 50%
        .height(60) // 设置按钮高度为 60
        .onClick(() => {
          router.back(); // 设置按钮点击事件，点击后返回上一页
        });
    }
    .width('100%') // 设置 Column 宽度为 100%
    .height('100%') // 设置 Column 高度为 100%
    .justifyContent(FlexAlign.Center) // 设置子组件在主轴（垂直方向）上居中对齐
    .alignItems(HorizontalAlign.Center); // 设置子组件在交叉轴（水平方向）上居中对齐
  }
}
```