//index.ets

``` java{.line-numbers}
import { router } from '@kit.ArkUI'; // 导入路由模块，用于页面导航和参数传递
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理模块，用于处理业务逻辑中的错误

@Entry // 装饰器，表示这是应用的入口页面
@Component // 装饰器，表示这是一个自定义组件
struct Index {
  @State message: string = 'Hello World'; // 使用 @State 装饰器定义一个响应式变量 message，初始值为 'Hello World'
  @State progressValue: number = 0; // 使用 @State 装饰器定义一个响应式变量 progressValue，初始值为 0
  @State isToggled: boolean = false; // 使用 @State 装饰器定义一个响应式变量 isToggled，初始值为 false
  @State inputText: string = ''; // 使用 @State 装饰器定义一个响应式变量 inputText，初始值为空字符串
  @State imageUrl: Resource = $r('app.media.huawei'); // 使用 @State 装饰器定义一个响应式变量 imageUrl，初始值为从 resources 目录加载的图片资源

  build() {
    // build 方法，用于定义组件的 UI 结构
    Row() {
      // 创建一个水平布局的 Row 组件
      Column() {
        // 在 Row 中创建一个垂直布局的 Column 组件

        // 1. 文本组件
        Text(this.message) // 创建一个 Text 组件，显示 this.message 的内容
          .fontSize(80) // 设置字体大小为 80
          .fontWeight(FontWeight.Bold) // 设置字体加粗
          .margin({ bottom: 40 }); // 设置底部外边距为 40

        // 2. 进度条
        Progress({ value: this.progressValue, total: 100, type: ProgressType.Linear }) // 创建一个 Progress 组件，显示进度条
          .width('80%') // 设置进度条宽度为父容器的 80%
          .height(50) // 设置进度条高度为 50
          .margin({ bottom: 80 }); // 设置底部外边距为 80

        Button('按一下增加10') // 创建一个 Button 组件，显示文本为 '按一下增加10'
          .fontSize(40) // 设置按钮字体大小为 40
          .width('80%') // 设置按钮宽度为父容器的 80%
          .height(80) // 设置按钮高度为 80
          .margin({ bottom: 90 }) // 设置底部外边距为 90
          .onClick(() => {
            this.progressValue = (this.progressValue + 10) % 110; // 设置按钮点击事件，点击后 progressValue 增加 10，超过 110 则重置为 0
          });

        // 3. 切换按钮
        Toggle({ type: ToggleType.Checkbox, isOn: this.isToggled }) // 创建一个 Toggle 组件，类型为复选框，初始状态为 this.isToggled
          .onChange((isOn: boolean) => { // 设置 Toggle 状态变化时的回调函数
            this.isToggled = isOn; // 更新 this.isToggled 的值为当前 Toggle 的状态
            console.info(`Toggle state changed to: ${isOn}`); // 打印 Toggle 状态变化日志
          })
          .width('50%') // 设置 Toggle 宽度为父容器的 50%
          .height(60) // 设置 Toggle 高度为 60
          .margin({ bottom: 40 }); // 设置底部外边距为 40

        // 4. 文本框
        TextInput({ placeholder: 'Enter text here', text: this.inputText }) // 创建一个 TextInput 组件，占位符为 'Enter text here'，初始值为 this.inputText
          .onChange((value: string) => { // 设置文本框内容变化时的回调函数
            this.inputText = value; // 更新 this.inputText 的值为当前文本框的内容
            console.info(`Text input changed to: ${value}`); // 打印文本框内容变化日志
          })
          .width('80%') // 设置文本框宽度为父容器的 80%
          .height(100) // 设置文本框高度为 100
          .fontSize(80) // 设置文本框字体大小为 80
          .fontWeight(FontWeight.Bold) // 设置文本框字体加粗
          .margin({ bottom: 30 }); // 设置底部外边距为 30

        // 5. 显示图片
        Image(this.imageUrl) // 创建一个 Image 组件，显示 this.imageUrl 指定的图片
          .width(200) // 设置图片宽度为 200
          .height(200) // 设置图片高度为 200
          .margin({ bottom: 40 }); // 设置底部外边距为 40

        // 6. 跳转按钮
        Button('Next')  // 创建一个按钮，按钮上显示的文字为 "Next"
          .type(ButtonType.Capsule)  // 设置按钮类型为胶囊形状
          .backgroundColor('#809FFB')  // 设置按钮的背景颜色为 #809FFB
          .fontSize(40)  // 设置按钮文字的字体大小为 40
          .fontWeight(FontWeight.Bold)  // 设置按钮文字的字体粗细为粗体
          .width('50%')  // 设置按钮的宽度为父容器的 50%
          .height(60)  // 设置按钮的高度为 60
          .onClick(() => {  // 设置按钮的点击事件
            console.info('Succeeded in clicking the ‘Next’ button.');  // 打印日志，表示按钮点击成功
            // 跳转到第二页，并传递数据
            router.pushUrl({  // 使用路由跳转到指定页面
              url: 'pages/Second',  // 目标页面的路径
              params: {  // 传递的参数
                progress: this.progressValue,  // 传递进度值
                text: this.inputText  // 传递输入的文本
              }
            })
              .then(() => {  // 跳转成功后的回调
                console.info('Succeeded in jumping to the second page.');  // 打印日志，表示跳转成功
              })
              .catch((err: BusinessError) => {  // 跳转失败后的回调
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);  // 打印错误日志，包含错误码和错误信息
              });
          });
      }
      .width('100%')  // 设置父容器的宽度为 100%
      .justifyContent(FlexAlign.Center)  // 设置父容器的内容在主轴（垂直轴）上居中对齐
      .alignItems(HorizontalAlign.Center);  // 设置父容器的内容在交叉轴（水平轴）上居中对齐
    }
    .height('100%');  // 设置父容器的高度为 100%
  }
}
```