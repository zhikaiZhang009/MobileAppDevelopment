### 一、设计目标
想要设计1个vivo官网的界面，主要包括以下四个模块：热销机型、系统功能、快速上手以及体验跳转按钮。
![[总览.png]]{width="400px"}

### 二、各模块设计思想
（1）热销机型部分
使用**Swiper组件**来承载多张照片以实现滑动轮播显示的效果。
![[热销机型.png]]{width="400px"}

（2）系统功能部分
使用**Grid组件**作为外层容器实现横向可滑动效果。
![[系统功能.png]]{width="400px"}

（3）快速上手部分
使用**list组件**作为外层容器实现纵向可滑动效果
![[快速上手.png]]{width="400px"}

（4）体验跳转按钮
通过**Button组件**来创建点击跳转按钮。在点击按钮后会将第一个界面原先设定好的字符串'敬请期待'传值到第二界面中。
![[跳转按钮.png]]{width="400px"}
跳转界面：
![[跳转界面.png]]{width="400px"}

### 三、实现代码
（1）第一界面：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI'; // 导入ArkUI的路由模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入基础服务模块的错误处理类

// 定义BannerClass类，用于存储Banner的相关信息
class BannerClass {
  id: string = ''; // Banner的唯一标识
  imageSrc: ResourceStr = ''; // Banner图片的资源路径
  url: string = ''; // Banner点击后跳转的URL

  // 构造函数，初始化BannerClass的实例
  constructor(id: string, imageSrc: ResourceStr, url: string) {
    this.id = id;
    this.imageSrc = imageSrc;
    this.url = url;
  }
}

// 定义ArticleClass类，用于存储文章的相关信息
class ArticleClass {
  id: string = ''; // 文章的唯一标识
  imageSrc: ResourceStr = ''; // 文章图片的资源路径
  title: string = ''; // 文章的标题
  brief: string = ''; // 文章的简介
  webUrl: string = ''; // 文章点击后跳转的URL

  // 构造函数，初始化ArticleClass的实例
  constructor(id: string, imageSrc: ResourceStr, title: string, brief: string, webUrl: string) {
    this.id = id;
    this.imageSrc = imageSrc;
    this.title = title;
    this.brief = brief;
    this.webUrl = webUrl;
  }
}

// 定义Index组件，作为应用的入口组件
@Entry
@Component
struct Index {
  @State message: string = '热销机型'; // 定义状态变量message，用于显示标题

  // 构建UI
  build() {
    Column() {
      // 显示标题
      Text(this.message).fontSize(22).fontWeight(700).width('100%').textAlign(TextAlign.Start)
        .padding({ left: 16 }).fontFamily('HarmonyHeiTi-Bold').lineHeight(33).margin({top:10})

      // 使用Scroll组件实现滚动视图
      Scroll() {
        Column() {
          Banner() // 显示Banner组件
          EnablementView() // 显示EnablementView组件
          TutorialView() // 显示TutorialView组件

          // 定义一个按钮，点击后跳转到第二个页面
          Button() {
            Row() {
              LoadingProgress().width(25).height(25).margin({ right: 8 }).color(Color.White); // 加载进度条
              Text('Open the OringinOS').fontSize(20).fontColor(Color.White) // 按钮文本
                .fontFamily('cursive').fontStyle(FontStyle.Italic).fontWeight(FontWeight.Bolder);
            }
          }.width(270).height(55).backgroundColor(0x317aff).margin({ top: 15 })
          .onClick(() => {
            console.info('Succeeded in clicking the  button.')
            // 使用路由跳转到第二个页面
            router.pushUrl({
              url: 'pages/second',
              params:{
                src:'敬请期待'
              }
            }).then(() => {
              console.info('Succeeded in jumping to the second page.')
            }).catch((err: BusinessError) => {
              console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
            })
          })
        }
      }
      .layoutWeight(1)
      .scrollBar(BarState.Off)
      .align(Alignment.TopStart)
    }
    .height('100%')
    .width('100%')
    .backgroundColor('#F1F3F5')
  }
}

// 定义Banner组件，用于显示轮播图
@Preview
@Component
struct Banner {
  @State bannerList: Array<BannerClass> = [
    new BannerClass('pic0', $r('app.media.banner_pic0'),
      'https://developer.huawei.com/consumer/cn/training/course/video/C101718352529709527'),
    new BannerClass('pic1', $r('app.media.banner_pic1'),
      'https://developer.huawei.com/consumer/cn/')
  ];

  // 构建UI
  build() {
    Swiper() {
      // 显示两张图片作为轮播图
      Image($r('app.media.vivo1')).objectFit(ImageFit.Contain).width('100%').padding({ top: 11, left: 16, right: 16 }).borderRadius(16)
      Image($r('app.media.vivo2')).objectFit(ImageFit.Contain).width('100%').padding({ top: 11, left: 16, right: 16 }).borderRadius(16)
    }
  }
}

// 定义EnablementItem组件，用于显示单个系统功能项
@Component
struct EnablementItem {
  @Prop enablementItem: ArticleClass; // 接收传入的文章数据

  // 构建UI
  build() {
    Column() {
      // 显示文章图片
      Image(this.enablementItem.imageSrc).width('100%').objectFit(ImageFit.Cover).height(110).borderRadius({
        topLeft: 16,
        topRight: 16
      })
      // 显示文章标题
      Text(this.enablementItem.title).height(20).width('100%').fontSize(14).textAlign(TextAlign.Center).textOverflow({ overflow: TextOverflow.Ellipsis })
        .maxLines(1).fontWeight(600).padding({ left: 12, right: 12 }).margin({ top: 8 })
    }.width(160).height(140).borderRadius(16).backgroundColor(Color.White)
  }
}

// 定义TutorialItem组件，用于显示单个教程项
@Component
struct TutorialItem {
  @Prop tutorialItem: ArticleClass; // 接收传入的文章数据

  // 构建UI
  build() {
    Row() {
      Column() {
        // 显示文章标题
        Text(this.tutorialItem.title).height(19).width('100%').fontSize(14).textAlign(TextAlign.Start).textOverflow({ overflow: TextOverflow.Ellipsis })
          .maxLines(1).fontWeight(400).margin({ top: 4 })
        // 显示文章简介
        Text(this.tutorialItem.brief).height(32).width('100%').fontSize(12).textAlign(TextAlign.Start).textOverflow({ overflow: TextOverflow.Ellipsis })
          .maxLines(2).fontWeight(400).fontColor('rgba(0, 0, 0, 0.6)').margin({ top: 5 })
      }.height('100%').layoutWeight(1).alignItems(HorizontalAlign.Start).margin({ right: 12 })
      // 显示文章图片
      Image(this.tutorialItem.imageSrc).height(64).width(108).objectFit(ImageFit.Cover).borderRadius(16)
    }.width('100%').height(88).borderRadius(16).backgroundColor(Color.White).padding(12).alignItems(VerticalAlign.Top)
  }
}

// 定义EnablementView组件，用于显示系统功能列表
@Component
struct EnablementView{
  @State enablementList: Array<ArticleClass> = [
    new ArticleClass('1', $r('app.media.vivo3'), '原子通知胶囊',
      '基于真实的开发场景，提供向导式学习，多维度融合课程等内容，给开发者提供全新的学习体验。',
      'https://developer.huawei.com/consumer/cn/doc/harmonyos-video-courses/video-tutorials-0000001443535745'),
    new ArticleClass('2', $r('app.media.enablement_pic2'), '原子设计体系',
      '提供系统能力概述、快速入门，用于指导开发者进行场景化的开发。指南涉及到的知识点包括必要的背景知识、符合开发者实际开发场景的操作任务流（开发流程、开发步骤、调测验证）以及常见问题等。',
      'https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/application-dev-guide-0000001630265101'),
    new ArticleClass('3', $r('app.media.enablement_pic3'), '全新操作体验',
      '针对新发布特性及热点特性提供详细的技术解析和开发最佳实践。',
      'https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/topic-architecture-0000001678045510'),
  ];

  // 构建UI
  build() {
    Column() {
      // 显示系统功能标题
      Text('系统功能').fontSize(22).fontWeight(700).width('100%').textAlign(TextAlign.Start).padding({ left: 16 })
        .fontFamily('HarmonyHeiTi-Bold').lineHeight(0)
      // 使用Grid组件显示系统功能列表
      Grid() {
        ForEach(this.enablementList, (item: ArticleClass) => {
          GridItem() {
            EnablementItem({ enablementItem: item }) // 显示单个系统功能项
          }
        }, (item: ArticleClass) => item.id)
      }.rowsTemplate('1fr').columnsGap(8).scrollBar(BarState.Off).height(169).padding({ top: 2, left: 16, right: 16 })
    }.margin({ top: 18 }).alignItems(HorizontalAlign.Start).width('100%')
  }
}

// 定义TutorialView组件，用于显示快速上手教程列表
@Component
struct TutorialView{
  @State tutorialList: Array<ArticleClass> = [
    new ArticleClass('1', $r('app.media.tutorial_pic1'), '图文音频实时翻译',
      '支持14个语种实时翻译，看外文文献边滑边翻译。看外文视频边听边翻译。',
      'https://developer.huawei.com/consumer/cn/forum/home?all=1'),
    new ArticleClass('2', $r('app.media.tutorial_pic2'), '快速迁移手机数据',
      '手机及平板默认内置该应用，宁可在桌面顶部下滑进入搜索框，搜索互传即可。',
      'https://developer.huawei.com/consumer/cn/forum/home?all=1'),
  ];

  // 构建UI
  build() {
    Column() {
      // 显示快速上手标题
      Text('快速上手').fontSize(22).fontWeight(700).width('100%').textAlign(TextAlign.Start).padding({ left: 16 })
        .fontFamily('HarmonyHeiTi-Bold').lineHeight(0).margin({bottom:6})
      // 使用List组件显示教程列表
      List({ space: 12 }) {
        ForEach(this.tutorialList, (item: ArticleClass) => {
          ListItem() {
            TutorialItem({ tutorialItem: item }) // 显示单个教程项
          }
        }, (item: ArticleClass) => item.id)
      }
      .scrollBar(BarState.Off)
      .padding({ left: 16, right: 16 })
    }
    .margin({ top: 18 })
    .alignItems(HorizontalAlign.Start)
  }
}
```

（2）第二界面：
```typescript{.line-numbers}
import { BusinessError } from '@kit.BasicServicesKit'; // 导入基础服务模块的错误处理类
import { router } from '@kit.ArkUI'; // 导入ArkUI的路由模块

// 获取当前页面的路由状态
let page = router.getState();

// 定义Second组件，作为第二个页面
@Entry
@Component
struct Second {
  @State src: string = page.params['src']; // 从路由参数中获取src的值，并定义为状态变量

  // 构建UI
  build() {
    Row() {
      Column() {
        // 显示加载进度条
        LoadingProgress().color(0x317aff).width(150).height(150);

        // 定义一个按钮，显示从路由参数中获取的src值
        Button() {
          Text(this.src).fontSize(24).fontFamily('cursive').fontStyle(FontStyle.Italic).fontColor(Color.White).fontWeight(FontWeight.Bold);
        }
        .type(ButtonType.Capsule) // 设置按钮样式为胶囊形状
        .margin({ top: 20 }) // 设置按钮的上边距
        .backgroundColor("0D9FFB") // 设置按钮的背景颜色
        .width('40%') // 设置按钮的宽度
        .height('5%') // 设置按钮的高度
        .onClick(() => {
          console.info('Succeeded in clicking the "Back" button.'); // 打印日志，表示按钮点击成功
          try {
            router.back(); // 返回上一个页面
            console.info("Succeeded in returning to the first page."); // 打印日志，表示返回成功
          } catch (err) {
            let code = (err as BusinessError).code; // 捕获错误并获取错误码
            let message = (err as BusinessError).message; // 捕获错误并获取错误信息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`); // 打印错误日志
          }
        });
      }
      .width('100%'); // 设置Column的宽度为100%
    }
    .height('100%'); // 设置Row的高度为100%
  }
}
```