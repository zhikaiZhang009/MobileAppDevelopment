# 实验三报告

> 学号：<3225706108>
> 
> 姓名：<黄泽凯>
> 
> 指导老师：<张凯斌>
> 
> 实验日期：<2025-03-20>

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；
  - 注意：UML图只是OOAD中的一部分（代码相关的部分），并不是OOAD的全部。例如：
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习；

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；
  - <font color=red>实验步骤部分需严格按模板要求撰写；</font>
  - <font color=red>提交时删除掉上文中的“UML提纲.png“图片；</font>

## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图

![[用例图.png]]

#### 1.2 用例规约

##### 1.2.1 添加商品

| 字段          | 内容                                                                 |
|---------------|----------------------------------------------------------------------|
| 用例名        | 添加商品信息                                                         |
| 执行者        | 服装店员工/老板                                                      |
| 前置条件      | 1. 用户已登录系统；<br>2. 数据库连接正常。                            |
| 触发事件      | 用户填写商品信息并点击“添加商品信息”按钮                                |
| 主成功场景    | 1. 用户输入货号、名称、价格、数量；<br>2. 系统检查货号唯一性；<br>3. 商品信息存入数据库；<br>4. 提示“添加成功”。 |
| 扩展场景      | **货号已存在**：<br>- 系统提示“商品已存在”，终止操作。                |
| 最小保证      | 所有操作日志将被记录，包括失败尝试。                                  |
| 后置条件      | 商品信息被持久化存储到数据库。                                        |
| 优先级        | 高                                                                  |
| 频度          | 高（每日多次）                                                       |
| 输入          | 货号（整数）、名称（字符串）、价格（整数）、数量（整数）。             |
| 输出          | 数据库记录更新，操作成功提示。                                        |
| 异常          | 1. 输入格式错误（如非数字货号）；<br>2. 数据库连接失败；<br>3. 系统崩溃。 |
| 附加信息      | 货号为主键，不可重复。                                                |


##### 1.2.2 删除商品

| 字段          | 内容                                                                 |
|---------------|----------------------------------------------------------------------|
| 用例名        | 删除商品信息                                                         |
| 执行者        | 服装店员工/老板                                                      |
| 前置条件      | 1. 用户已登录系统；<br>2. 目标商品存在。                              |
| 触发事件      | 用户输入要删除商品对应的货号并点击“删除商品信息”按钮。                                    |
| 主成功场景    | 1. 用户输入货号；<br>2. 系统验证货号存在；<br>3. 删除数据库记录；<br>4. 提示“删除成功”。 |
| 扩展场景      | **货号不存在**：<br>- 系统提示“商品不存在”，终止操作。                |
| 最小保证      | 删除操作日志将被记录。                                                |
| 后置条件      | 数据库中的商品信息被移除。                                            |
| 优先级        | 中                                                                  |
| 频度          | 中（每日多次）                                                       |
| 输入          | 货号（整数）。                                                       |
| 输出          | 数据库记录删除，操作成功提示。                                        |
| 异常          | 1. 数据库删除失败；<br>2. 系统意外中断。                              |
| 附加信息      | 删除操作不可逆。                                                      |

##### 1.2.3 更新商品

| 字段          | 内容                                                                 |
|---------------|----------------------------------------------------------------------|
| 用例名        | 修改商品信息                                                         |
| 执行者        | 服装店员工/老板                                                      |
| 前置条件      | 1. 用户已登录系统；<br>2. 目标商品存在。                              |
| 触发事件      | 用户输入要修改的商品信息并点击“修改商品信息”按钮。                            |
| 主成功场景    | 1. 用户输入货号和新属性值；<br>2. 系统验证货号存在；<br>3. 更新数据库记录；<br>4. 提示“修改成功”。 |
| 扩展场景      | **货号不存在**：<br>- 系统提示“商品不存在”，终止操作。                |
| 最小保证      | 修改操作日志将被记录。                                                |
| 后置条件      | 数据库中的商品信息被更新。                                            |
| 优先级        | 中                                                                  |
| 频度          | 中（每日多次）                                                       |
| 输入          | 货号（整数）、新名称（字符串）、新价格（整数）、新数量（整数）。       |
| 输出          | 数据库记录更新，操作成功提示。                                        |
| 异常          | 1. 输入的新数据格式错误；<br>2. 数据库更新失败。                      |
| 附加信息      | 仅允许修改非主键字段（名称、价格、数量）。                            |

##### 1.2.4查询商品

| 字段          | 内容                                                                 |
|---------------|----------------------------------------------------------------------|
| 用例名        | 查询商品信息                                                         |
| 执行者        | 服装店员工/老板                                                      |
| 前置条件      | 用户已登录系统。                                                     |
| 触发事件      | 用户选择是否筛选有货商品并点击“查询商品信息”按钮。                        |
| 主成功场景    | 1. 用户选择是否筛选有货商品；<br>2. 系统查询数据库；<br>3. 返回符合条件的商品列表。 |
| 扩展场景      | **筛选有货商品**：<br>- 仅返回数量>0的商品。                          |
| 最小保证      | 查询结果至少包含表头和空状态提示。                                    |
| 后置条件      | 界面显示查询结果。                                                   |
| 优先级        | 高                                                                  |
| 频度          | 高（每日多次）                                                       |
| 输入          | 筛选条件（是否仅显示有货商品）。                                      |
| 输出          | 商品列表（货号、名称、价格、数量）。                                  |
| 异常          | 1. 数据库查询超时；<br>2. 查询结果为空时的友好提示。                  |
| 附加信息      | 默认显示所有商品，支持实时刷新。                                      |
### 2. 总体设计

#### 2.1 类图（静态视图）
![[类图（静态）.png ]]

#### 2.2 活动图（动态视图）

![活动图（动态视图）.svg]]

### 3. 详细设计

#### 3.1 详细类图

![[详细类图.png]]

#### 3.2 包图

![[包图.svg]]

#### 4.1 代码实现

##### 4.1.1 AccounterUser.ets
```typescript {.line-numbers}
// 导入数据库模块、工具类和接口
import { relationalStore } from '@kit.ArkData';
import RdbUtil from './RdbUtil';
import RdbFunctions from './RdbFunctions';
import { AccountData, AccountTable } from './table/AccountInterface';
import CommonConstants from '../Constants/CommonConstants'

// 账户用户操作类
export default class AccountUsers {
    // 初始化数据库操作工具类
    private accountUsers = new RdbFunctions(
        CommonConstants.ACCOUNT_TABLE.tableName,  // 表名
        CommonConstants.ACCOUNT_TABLE.sqlCreate,   // 建表 SQL
        CommonConstants.ACCOUNT_TABLE.columns      // 列名列表
    );

    // 构造函数，可选回调函数
    constructor(callback: Function = () => {}) {
        this.accountUsers.getRdbStore(() => {
            console.info('Database connected!'); // 添加日志确认连接成功
            callback();
        });
    }

    // 获取数据库连接
    getRdbStore(callback: Function = () => {}) {
        this.accountUsers.getRdbStore(callback);
    }


    insertData(account: AccountData, callback: (success: boolean, message?: string) => void) {
        const valueBucket = generateBucket(account);  // 将数据转换为键值对
        console.log('插入数据:', JSON.stringify(valueBucket));
        this.accountUsers.insertData(valueBucket, callback); // 调用工具类插入
    }


    // 删除数据
    deleteData(account: AccountData, callback: Function) {
        let predicates = new relationalStore.RdbPredicates(
            CommonConstants.ACCOUNT_TABLE.tableName
        );
        predicates.equalTo('ArtNo', account.ArtNo);  // 根据 ArtNo 删除
        this.accountUsers.deleteData(predicates, callback);
    }

    // 更新数据
    updateData(account: AccountData, callback: Function) {
        const valueBucket = generateBucket(account);
        console.log('更新数据:', JSON.stringify(valueBucket));
        let predicates = new relationalStore.RdbPredicates(
            CommonConstants.ACCOUNT_TABLE.tableName
        );
        predicates.equalTo('ArtNo', account.ArtNo);  // 根据 ArtNo 更新
        this.accountUsers.updateData(predicates, valueBucket, callback);
    }
    // 查询数据
    query(isFilterStock: boolean, callback: Function) {
        let predicates = new relationalStore.RdbPredicates(
            CommonConstants.ACCOUNT_TABLE.tableName
        );
        if (isFilterStock) {
            predicates.notEqualTo('Amount', 0); // 筛选 Amount 不等于0的记录
        }
        this.accountUsers.query(predicates, (resultSet: relationalStore.ResultSet) => {
            let count = resultSet.rowCount;
            if (count === 0 || typeof count === 'string') {
                console.log('Query no result!');  // 无结果提示
                callback();
            } else {
                resultSet.goToFirstRow();
                console.log('Columns:', resultSet.columnNames);
                const result: AccountData[] = [];
                for (let i = 0; i < count; i++) {
                    let tmp: AccountData = {  ArtNo:0, Name: '', Price: 0, Amount: 0 };
                    tmp.ArtNo = resultSet.getDouble(resultSet.getColumnIndex('ArtNo')); // 读取货号
                    tmp.Name = resultSet.getString(resultSet.getColumnIndex('Name'));   //读取商品名称
                    tmp.Price = resultSet.getDouble(resultSet.getColumnIndex('Price'));// 读取价格
                    tmp.Amount = resultSet.getDouble(resultSet.getColumnIndex('Amount'));   // 读取数量
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);  // 返回查询结果
            }
        });
    }
    checkArtNoExists(artNo: number, callback: (exists: boolean) => void) {
        let predicates = new relationalStore.RdbPredicates(
            CommonConstants.ACCOUNT_TABLE.tableName
        );
        predicates.equalTo('ArtNo', artNo);

        // 调用 RdbFunctions 的 query 方法检查是否存在
        this.accountUsers.query(predicates, (resultSet: relationalStore.ResultSet) => {
            const exists = resultSet.rowCount > 0;
            callback(exists);
            resultSet.close(); // 必须关闭结果集
        });
    }
}

// 辅助函数：将 AccountData 转换为数据库键值对
function generateBucket(account: AccountData) {
    let obj: relationalStore.ValuesBucket = {};
    obj.ArtNo = account.ArtNo;
    obj.Name = account.Name;
    obj.Price = account.Price;
    obj.Amount = account.Amount;
    return obj;
}
```
##### 4.1.2 RdbFunctions.ets
```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import RdbUtil from './RdbUtil';

// 数据库操作工具类（继承自 RdbUtil）
export default class RdbFunctions extends RdbUtil {
  // 插入数据
  insertData(data: relationalStore.ValuesBucket, callback: Function = () => {}) {
    let resFlag: boolean = false;  // 操作结果标志
    const valueBucket = data;
    if (this.rdbStore) {
      this.rdbStore.insert(this.tableName, valueBucket, (err, ret) => {
        if (err) {
          console.error('Rdb', `insertData() failed, err ${err}`);
          callback(resFlag);  // 失败返回 false
          return;
        }
        console.info(`insertData() finished: ${ret}`);  // 日志提示
        callback(!resFlag);  // 成功返回 true
      });
    }
  }

  // 删除数据
  deleteData(predicates: relationalStore.RdbPredicates, callback: Function = () => {}) {
    let resFlag: boolean = false;
    if (this.rdbStore) {
      this.rdbStore.delete(predicates, (err, ret) => {
        if (err) {
          console.error('Rdb', `deleteData() failed, err ${err}`);
          callback(resFlag);
          return;
        }
        console.info(`deleteData() finished: ${ret}`);
        callback(!resFlag);
      });
    }
  }


  updateData(predicates: relationalStore.RdbPredicates, data: relationalStore.ValuesBucket, callback: Function = () => {}) {
    let resFlag: boolean = false;
    const valueBucket = data;
    if (this.rdbStore) {
      this.rdbStore.update(valueBucket, predicates, (err, ret) => {
        if (err) {
          console.error('Rdb', `updateData() failed, code: ${err.code}, message: ${err.message}`);
          callback(resFlag);
          return;
        }
        console.info(`updatedata() finished: ${ret}`);
        callback(!resFlag);
      });
    }
  }

  // 查询数据
  query(predicates: relationalStore.RdbPredicates, callback: Function = () => {}) {
    if (this.rdbStore) {
      this.rdbStore.query(predicates, (err, ret) => {
        if (err) {
          console.error('Rdb', `query() failed ${err}`);
          return;
        }
        console.info('Rdb', `query() finished: ${ret}`);
        callback(ret);  // 返回查询结果集
      });
    }
  }
}
```
##### 4.1.3 CommonConstants.ets
```typescript {.line-numbers}
// 导入关系型数据库模块和账户表接口
import { relationalStore } from '@kit.ArkData'
import { AccountTable } from '../database/table/AccountInterface'

// 定义公共常量类
export default class CommonConstants {
  // 数据库存储配置
  static readonly STONE_CONFIG: relationalStore.StoreConfig = {
    name: 'database2.db',        // 数据库文件名
    securityLevel: relationalStore.SecurityLevel.S1  // 安全级别为 S1
  }

  // 账户表结构定义
  static readonly ACCOUNT_TABLE: AccountTable = {
    tableName: 'accountTable2',  // 表名
    sqlCreate: 'CREATE TABLE IF NOT EXISTS accountTable2 (ArtNo INTEGER PRIMARY KEY , Name TEXT, Price INTEGER, Amount INTEGER)',
    columns: ['ArtNo', 'Name', 'Price', 'Amount']  // 列名列表
  }
}
```

##### 4.1.4 AccountInterface.ets
```typescript {.line-numbers}
// 定义账户数据接口
export interface AccountData {
  ArtNo: number;          // 货号
  Name: string; // 商品名称
  Price: number;     // 价格
  Amount: number;       // 数量
}

// 定义账户表结构接口
export interface AccountTable {
  tableName: string;     // 表名
  sqlCreate: string;     // 建表 SQL 语句
  columns: Array<string>; // 列名数组
}
```
##### 4.1.5 RdbUtil.ets
```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import CommonConstants from "../Constants/CommonConstants";

// 数据库工具基类
export default class RdbUtil {
  rdbStore: relationalStore.RdbStore | null = null;  // 数据库实例
  tableName: string = '';        // 当前操作的表名
  sqlCreateTable: string = '';   // 建表 SQL
  columns: Array<string> = [];   // 列名列表

  // 构造函数初始化表信息
  constructor(tableName: string, sqlCreateTable: string, columns: Array<string>) {
    this.tableName = tableName;
    this.sqlCreateTable = sqlCreateTable;
    this.columns = columns;
  }

  // 获取数据库连接
  getRdbStore(callback: Function = () => {}) {
    if (!callback || typeof callback === 'undefined' || callback === undefined) {
      console.info('getRdbStore() has no callback.');
      return;
    }
    if (this.rdbStore != null) {
      console.info('The rdbStore exists.');  // 避免重复初始化
      callback();
      return;
    }
    let context: Context = getContext(this) as Context;  // 获取上下文
    relationalStore.getRdbStore(
      context,
      CommonConstants.STONE_CONFIG,  // 使用公共配置
      (err, rdb) => {
        if (err) {
          console.error(`getRdbStore() failed, err: ${err}`);
          return;
        }
        this.rdbStore = rdb;
        this.rdbStore.executeSql(this.sqlCreateTable);  // 执行建表语句
        console.info("getRdbStore() finished");
        callback();
      }
    );
  }
}
```
##### 4.1.6 index.ets
```typescript {.line-numbers}
// 导入所需的模块和接口
// AccountData 接口定义了账户数据的结构
import {AccountData} from '../Common/database/table/AccountInterface';
// AccountTable 接口定义了数据库表操作
import {AccountTable} from '../Common/database/table/AccountInterface';
// AccountUsers 类处理用户账户操作
import AccountUsers from '../Common/database/AccountUsers';
// 鸿蒙的关系型数据库模块
import { relationalStore } from '@kit.ArkData';
// 在文件顶部添加
import promptAction from '@ohos.promptAction';
@Entry
@Component
struct Index {

  @State message: string = '查询结果';
  @State ArtNo:number =0;
  @State Name:string='';
  @State Price:number=0;
  @State Amount:number=0;
  @State ArtNo_u:number =0;
  @State Name_u:string='';
  @State Price_u:number=0;
  @State Amount_u:number=0;
  @State ArtNo_d:number=0;
  @State isFilterStock: boolean = false;
  scroller: Scroller = new Scroller()
  @State dataList: AccountData[] = [];
  private accountUsers = new AccountUsers(() => {
    console.info("数据库初始化成功");
  });

  build() {

    Scroll() {

      Column() {

        Text("服装信息管理系统")
          .fontSize(30)
          .fontWeight(FontWeight.Bold)
          .fontColor('black')
          .margin({ bottom: 17 })


        Column() {

          Row() {
            TextInput({ placeholder: '输入货号' })
              .width('48%')
              .onChange((value: string) => this.ArtNo = parseInt(value))

            TextInput({ placeholder: '输入名称' })
              .width('48%')
              .margin({ left: '4%' })
              .onChange((value: string) => this.Name = value)
          }.margin({ bottom: 10 })

          Row() {
            TextInput({ placeholder: '输入价格' })
              .width('48%')
              .onChange((value: string) => this.Price = parseInt(value))

            TextInput({ placeholder: '输入数量' })
              .width('48%')
              .margin({ left: '4%' })
              .onChange((value: string) => this.Amount = parseInt(value))
          }
        }
        .padding(15)
        .borderRadius(12)
        .backgroundColor("#f5f5f5")
        .width('100%')


        Button(('增加商品信息'), { type: ButtonType.Capsule })
          .width('60%')
          .height(45)
          .backgroundColor('#ff525559')
          .fontColor(Color.White)
          .margin({ top: 15, bottom: 25 })
          .onClick(() => {
            let newAccount: AccountData = {
              ArtNo: this.ArtNo,
              Name: this.Name,
              Price: this.Price,
              Amount: this.Amount
            };

            // 检查 ArtNo 是否存在
            this.accountUsers.checkArtNoExists(newAccount.ArtNo, (exists: boolean) => {
              if (exists) {
                // 弹出提示
                promptAction.showDialog({
                  message: '该商品已经存在',
                  buttons: [{
                    text: '确定',
                    color: '#000000' // 根据 UI 主题调整颜色
                  }]
                }).catch((err: Error) => { // 显式指定 Error 类型
                  console.error(`提示失败: ${err.message}`);
                });
              } else {
                // 执行插入操作
                this.accountUsers.insertData(newAccount, () => {
                  console.info("插入数据成功");
                });
              }
            });
          })

        Column() {

          Row() {
            TextInput({ placeholder: '输入货号' })
              .width('48%')
              .onChange((value: string) => this.ArtNo_u = parseInt(value))

            TextInput({ placeholder: '输入名称' })
              .width('48%')
              .margin({ left: '4%' })
              .onChange((value: string) => this.Name_u = value)
          }.margin({ bottom: 10 })


          Row() {
            TextInput({ placeholder: '输入价格' })
              .width('48%')
              .onChange((value: string) => this.Price_u = parseInt(value))

            TextInput({ placeholder: '输入数量' })
              .width('48%')
              .margin({ left: '4%' })
              .onChange((value: string) => this.Amount_u = parseInt(value))
          }
        }
        .padding(15)
        .borderRadius(12)
        .backgroundColor("#f5f5f5")
        .width('100%')

        Button('更新商品信息', { type: ButtonType.Capsule })
          .width('60%')
          .height(45)
          .backgroundColor("#FF525559")
          .fontColor(Color.White)
          .margin({ top: 15, bottom: 25 })
          .onClick(() => {
            let newAccount: AccountData = {
              ArtNo: this.ArtNo_u,
              Name: this.Name_u,
              Price: this.Price_u,
              Amount: this.Amount_u
            };
            // 检查 ArtNo 是否存在
            this.accountUsers.checkArtNoExists(newAccount.ArtNo, (exists: boolean) => {
              if (!exists) {
                promptAction.showDialog({
                  message: '商品不存在',
                  buttons: [{
                    text: '确定',
                    color: '#000000'
                  }]
                }).catch((err: Error) => {
                  console.error(`提示失败: ${err.message}`);
                });
              } else {
                this.accountUsers.updateData(newAccount, () => {
                  console.info("更新数据成功");

                });
              }
            });
          })

        Column() {
          Row() {
            TextInput({ placeholder: '输入要删除的货号' })
              .width('80%')
              .onChange((value: string) => this.ArtNo_d = parseInt(value))
          }
        }
        .margin({ bottom: 10 })
        .padding(15)
        .borderRadius(12)
        .backgroundColor("#f5f5f5")
        .width('100%')

        Button('删除商品信息', { type: ButtonType.Capsule })
          .width('60%')
          .height(40)
          .backgroundColor("#FF525559")
          .fontColor(Color.White)
          .margin({ bottom: 10 })
          .onClick(() => {

            let newAccount: AccountData = {
              ArtNo: this.ArtNo_d,
              Name: '',
              Price: 0,
              Amount: 0
            };
            this.accountUsers.checkArtNoExists(newAccount.ArtNo, (exists: boolean) => {
              if (!exists) {
                promptAction.showDialog({
                  message: '商品不存在',
                  buttons: [{
                    text: '确定',
                    color: '#000000'
                  }]
                }).catch((err: Error) => {
                  console.error(`提示失败: ${err.message}`);
                });
              } else {
                this.accountUsers.deleteData(newAccount, () => {
                  console.info("删除数据成功");

                });
              }
            });

          })


        Column() {
          // 表头
          Row() {
            Text('货号').width('25%').fontWeight(FontWeight.Bold).backgroundColor('#f0f0f0').textAlign(TextAlign.Center).height(40)
            Text('名称').width('25%').fontWeight(FontWeight.Bold).backgroundColor('#f0f0f0').textAlign(TextAlign.Center).height(40)
            Text('价格').width('25%').fontWeight(FontWeight.Bold).backgroundColor('#f0f0f0').textAlign(TextAlign.Center).height(40)
            Text('数量').width('25%').fontWeight(FontWeight.Bold).backgroundColor('#f0f0f0').textAlign(TextAlign.Center).height(40)
          }
          .width('100%')
          .padding(10)
          .borderRadius(8)

          // 数据行

          ForEach(this.dataList, (item: AccountData) => {
            Row() {
              Text(item.ArtNo.toString()).width('25%').textAlign(TextAlign.Center)
              Text(item.Name).width('25%').textAlign(TextAlign.Center)
              Text(item.Price.toString()).width('25%').textAlign(TextAlign.Center)
              Text(item.Amount.toString()).width('25%').textAlign(TextAlign.Center)
            }
            .width('100%')
            .padding(10)
            .border({ width: 1, color: '#e0e0e0' })
          }, (item: AccountData) => item.ArtNo.toString())
        }
        .width('100%')
        .margin({ top: 20 })

        Row() {
          Button(('查询商品信息'), { type: ButtonType.Capsule })
            .width(140)
            .fontSize(16)
            .fontWeight(FontWeight.Medium)
            .margin({ top: 20, bottom: 20, right: 20 })
            .backgroundColor("#FF525559")
            .onClick(() => {
              this.accountUsers.query(this.isFilterStock, (result: AccountData[]) => {
                this.dataList = result; // 将查询结果存入状态变量
                console.info("查询成功")
              })
            })

          Row() {
            Toggle({ type: ToggleType.Switch, isOn: this.isFilterStock })
              .onChange((isOn: boolean) => {
                this.isFilterStock = isOn;
              })
            Text("筛选有货")
              .fontSize(15)
              .fontWeight(600)
              .margin({ left: 10 })
          }
        }

      }
      .width('100%')
    }
    .width('100%')
    .height('100%')
    .scrollable(ScrollDirection.Vertical)
    .scrollBar(BarState.On)
    .scrollBarColor(Color.Gray)
    .scrollBarWidth(6)
  }
}
```
#### 4.2 结果验证

##### 整体界面
![[整体布局(1).png]]{width="200px"}
![[整体布局(2).png]]{width="200px"}

##### 添加商品信息
![[添加商品信息.png]]{width="200px"}

##### 修改商品信息
![[修改商品信息.png]]{width="200px"}

##### 删除商品信息
![[删除商品信息.png]]{width="200px"}

##### 查询商品信息（筛选有货）
![[查询商品信息（筛选有货）.png]]{width="200px"}

##### 添加商品已经存在提示
![[添加商品已经存在.png]]{width="200px"}

##### 修改商品不存在提示
![[修改商品不存在提示.png]]{width="200px"}

##### 删除商品不存在提示
![[删除商品不存在提示.png]]{width="200px"}
