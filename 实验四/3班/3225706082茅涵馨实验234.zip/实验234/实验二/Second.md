# <center>**实验二 页面信息传递及新增UI控件**</center>
## <center>空数3班 3225706082 茅涵馨 </center> 
### 一、补充Index页面  
```JS
//router是ArkUI框架提供的页面路由管理工具，用于实现页面跳转、参数传递、返回等导航操作
import { router } from '@kit.ArkUI';
//BusinessError是ArkTS中定义的业务错误类型，用于处理应用中的异常情况。
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
  //定义组件名为Index
struct Index {
  @State account: string = '';
  @State password: string = '';
  @State accountError: boolean = false;
  @State showError: boolean = false;
  @State isDarkMode: boolean = false;

  //UI构建方法build（）
  build() {
    Row(){
      Column() {
        //UI内容

        //图片组件，引用应用资源中的图片
        Image($r('app.media.background'))
          .width('50%')
          .aspectRatio(1)

        //账号
        TextInput({ placeholder: '请输入账号' })
          .placeholderColor(Color.Grey)
          .placeholderFont({ size: 14, weight: 400 })
          .caretColor(Color.Blue)
          .width(300)
          .height(40)
          .margin(20)
          .fontSize(24)
          .fontColor(Color.Black)//空值检测
          .onChange((value: string) => {
            this.account = value;
            this.accountError = value.trim().length === 0;
          })
        if (this.accountError) {
          Text('账号不能为空！')
            .fontSize(20)
            .fontColor(Color.Red)
        }

        //密码
        TextInput({ placeholder: '请输入密码' })
          .placeholderColor(Color.Grey)
          .placeholderFont({ size: 14, weight: 400 })
          .caretColor(Color.Blue)
          .width(300)
          .height(40)
          .margin(20)
          .fontSize(24)
          .fontColor(Color.Black)
          .type(InputType.Password)
          .maxLength(10)
          .showPasswordIcon(true)
          .onChange((value: string) => { //监听输入变化
            this.password = value;
            this.showError = value.length > 0 && value.length < 5;
          })
        if (this.showError) {
          Text('密码不能少于5位!')
            .fontSize(20)
            .fontColor(Color.Red)
            .margin({ top: -10, bottom: 10 })
        }

        //添加按钮，以响应用户点击
        Button() {
          Text('登录')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        //设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FF8')
        .width('40%')
        .height('5%')
        .enabled(this.account.trim().length > 0 && this.password.length >= 5)
        .opacity(this.account && this.password ? 1 : 0.5)

        //（异步事件处理）跳转按钮绑定onClick事件，点击时触发回调函数
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Next' button.`)
          //跳转到第二页
          //用到了Promise链式调用；.then（）代表跳转成功时执行，打印成功日志；.catch()代表跳转失败时捕获BusinessError错误，输出错误码和消息
          router.pushUrl({ url: 'pages/Second' }).then(() => {
            console.info(`Succeeded in jumping to the second page.`)
          }).catch((err: BusinessError) => {
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })
        })

        //添加注册按钮
        Button() {
          Text('注册')
            .fontSize(20)
        }
        .type(ButtonType.Normal)
        .margin({ top: 20 })
        .width(90)
        .height(30)
        .backgroundColor(Color.Transparent)
        .onClick(() => {
          router.pushUrl({ url: 'pages/Register' })
            .then(() => {
              console.info('跳转到注册页面成功');
            })
            .catch((err: BusinessError) => {
              console.error(`跳转失败，错误码：${err.code}, 消息：${err.message}`);
            });
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```

### 二、Second页面  

``` JS 
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Second {
  @State message: string = '登录成功！';

  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)

        Button() {
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FF8')
        .width('40%')
        .height('5%')
        //跳转按钮绑定onClick事件，点击时返回到第一页
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Back' button.`)
          try {
            /*返回第一页
            此函数完成页面跳转
            try-catch：捕获可能抛出的异常*/
            router.back()
            console.info(`Succeeded in returning to the first page.`)
          }catch (err) {
            let code = (err as BusinessError).code;
            let message = (err as  BusinessError).message;
            console.error(`Failed to return to the first page. Code is ${code},message is ${message}`)
          }
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
### 三、Register页面

```JS
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Register {
    //定义变量
  @State username: string = '';
  @State password: string = '';
  @State confirmPassword: string = '';
  @State usernameError: boolean = false;
  @State passwordError: boolean = false;
  @State confirmError: boolean = false;

  build() {
    Row() {
      Column() {
        Image($r('app.media.background'))
          .width('50%')
          .aspectRatio(1)

        // 用户名输入
        TextInput({ placeholder: '请输入用户名' })
          .placeholderColor(Color.Grey)
          .width(300)
          .height(40)
          .margin(20)
          .onChange((value: string) => {
            this.username = value;
            this.usernameError = value.trim().length === 0;
          })
          //提示错误，需输入用户名
        if (this.usernameError) {
          Text('用户名不能为空')
            .fontColor(Color.Red)
        }

        // 密码输入
        TextInput({ placeholder: '请输入密码（至少5位）' })
          .type(InputType.Password)
          .width(300)
          .height(40)
          .margin(20)
          //校验密码长度
          .onChange((value: string) => {
            this.password = value;
            this.passwordError = value.length < 5;
          })
        if (this.passwordError) {
          Text('密码不能少于5位')
            .fontColor(Color.Red)
        }

        // 确认密码
        TextInput({ placeholder: '请确认密码' })
          .type(InputType.Password)
          .width(300)
          .height(40)
          .margin(20)
          //验证密码是否一致
          .onChange((value: string) => {
            this.confirmPassword = value;
            this.confirmError = this.password !== value;
          })
        if (this.confirmError) {
          Text('密码不一致')
            .fontColor(Color.Red)
        }

        Button('立即注册')
          .type(ButtonType.Capsule)
          .width('40%')
          .height(50)
          .margin(20)
          .backgroundColor('#0D9FFB')
          .enabled(
            this.username.trim() !== '' &&
              this.password.length >= 5 &&
              this.confirmPassword === this.password
          )
          //跳转页面，捕捉异常
          .onClick(() => {
            router.replaceUrl({ url: 'pages/Second' }) // 替换当前页面
              .then(() => {
                console.info('注册成功，跳转到结果页');
              })
              .catch((err: BusinessError) => {
                console.error(`跳转失败：${err.code}, ${err.message}`);
              });
          })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```

### 四、截图
#### 1、Index页面
没有输入用户名，登录键无法使用
![alt text](<屏幕截图 2025-04-04 221157-1.png>)

同时会提示账号不能为空

![alt text](<屏幕截图 2025-04-04 222214.png>)

点击注册
#### 2、Register（注册）页面
![alt text](<屏幕截图 2025-04-04 221537.png>)

输入用户名，输入密码

若密码少于五位数则会提示

![alt text](<屏幕截图 2025-04-04 221808.png>)

若两次输入的密码不一样也会提示

![alt text](<屏幕截图 2025-04-04 221923.png>)

输入无误后即可注册

![alt text](<屏幕截图 2025-04-04 222036.png>)

注册后就可以登录了

![alt text](<屏幕截图 2025-04-04 222111.png>)
#### 3、Second页面
输入账号密码就可以登录了

![alt text](<屏幕截图 2025-04-04 222302.png>)
![alt text](<屏幕截图 2025-04-04 222330.png>)