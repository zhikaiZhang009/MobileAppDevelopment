// Second.ets
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Second {
  @State message: string = 'Hi there';
  @State receivedData: string = ''; // 用于存储接收到的数据
  @State inputValue: string = ''; // 用于绑定输入框的值
  @State sliderValue: number = 50; // 用于绑定滑块的值
  @State isToggleOn: boolean = false; // 用于绑定开关的状态
  aboutToAppear() {
    // 在页面加载时获取传递的参数
    let params = router.getParams() as Record<string, string>;
    if (params && params['data']) {
      this.receivedData = params['data']; // 将参数赋值给状态变量
    }
  }

  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold);
        Text(` ${this.receivedData}`) // 显示接收到的数据
          .fontSize(30)
          .margin({ top: 20 });
        TextInput({ placeholder: 'Enter something...' })
          .width('80%')
          .height(40)
          .margin({ top: 20 })
          .onChange((value: string) => {
            this.inputValue = value; // 更新输入框的值
            console.info(`Input value: ${this.inputValue}`);
          });

        // 添加一个滑块组件
        Slider({
          value: this.sliderValue,
          min: 0,
          max: 100,
          step: 1,
          style: SliderStyle.OutSet
        })
          .width('80%')
          .margin({ top: 20 })
          .onChange((value: number) => {
            this.sliderValue = value; // 更新滑块的值
            console.info(`Slider value: ${this.sliderValue}`);
          });

        // 添加一个开关组件
        Toggle({ type: ToggleType.Checkbox, isOn: this.isToggleOn })
          .margin({ top: 20 })
          .onChange((isOn: boolean) => {
            this.isToggleOn = isOn; // 更新开关的状态
            console.info(`Toggle is ${this.isToggleOn ? 'on' : 'off'}`);
          });

        Button() {
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold);
        }
        .type(ButtonType.Capsule)
        .margin({ top: 20 })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Back' button.`);
          try {
            // 返回第一页
            router.back();
            console.info('Succeeded in returning to the first page.');
          } catch (err) {
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`);
          }
        });
      }
      .width('100%');
    }
    .height('100%');
  }
}


