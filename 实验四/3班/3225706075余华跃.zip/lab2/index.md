// Index.ets
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct Index {
  @State message: string = 'Hello World';
  @State inputValue: string = ''; // 用于绑定输入框的值
  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        TextInput({ placeholder: '请输入姓名' })
          .width('80%')
          .height(40)
          .margin({ top: 20 })
          .onChange((value: string) => {
            this.inputValue = value; // 更新输入框的值
            console.info(`Input value: ${this.inputValue}`);
          });
        Button() {
          Text('Next')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({ top: 20 })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Next' button.`);
          // 跳转到第二页，并传递参数
          router.pushUrl({
            url: 'pages/Second',
            params: { data: this.inputValue} // 传递参数
          }).then(() => {
            console.info('Succeeded in jumping to the second page.');
          }).catch((err: BusinessError) => {
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
          });
        });
      }
      .width('100%');
    }
    .height('100%');
  }
}


