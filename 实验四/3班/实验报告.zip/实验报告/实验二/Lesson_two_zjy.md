# <a href="#" style="display: block; text-align: center;">实验二：基本组件</a>
## 一、实验说明
&emsp; 本次实验增加了不同页面参数的传值，以及添加了四个基本组件分别为Checkbox、Image、Select以及DatePicker
## 二、实验代码的展示
第一个页面：Index.ets
```TypeScript{.line-numbers}
//Index.ets

//导入页面路由模块
//import { router } from  '@kit.ArkUI';
import { BusinessError } from  '@kit.BasicServicesKit';
import router from '@ohos.router';

@Entry
@Component
struct Index {
  //定义状态变量
  @State message: string = '借阅书籍选择'
  @State reading: string = '实体书'
  @State listening: string = '电子书'
  build() {
    Row() {
      Column() {
        //创建文本
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)

        //添加下拉选择菜单，以提供多个选项给用户选择
        //设置下拉列表值和图标
        Select([{ value: '收获', icon: $r('app.media.book1') },
          { value: '活着', icon: $r('app.media.book2') }])
          .selected(2) //选中的下拉列表索引
          .value('余华作品集') //下拉按钮本身的文本内容
          .font({ size: 16, weight: 500 }) //下拉按钮本身的文本样式
          .fontColor('#182431') //下拉按钮本身的文本颜色
          .selectedOptionFont({ size: 16, weight: 400 })
          //下拉菜单选中项的文本样式
          .optionFont({ size: 16, weight: 400 })//下拉菜单项的文本样式

        //添加多选框，以提供用户读书方式
        //设置多选框名称、多选框的群组名称
        Checkbox({ name: 'one', group: 'checkboxGroup' })
          .select(false) //设置默认选中
          .selectedColor(0xed6f21) //设置选中颜色
          .onChange((value: boolean) => {
            console.info('Checkbox1 change is' + value)
          }) //设置选中事件
        Text(this.reading) //设置多选框名称
        Checkbox({ name: 'two', group: 'checkboxGroup' })
          .select(false)
          .selectedColor(0xed6f21)
          .onChange((value: boolean) => {
            console.info('Checkbox2 change is' + value)
          })
        Text(this.listening)

        //添加按钮，以响应用户点击
        Button() {
          Text('Next')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
        //跳转按钮绑定onClick事件，点击时跳转到第二页
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Next' Button.`)
          //跳转到第二页
          router.pushUrl({
            url: 'pages/Second', //设置传参的页面URL
            params: {src: '借阅书籍',} //设置传参的值
          }).then(() =>{
            console.info('Succeeded in jumping to the second page.')

          }).catch((err: BusinessError) => {
            console.error(`Failed to jump to the second page. Code is ${err.code},message is ${err.message}`)
          })
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
第二个页面：Second.ets
```TypeScript
//Second.ets

//导入页面路由模块
//import { router } from '@kit.ArkUI'
import { BusinessError } from '@kit.BasicServicesKit'
import router from '@ohos.router';

@Entry
@Component
struct Second {
  @State message: string = '借阅起始时间'
  @State src: object = router.getParams() //接收Index.ets传来的参数
  build() {
    Row() {
      Column(){
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //显示传参的内容
        Text(this.src?.['src'])
          .fontSize(20) //设置内容大小
          .fontWeight(FontWeight.Normal) //设置内容宽度
        //显示书籍的图片
        Image($r('app.media.booking')) //设置本地图片的位置
          .width(180) //设置图片宽度
          .height(180) //设置图片高度
        //添加选择日期的滑动选择器组件
        DatePicker({
          start: new Date('2000-1-1'),
          //设置选择器的起始时间。默认值为Date（'1970-1-1')
          end: new Date('2100-12-31'),
          //设置选择器的结束时间。默认值为Date（'2100-12-31')
          selected: new Date(),
          //设置选中项的日期。默认值为当前系统日期
        })
        //添加按钮，以响应用户点击
        Button(){
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
        //返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Back' button.`)
          try {
            //返回第一页
            router.back()
            console.info('Succeeded in returning to the first page.')
          }catch (err) {
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            console.error(`Failed to return to the first page. Code is ${code},message is ${message}`)
          }
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
## 三、实验结果展示
第一页：Index.ets
![alt text](截图一.png)
第二页：Second.ets
![alt text](截图二.png)
