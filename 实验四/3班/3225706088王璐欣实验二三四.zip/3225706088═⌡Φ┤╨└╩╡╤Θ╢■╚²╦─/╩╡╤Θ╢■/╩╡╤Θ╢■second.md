```
// 导入ArkUI路由模块，用于页面导航操作
import { router } from '@kit.ArkUI';
// 导入基础服务错误类型，用于类型化错误处理
import { BusinessError } from '@kit.BasicServicesKit';

// 入口组件装饰器（表示这是应用入口页面）
@Entry
// 组件装饰器（声明为可复用组件）
@Component
// 定义Second页面组件
struct Second {
  // 状态管理：页面标题（@State装饰器实现数据驱动）
  @State message: string = 'Details Page'
  // 颜色方案（与首页保持视觉一致性）
  private primaryColor: string = '#0D9FFB'  // 主色调（按钮/标题）
  private bgColor: string = '#F9F9F9'      // 页面背景色
  private surfaceColor: string = '#F5F5F5' // 表面色（导航栏背景）

  // 构建UI布局
  build() {
    // 根布局：横向排列（Row）
    Row() {
      // 主内容列：纵向排列（Column）
      Column() {
        /* ================= 导航栏区域 ================= */
        // 导航栏容器（Row横向布局）
        Row() {
          // 返回图标按钮
          Text('🔙')                  // Unicode左箭头符号
            .fontSize(40)            // 图标大小40vp
            .margin({ right: 10 })   // 右外边距10vp
            .onClick(() => router.back()) // 点击返回上一页
          
          // 页面标题文本
          Text(this.message)         // 绑定message状态变量
            .fontSize(24)            // 字体大小24vp
            .fontColor(this.primaryColor) // 使用主色调
        }                            // 结束导航栏Row容器
        .width('100%')              // 宽度100%填充父容器
        .padding(15)                // 内边距15vp
        .backgroundColor(this.surfaceColor) // 设置导航栏背景色

        /* ================= 详情卡片区域 ================= */
        // 卡片容器（Column纵向布局）
        Column() {
          // 卡片标题
          Text('📌 Product Info')     // 带图钉图标的标题
            .fontSize(30)            // 字体大小30vp
            .margin({ bottom: 10 })  // 下边距10vp
          
          // ===== 产品名称条目 =====
          Row() {                    // 横向布局容器
            Text('• Name:')         // 条目标签
              .fontSize(20)         // 字体20vp
              .width(80)            // 固定宽度80vp
            Text('Premium Package') // 产品名称
              .fontSize(20)        // 字体20vp
              .fontColor('#666')    // 深灰色文字
          }.margin({ bottom: 8 })   // 下边距8vp
          
          // ===== 价格条目 =====
          Row() {
            Text('• Price:')        // 价格标签
              .fontSize(20)
              .width(80)
            Text('$299.99')         // 价格数值
              .fontSize(20)
              .fontColor('#FF4500') // 橙色强调色
          }.margin({ bottom: 8 })   // 下边距8vp
          
          // ===== 状态条目 =====
          Row() {
            Text('• Status:')       // 状态标签
              .fontSize(20)
              .width(80)
            Text('Available')       // 可用状态
              .fontSize(20)
              .fontColor('#32CD32') // 绿色表示可用
          }                         // 结束状态Row容器
        }                           // 结束卡片Column容器
        .padding(20)               // 卡片内边距20vp
        .margin(15)                // 卡片外边距15vp
        .backgroundColor(Color.White) // 白色背景
        .borderRadius(15)          // 圆角15vp
        .shadow({                  // 添加阴影效果
          radius: 10,              // 阴影半径10vp
          color: '#00000010',      // 半透明黑色（16进制RGBA）
          offsetX: 2,             // X轴偏移2vp
          offsetY: 2             // Y轴偏移2vp
        })

        /* ================= 操作按钮组 ================= */
        // 按钮横向容器
        Row() {
          // ===== 收藏按钮 =====
          Button() {                // 按钮组件开始
            Text('❤️\nCollect')    // 两行文本（图标+文字）
              .fontSize(16)       // 字体16vp
          }                         // 结束Button组件
          .width(100)             // 固定宽度100vp
          .height(80)              // 固定高度80vp
          .margin({ right: 15 })   // 右外边距15vp
          .backgroundColor('#FFF0F5') // 浅粉色背景
          .borderRadius(12)        // 圆角12vp
          
          // ===== 分享按钮 =====
          Button() {
            Text('📤\nShare')     // 分享图标+文字
              .fontSize(16)
          }
          .width(100)
          .height(80)
          .margin({ right: 15 })   // 右外边距15vp
          .backgroundColor('#F0F8FF') // 浅蓝色背景
          .borderRadius(12)
          
          // ===== 联系按钮 =====
          Button() {
            Text('📞\nContact')   // 电话图标+文字
              .fontSize(16)
          }
          .width(100)
          .height(80)
          .backgroundColor('#F5F5DC') // 米色背景
          .borderRadius(12)
        }                           // 结束按钮组Row容器
        .margin({ top: 20 })        // 上边距20vp
        .justifyContent(FlexAlign.Center) // 水平居中排列

        /* ================= 返回按钮区域 ================= */
        Button() {                  // 按钮组件开始
          Text('Back to Home')     // 按钮文本
            .fontSize(24)          // 大号字体24vp
            .fontWeight(FontWeight.Bold) // 加粗字体
        }                           // 结束Button组件
        .type(ButtonType.Capsule)  // 胶囊样式按钮
        .margin({ top: 30 })       // 上边距30vp
        .backgroundColor(this.primaryColor) // 主色背景
        .width('50%')             // 宽度占父容器50%
        .height(50)               // 固定高度50vp
        .onClick(() => {           // 点击事件处理
          try {                    // 异常捕获块
            router.back()         // 执行返回操作
            console.info('Returned to home page.') // 成功日志
          } catch (err) {         // 错误捕获
            const error = err as BusinessError // 类型转换
            console.error(`Back failed: ${error.code} - ${error.message}`) // 错误日志
          }
        })
      }                            // 结束主内容Column容器
      .width('100%')              // 宽度100%填充父Row
    }                              // 结束根布局Row容器
    .height('100%')               // 高度100%填充父容器
    .padding(10)                 // 根容器内边距10vp
    .backgroundColor(this.bgColor) // 应用页面背景色
  }                               // 结束build方法
}                                 // 结束Second组件
```

![](D:\桌面\3225706088王璐欣实验二三四\实验二\page2.png)