```
// 导入路由模块和错误类型
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

// 入口组件装饰器
@Entry
// 组件装饰器
@Component
// 定义Index组件
struct Index {
  // 状态管理：页面主标题（使用@State装饰器实现数据驱动更新）
  @State message: string = 'Welcome'
  // 状态管理：搜索框输入内容
  @State searchText: string = ''
  // 状态管理：About按钮悬停状态
  @State aboutHover: boolean = false
  
  // 颜色方案定义（私有属性）
  private primaryColor: string = '#0D9FFB'  // 主色调（用于按钮/标题）
  private bgColor: string = '#F9F9F9'      // 页面背景色
  private surfaceColor: string = '#F5F5F5' // 表面色（用于导航栏）

  // 构建UI布局
  build() {
    // 根布局：横向排列（Row）
    Row() {
      // 主内容列：纵向排列（Column）
      Column() {
        /* ------------------------- 顶部导航栏区域 ------------------------- */
        // 导航栏横向容器
        Row() {
          // 主页图标
          Text('🏠')                    // Unicode字符：🏠
            .fontSize(40)              // 字体大小40vp
            .margin({ right: 10 })     // 右外边距10vp
          
          // 应用标题文本
          Text('Home Page')             
            .fontSize(24)               // 字体大小24vp
            .fontColor(this.primaryColor) // 使用主色调
        }                               // 结束导航栏Row容器
        .width('100%')                 // 宽度100%填充父容器
        .padding(15)                    // 内边距15vp
        .backgroundColor(this.surfaceColor) // 设置背景色

        /* ------------------------- 搜索区域 ------------------------- */
        // 搜索输入框组件
        TextInput({ placeholder: 'Search...' }) // 设置占位符文本
          .width('90%')               // 宽度占父容器的90%
          .height(50)                 // 高度50vp
          .margin({ 
            top: 20,                   // 上边距20vp
            bottom: 15                 // 下边距15vp
          })                           
          .padding(10)                // 输入框内边距10vp
          .borderRadius(25)            // 圆角半径25vp（实现胶囊形状）
          .backgroundColor(Color.White) // 白色背景

        /* ------------------------- 主标题区域 ------------------------- */
        // 动态文本显示（绑定message状态变量）
        Text(this.message)             
          .fontSize(50)                // 超大字体50vp
          .fontWeight(FontWeight.Bold) // 加粗字体
          .margin({ bottom: 30 })      // 下边距30vp

        /* ------------------------- 内容卡片区域 ------------------------- */
        // 卡片容器（Column布局）
        Column() {
          // 卡片内容文本
          Text('📷 Featured Content')  // 带图标的文本
            .fontSize(30)              // 字体30vp
            .margin(15)                // 四周15vp边距
        }                              // 结束Column容器
        .padding(15)                   // 卡片内边距15vp
        .backgroundColor(Color.White)  // 白色背景
        .borderRadius(15)              // 圆角15vp

        /* ------------------------- 功能按钮组区域 ------------------------- */
        // 按钮横向排列容器
        Row() {
          // ========== FAQ按钮 ==========
          // 胶囊样式按钮
          Button() {                    // 按钮组件开始
            // 按钮内部横向布局
            Row() {
              Text('❓')              // 问号图标（Unicode）
                .fontSize(24)          // 图标大小24vp
                .fontColor(Color.White)// 白色图标
                .margin({ right: 8 })  // 图标右间距8vp
              
              Text('FAQ')              // 按钮文字
                .fontColor(Color.White)// 白色文字
                .fontSize(16)          // 文字大小16vp
            }                          // 结束内部Row布局
            .padding(10)               // 按钮内边距10vp
          }                            // 结束Button组件
          .type(ButtonType.Capsule)    // 设置为胶囊按钮样式
          .backgroundColor(this.primaryColor) // 主色背景
          .width(140)                 // 固定宽度140vp
          .height(45)                  // 固定高度45vp
          .shadow({                    // 添加阴影效果
            radius: 8,                 // 阴影半径8vp
            color: Color.Gray,         // 灰色阴影
            offsetX: 2,               // X轴偏移2vp
            offsetY: 2                // Y轴偏移2vp
          })

          // ========== About按钮 ==========
          Button() {                   // 按钮组件开始
            Row() {
              Text('ⓘ')              // 信息图标（Unicode）
                .fontSize(20)          // 图标大小20vp
                .fontColor(this.primaryColor) // 主色图标
                .margin({ right: 8 })  // 图标右间距8vp
              
              Text('About')            // 按钮文字
                .fontSize(16)         // 文字大小16vp
                .fontColor(this.primaryColor) // 主色文字
            }
          }                            // 结束Button组件
          .type(ButtonType.Normal)     // 普通按钮样式
          .borderRadius(20)            // 圆角20vp
          .width(140)                  // 固定宽度140vp
          .height(45)                  // 固定高度45vp
          .margin({ left: 15 })        // 左外边距15vp
          .backgroundColor(Color.White) // 白色背景
          .border({                    // 添加边框
            width: 2,                  // 边框宽度2vp
            color: this.primaryColor   // 主色边框
          })
          .onHover(hover => {          // 悬停事件监听
            this.aboutHover = hover    // 更新悬停状态
          })
          .stateEffect(this.aboutHover) // 应用悬停状态效果
        }                              // 结束按钮组Row容器
        .justifyContent(FlexAlign.Center) // 水平居中排列
        .width('100%')                 // 宽度100%填充
        .margin({ top: 25 })           // 上边距25vp

        /* ------------------------- 页面跳转按钮 ------------------------- */
        Button() {                      // 按钮组件开始
          Text('Next')                 // 按钮文字
            .fontSize(30)              // 超大字体30vp
            .fontWeight(FontWeight.Bold) // 加粗字体
        }                              // 结束Button组件
        .type(ButtonType.Capsule)      // 胶囊样式
        .margin({ top: 30 })           // 上边距30vp
        .backgroundColor(this.primaryColor) // 主色背景
        .width('40%')                  // 宽度占父容器40%
        .height(50)                    // 高度50vp
        .onClick(() => {               // 点击事件处理
          // 执行路由跳转（跳转到Second页面）
          router.pushUrl({ url: 'pages/Second' })
            // 错误捕获
            .catch((err: BusinessError) => {
              console.error(`Routing failed: ${err.code}`) // 打印错误信息
            })
        })
      }                                // 结束主内容Column容器
      .width('100%')                  // 宽度100%填充父Row
    }                                  // 结束根布局Row容器
    .height('100%')                   // 高度100%填充父容器
    .padding(10)                      // 根容器内边距10vp
    .backgroundColor(this.bgColor)    // 应用背景色
  }                                   // 结束build方法
}                                     // 结束Index组件
```

![](D:\桌面\3225706088王璐欣实验二三四\实验二\page1.png)

![](D:\桌面\3225706088王璐欣实验二三四\实验二\日志.png)