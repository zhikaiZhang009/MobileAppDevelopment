```typescript
import  router  from '@ohos.router';

import { BusinessError } from '@kit.BasicServicesKit';

@Entry

@Component

struct Page {

  @State message: string = '鸿蒙登录';

  @State selectedDate: Date = new Date(2025, 2, 7);

  @State account: string = '';

  @State password: string = '';

  private handleLogin(): void {

    if (!this.account || !this.password) {

      console.error('账号密码不能为空');

      return;

    }

    console.info(`登录请求：账号=${this.account}`);

  }

  build(): void {

    Column({ space: 10 }) {

      Text(this.message)

        .fontSize(30)

        .fontWeight(FontWeight.Bold)

        .margin({ top: 40, bottom: 30 })

      Column({ space: 15 }) {

        TextInput({ placeholder: '请输入账号' })

          .width('80%')

          .height(40)

          .padding(8)

          .borderRadius(8)

          .backgroundColor(Color.White)

          .onChange((value: string) => {

            this.account = value;

          })

        TextInput({ placeholder: '请输入密码' })

          .width('80%')

          .height(40)

          .padding(8)

          .type(InputType.Password)

          .borderRadius(8)

          .backgroundColor(Color.White)

          .onChange((value: string) => {

            this.password = value;

          })

        Button('立即登录', { type: ButtonType.Capsule })

          .width('60%')

          .height(45)

          .backgroundColor('#0D9FFB')

          .margin({ top: 20 })

          .onClick(() => this.handleLogin())

        Row() {

          Text('没有账号？')

            .fontSize(14)

          Text('立即注册')

            .fontSize(14)

            .fontColor('#0D9FFB')

            .onClick(() => {

              router.pushUrl({ url: 'pages/RegisterPage' })

                .catch((err: BusinessError) => {

                  console.error(`跳转失败: ${err.code}, ${err.message}`);

                });

            })

        }

        .margin({ top: 10 })

      }

      .width('100%')

      .alignItems(HorizontalAlign.Center)

      DatePicker({

        start: new Date(1970, 0, 1),

        end: new Date(2100, 0, 1),

        selected: this.selectedDate

      })

        .width('90%')

        .margin({ top: 30 })

      Button('Next >>')

        .type(ButtonType.Capsule)

        .width('40%')

        .height(45)

        .backgroundColor('#0D9FFB')

        .margin({ top: 30 })

        .onClick(() => {

          console.info('Succeeded in clicking the \'Next\' button.')

          router.pushUrl({ url: 'pages/Page1',params: { src: '第一个页面传输的数据' } })

        })

    }

    .width('100%')

    .height('100%')

    .backgroundColor('#F8F8F8')

  }

}
```
