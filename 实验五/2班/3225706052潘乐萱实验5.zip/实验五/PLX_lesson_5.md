# 实验五报告

> 学号：3225706052
> 
> 姓名：潘乐萱
> 
> 指导老师：张凯斌
> 
> 实验日期：2023-04-02

## 一、实验目的

- 完成移动APP的原始框架，将作为后续系统的承载容器；
- 掌握教科书中网络编程相关部分练习；

## 二、实验内容

- 阅读教科书的第7章“网络编程”；
- 结合理论课要求完成本次APP框架设计；

## 三、实验要求

- Loading Page：完成起始页展示
  - 展示个性化设计
  - 可采用点击或定时方式完成跳转
- Login/Registration Page：实现登录/注册功能
  - 本次实验只要求完成页面设计
  - 具体功能在后续实验中完成
    - 主要涉及关系数据库操作
- Home Page：主界面，承担APP主要功能展示（以按钮形式）和跳转
  - 本次实验实现三个功能（按钮）
    - 请求图像
      - 要求使用Image组件的ArrayBuffer形式，<font color=red>不能直接使用URL返回</font>
      - Image组件可直接放在Home Page
    - 请求JSON
      - 采用RichText组件展示请求后的数据
      - RichText在新页面，需跳转
      - 理解异步/同步概念，实现页面跳转后的数据正确展示
    - 请求Web
      - 采用Web组件，直接请求本地HTML，展示2019年世界各国农作物产量预测系统
        - HTML文件在实验五Git课程仓库
      - Web组件在新页面，需跳转
      - 初步理解Web应用，为后续WebGIS二次开发打基础
- 撰写并提交实验报告；
  - <font color=red>实验步骤部分需严格按模板要求撰写</font>

## 四、实验步骤

### 1. Loading Page

#### 1.1 截图展示
等到页面:
![LoadingPage](Screenshot_2025-04-09T160849.png)

#### 1.2 代码实现

LoadingPage.ets：
```typescript {.line-numbers}
import router from '@ohos.router'; // 导入路由模块，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit'; // 导入业务错误类型，用于错误处理

@Entry
@Component
struct LoadingPage {
  // 定义一个名为 LoadingPage 的组件
  build() {
    Column({ space: 20 }) {
      // 显示欢迎文本
      Text('欢迎来到农作物产量预测系统')
        .fontSize(24) // 设置字体大小
        .fontWeight(FontWeight.Bold) // 设置字体加粗

      // 显示图片
      Image($r('app.media.kitty')) // 使用资源 ID 加载图片
        .width(200).height(200).margin(15) // 设置图片的宽度、高度和外边距
        .overlay('',{ align: Alignment.Bottom, offset: { x: 0, y: 20 } })

      // 显示进度条
      Progress({ value: 150, total: 150, type: ProgressType.Linear }).color(Color.Green).value(150).width(250)
        .style({ strokeWidth: 10, enableSmoothEffect: true }) // 设置进度条的样式，包括线宽和启用平滑效果

      // 显示按钮并设置点击事件
      Button('点击进入', { type: ButtonType.Capsule, stateEffect: true }) // 创建一个胶囊形状的按钮，并启用状态效果
        .backgroundColor(0x6a8d6d) // 设置按钮背景颜色
        .width(90) // 设置按钮宽度
        .onClick(() => {
          // 按钮点击事件处理函数
          try {
            router.pushUrl({ url: "pages/LoginPage" }); // 跳转到登录页面
          } catch (err) {
            const error = err as BusinessError; // 将错误转换为 BusinessError 类型
            console.error(`跳转失败： ${error.code} - ${error.message}`); // 输出错误信息到控制台
          }
        })
    }.width('100%').height('100%').justifyContent(FlexAlign.Center).backgroundColor(0xfff8eb)
    // 设置列的宽度、高度、内容对齐方式和背景颜色
  }
}
```


### 2. Login/Registration Page

#### 2.1 截图展示
登录/注册页面:
![LoginPage](Screenshot_2025-04-09T160852.png)

#### 2.2 代码实现

LoginPage.ets：
```typescript {.line-numbers}
import router from '@ohos.router'; // 导入路由模块，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit'; // 导入业务错误类型，用于错误处理

@Entry
@Component
struct LoginPage {
  // 定义一个名为 LoginPage 的组件
  build() {
    Column() { 
      // 显示标题文本“农作物产量预测系统”
      Text('农作物产量预测系统')
        .fontSize(30) // 设置字体大小
        .fontWeight(FontWeight.Bold) // 设置字体加粗
        .margin({ bottom: 10 }) // 设置底部外边距

      // 显示子标题文本“用户登录”
      Text('用户登录')
        .fontSize(20) // 设置字体大小
        .fontWeight(FontWeight.Bold) // 设置字体加粗
        .margin({ bottom: 40 }) // 设置底部外边距

      // 创建一个账号输入框
      TextInput({ placeholder: '请输入账号' }).margin({ top: 20 })
        .onSubmit((EnterKeyType) => {
          // 当用户点击输入法的回车键时触发此事件
          console.info(EnterKeyType + '输入法回车键的类型值');
        })

      // 创建一个密码输入框
      TextInput({ placeholder: '请输入密码' }).type(InputType.Password).margin({ top: 20, bottom: 180 })
        .onSubmit((EnterKeyType) => {
          // 当用户点击输入法的回车键时触发此事件
          console.info(EnterKeyType + '输入法回车键的类型值');
        })

      // 创建一个登录按钮
      Button('登录').width(150).margin({ top: 20 }).backgroundColor(0x6a8d6d)
        .onClick(() => {
          // 登录按钮点击事件处理函数
          try {
            router.pushUrl({ url: "pages/HomePage" }); // 跳转到主页
          } catch (err) {
            const error = err as BusinessError; // 将错误转换为 BusinessError 类型
            console.error(`跳转失败： ${error.code} - ${error.message}`); // 输出错误信息到控制台
          }
        })

      // 创建一个注册按钮
      Button('注册').width(150).margin({ top: 20 }).backgroundColor(0x236952)
        .onClick(() => {
          // 注册按钮点击事件处理函数
          try {
            router.pushUrl({ url: "pages/HomePage" }); // 跳转到主页（通常这里应该是注册页面，但此处示例为跳转到主页）
          } catch (err) {
            const error = err as BusinessError; // 将错误转换为 BusinessError 类型
            console.error(`跳转失败： ${error.code} - ${error.message}`); // 输出错误信息到控制台
          }
        })
    }.width('100%').height('100%').justifyContent(FlexAlign.Center).backgroundColor(0xfff8eb)
    // 设置列的宽度、高度、内容对齐方式和背景颜色
  }
}
```

### 3. Home Page

#### 3.1 截图展示
主页面:
![HomePage](Screenshot_2025-04-09T160856.png)
点击请求图像:
![点击请求图像](Screenshot_2025-04-09T160904.png)

#### 3.2 代码实现

HomePage.ets：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI'; // 导入路由模块，用于页面跳转
import { http } from '@kit.NetworkKit'; // 导入网络请求模块，用于发送 HTTP 请求
import { image } from '@kit.ImageKit'; // 导入图像处理模块，用于处理图像数据
import { BusinessError } from '@kit.BasicServicesKit'; // 导入业务错误类型，用于错误处理

// 异步函数，用于发送 HTTP GET 请求并获取 JSON 数据
async function jsonHttpReq(): Promise<string> {
  // 使用 Promise 包装异步操作
  const result: string = await new Promise((resolve: Function, reject: Function) => {
    let httpRequest = http.createHttp(); // 创建一个 HTTP 请求实例
    let url = "https://github.com/kaibin-zhang/MobileAppDevelopment/blob/main/example.json"; // JSON 数据的 URL
    let promise = httpRequest.request(
      url,
      {
        method: http.RequestMethod.GET, // 使用 GET 方法
        connectTimeout: 600000, // 连接超时时间（毫秒）
        readTimeout: 600000, // 读取超时时间（毫秒）
        header: { 'Content-Type': 'application/json' } // 请求头，指定内容类型为 JSON
      }
    );

    // 处理 HTTP 请求的响应
    promise.then((data) => {
      if (data.responseCode === http.ResponseCode.OK) { // 检查响应码是否为 200（OK）
        console.info('Result:' + data.result); // 输出响应结果
        console.info('code:' + data.responseCode); // 输出响应码
        let message = JSON.stringify(data.result); // 将响应结果转换为 JSON 字符串
        resolve(message); // 解析 Promise，返回 JSON 字符串
      }
    }).catch((err: BusinessError) => {
      console.info('error:' + JSON.stringify(err)); // 输出错误信息
      reject(`Error:${err}`); // 拒绝 Promise，返回错误信息
    });
  });
  console.info(`The result:${result}`); // 输出最终结果
  return result; // 返回 JSON 字符串
}

@Entry
@Component
struct Homepage {
  @State message: string = '禁止 Hello World'; // 组件状态变量，存储文本消息
  @State imagePixel: PixelMap | undefined = undefined; // 组件状态变量，存储图像像素映射

  // 请求图像的私有方法
  private imageHttpReq() {
    let httpRequest = http.createHttp(); // 创建一个 HTTP 请求实例
    let url = "https://github.com/Pnlexuana-52/Svvn.github.io/blob/main/%E7%8C%AB%E7%8C%AB.jpeg?raw=true"; // 图像的 URL
    let promise = httpRequest.request(
      url,
      {
        method: http.RequestMethod.GET, // 使用 GET 方法
        connectTimeout: 60000, // 连接超时时间
        readTimeout: 60000, // 读取超时时间
        header: {
          'Content-Type': 'application/json' // 请求头，指定内容类型为 JSON
        }
      });

    // 处理 HTTP 请求的响应
    promise.then((data) => {
      if (data.responseCode === http.ResponseCode.OK) { // 检查响应码是否为 200（OK）
        console.info('Result:' + data.result); // 输出响应结果
        console.info('code:' + data.responseCode); // 输出响应码

        let imageData: ArrayBuffer = data.result as ArrayBuffer; // 将响应结果转换为 ArrayBuffer
        let imageSource: image.ImageSource = image.createImageSource(imageData); // 创建图像源

        class sizeTmp {
          height: number = 100
          width: number = 100
        }

        let options: Record<string, number | boolean | sizeTmp> = {
          'alphaType': 0,
          'editable': false,
          'pixelFormat': 3,
          'scaleMode': 1,
          'size': { height: 100, width: 100 } // 图像大小选项
        };
        imageSource.createPixelMap(options).then((pixelMap: PixelMap) => {
          this.imagePixel = pixelMap; // 将图像像素映射存储到组件状态中
        });
      }
    }).catch((err: BusinessError) => {
      console.info('error:' + JSON.stringify(err)); // 输出错误信息
    });
  };

  build() {
    Column({ space: 20 }) { // 创建一个垂直布局的列
      Text('选择服务')
        .fontSize(24)
        .fontWeight(FontWeight.Bold)

      // 按钮用于请求图像
      Button('请求图像')
        .onClick(() => this.imageHttpReq())// 点击按钮时调用 imageHttpReq 方法
        .width('80%')
        .margin(10)
        .backgroundColor(0x236952)

      // 如果图像像素映射存在，则显示图像
      if (this.imagePixel) {
        Image(this.imagePixel)
          .width(200)
          .height(200)

        // 按钮用于请求 JSON 数据并跳转到 JSON 显示页面
        Button('请求JSON')
          .width('80%')
          .margin(10)
          .backgroundColor(0x236952)
          .onClick(async () => {
            console.info(`Succeeded in Clicking`);
            try {
              let jsonData = await jsonHttpReq(); // 异步请求 JSON 数据
              await router.pushUrl({
                url: 'pages/JsonDisplayPage',
                params: { src: jsonData } // 将 JSON 数据作为参数传递给目标页面
              })
                .then(() => {
                  console.info(' Succeeded in jumping to the second page'); // 输出跳转成功信息
                })
                .catch((err: BusinessError) => {
                  console.error(`Failed to jump to the JsonDisaplayPage Code is ${err.code}, message is ${err.message}`); // 输出跳转失败信息
                });
            } catch (error) {
              console.error(`Error occurred while fetching JSON data: ${error}`); // 输出获取 JSON 数据时的错误信息
            }
          });

        // 按钮用于跳转到 Web 页面
        Button('请求Web')
          .onClick(() => router.pushUrl({ url: 'pages/WebPage' }))// 点击按钮时跳转到 Web 页面
          .width('80%')
          .margin(10)
          .backgroundColor(0x236952)

      }
    }.width('100%').height('100%').justifyContent(FlexAlign.Center).backgroundColor(0xfff8eb) // 设置列的宽度、高度、对齐方式和背景颜色
  };
}
```

### 4. Function Pages

Function Pages 是各具体功能实现的页面，盛放各自所需组件；

须从Home Page跳转；

本实验有2个Function Pages

- JSON Page
- Web Page

#### 4.1 JSON Page

##### 4.1.1 截图展示
点击请求JSON：
![点击请求JSON](Screenshot_2025-04-09T171020-1.png)

##### 4.1.2 代码实现

JsonDisplayPage.ets：
```typescript {.line-numbers}
// 导入路由模块，用于页面跳转和参数传递
import { router } from '@kit.ArkUI';

// 定义一个页面组件，使用@Entry注解表示这是一个入口组件
@Entry
@Component
struct JsonDisplayPage {
  // 定义一个状态变量，用于存储JSON数据的字符串表示
  @State jsonData: string = '';

  // 页面即将出现时触发的生命周期方法
  aboutToAppear() {
    // 获取路由传递的参数，并将其类型断言为键值对形式的字符串记录
    let params = router.getParams() as Record<string, string>;
    // 检查参数是否存在且包含'src'键
    if (params && params['src']) {
      // 将'src'参数的值赋给jsonData状态变量
      this.jsonData = params['src'];
      // 打印日志信息，表示成功获取到'src'参数
      console.info('Succeeded get src');
    }
  }

  // 定义组件的UI结构
  build() {
    // 使用Column布局容器来组织子组件，设置子组件之间的间距为20
    Column({ space: 20 }) {
      // 显示JSON数据的RichText组件
      RichText(this.jsonData)
        .width('90%') 
        .height('80%') 
        .backgroundColor('#f0f0f0') // 设置背景颜色
        .padding(10) // 设置内边距

      // 返回按钮，点击后返回上一页面
      Button('返回')
        .onClick(() => router.back()) // 绑定点击事件，调用router.back()返回上一页面
        .backgroundColor(0xfff8eb) // 设置按钮背景颜色
    }.width('100%').height('100%').justifyContent(FlexAlign.Center).backgroundColor(0xfff8eb) 
  }
}
```

#### 4.2 Web Page

##### 4.2.1 截图展示
点击请求Web:
![点击请求Web](Screenshot_2025-04-09T170910-1.png)

##### 4.2.2 代码实现

WebPage.ets：
```typescript {.line-numbers}
// 导入ArkWeb的webview模块，用于显示Web内容
import { webview } from '@kit.ArkWeb';


@Entry
@Component
struct WebPage {
  // 创建一个WebviewController实例，用于控制Webview的行为
  controller: webview.WebviewController = new webview.WebviewController();

  // 定义组件的UI结构
  build() {
    // 使用Column布局容器来组织子组件
    Column() {
      // 嵌入一个Web组件，用于显示Web内容
      Web({
        src: $rawfile('Agricultural_Crop_Yields_WebApp.html'), // 指定Web内容的来源，这里是一个本地HTML文件
        controller: this.controller // 绑定WebviewController实例，用于控制Webview
      }) // 本地HTML文件路径
    }.backgroundColor(0xfff8eb) // 设置Column背景颜色
  }
}
```
