```typescript
async loadImage() : Promise<void>{
  this.loading = true; // 设置加载状态为 true

  try {
  const imageUrl = 'https://ww3.sinaimg.cn/mw690/9516662fgy1hct88xfrd9j20k00k0dho.jpg';
  const httpRequest = http.createHttp();

  // 发起 HTTP 请求获取图片数据
  let response = await httpRequest.request(
    imageUrl,
    {
      method: http.RequestMethod.GET,
      connectTimeout: 10000, // 设置超时时间为 10 秒
    });

  if (response.responseCode === http.ResponseCode.OK) {
  console.info('Image loaded successfully.');

  // 将返回的数据转换为 ArrayBuffer
  let imgData: ArrayBuffer = response.result as ArrayBuffer;

  // 使用 ImageSource 创建图片源
  let imgSource = image.createImageSource(imgData);

  // 创建 PixelMap
  let options: Record<string,number  | boolean  | Size> = {
  'alphaType':0,
  'editable':false,
  'piexlFormat':3,
  'scaleMode':1,
  'size':{height:100,width:100}
};

let pixelMap = await imgSource.createPixelMap(options);
this.pixelMapImg = pixelMap; // 更新图片数据
} else {
  console.error(`Failed to load image. Response code: ${response.responseCode}`);
}
} catch (err) {
  console.error(`Error loading image: ${err.message}`);
} finally {
  this.loading = false; // 无论成功或失败，都设置加载状态为 false
}
}
```
```typescript
async  function jsonHttpReq(): Promise<string>{
  //异步函数，该函数内部包含异步操作，async/await是一种用于处理异步操作的Promise语法糖
  //通过使用async关键字声明一个函数为异步函数，并使用await关键字等待Promise的解析，以同步的方式编写异步操作的代码。
  //Promise：用于处理异步操作的对象，最终函数会返回一个字符串类型的promise对象
  const result: string = await new Promise((resolve:Function,reject:Function)=>{
//创建一个新的promise对象，同时传入一个带有两个参数的函数，executor函数接收两个参数：resolve和reject，分别表示异步操作成功和失败时的回调函数
    //await：等待 Promise 完成，并获取其结果
    //Promise 最终解析出的一个字符串赋给result
    let httpRequest = http.createHttp();
    //创建一个http请求。
    let url = "https://github.com/kaibin-zhang/MobileAppDevelopment/blob/main/example.json";
    //目标服务器的地址

    let promise = httpRequest.request(
      url,
      {
        method:http.RequestMethod.GET,//请求方法
        connectTimeout:600000,//超时时间
        header:{'Content-Type':'application/json'}//请求头，指定内容类型为application/json
      }
    );
    //根据URL地址，发起HTTP网络请求。返回promise对象


    promise.then((data)=>{//http请求成功就执行then回调函数
      //data：服务器返回的响应数据
      if(data.responseCode === http.ResponseCode.OK){//响应状态码是否和成功响应的状态码相同，若相同即👇

        console.info('Result:'+data.result);
        console.info('code:'+data.responseCode);
        //控制台输出结果和响应状态码
        let message = JSON.stringify(data.result);
        //JSON.stringify(data.result)将JSON对象转换成字符串并赋给message
        resolve(message);
        //调用resolve将刚刚转换得到的字符串返回给promise对象
      }
    })//then函数结束


      .catch((err:BusinessError) =>{//http请求失败就执行catch函数
      console.info('error:'+JSON.stringify(err));
      reject(`Error:${err}`);
      //调用reject把错误信息赋给promise
    });//catch结束

  });//结束promise对象的函数操作
  console.info(`The result:${result}`);
  return result;
  //返回result
}
```