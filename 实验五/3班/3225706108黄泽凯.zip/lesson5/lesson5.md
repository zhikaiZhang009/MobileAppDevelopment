# 实验五报告

> 学号：<3225706108>
> 
> 姓名：<黄泽凯>
> 
> 指导老师：<张凯斌>
> 
> 实验日期：<2025-04-10>

## 一、实验目的

- 完成移动APP的原始框架，将作为后续系统的承载容器；
- 掌握教科书中网络编程相关部分练习；

## 二、实验内容

- 阅读教科书的第7章“网络编程”；
- 结合理论课要求完成本次APP框架设计；

## 三、实验要求

- Loading Page：完成起始页展示
  - 展示个性化设计
  - 可采用点击或定时方式完成跳转
- Login/Registration Page：实现登录/注册功能
  - 本次实验只要求完成页面设计
  - 具体功能在后续实验中完成
    - 主要涉及关系数据库操作
- Home Page：主界面，承担APP主要功能展示（以按钮形式）和跳转
  - 本次实验实现三个功能（按钮）
    - 请求图像
      - 要求使用Image组件的ArrayBuffer形式，<font color=red>不能直接使用URL返回</font>
      - Image组件可直接放在Home Page
    - 请求JSON
      - 采用RichText组件展示请求后的数据
      - RichText在新页面，需跳转
      - 理解异步/同步概念，实现页面跳转后的数据正确展示
    - 请求Web
      - 采用Web组件，直接请求本地HTML，展示2019年世界各国农作物产量预测系统
        - HTML文件在实验五Git课程仓库
      - Web组件在新页面，需跳转
      - 初步理解Web应用，为后续WebGIS二次开发打基础
- 撰写并提交实验报告；
  - <font color=red>实验步骤部分需严格按模板要求撰写</font>

## 四、实验步骤

### 1. Loading Page

#### 1.1 截图展示

![[加载界面.png]]{width="200px"}

#### 1.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import router from '@ohos.router';

@Entry
@Component
struct SplashPage {
  @State countDown: number = 5
  private timerId: number = -1

  // 页面生命周期 - 页面显示时启动定时器
  onPageShow() {
    this.startCountdown()
  }

  // 页面生命周期 - 页面销毁时清除定时器
  aboutToDisappear() {
    this.clearTimer()
  }

  // 启动倒计时
  private startCountdown() {
    this.timerId = setInterval(() => {
      if (this.countDown <= 1) {
        this.clearTimer()
        this.navigate()
      } else {
        this.countDown -= 1
      }
    }, 1000)
  }

  // 清除定时器
  private clearTimer() {
    if (this.timerId !== -1) {
      clearInterval(this.timerId)
      this.timerId = -1
    }
  }

  // 路由跳转
  private navigate() {
    router.pushUrl({ url: 'pages/lesson5_LoginPage' })
  }

  build() {
    Stack() {
      // 背景图片
      Image($r('app.media.learn'))
        .objectFit(ImageFit.Cover)
        .width('100%')
        .height('100%')

      // 跳过按钮
      Button(`跳过 ${this.countDown}s`)
        .position({ x: '76%', y: '5%' })
        .backgroundColor('#66000000') // 60%透明度的黑色
        .fontColor(Color.White)
        .fontSize(14)
        .padding({ left: 19, right: 12, top: 6, bottom: 6 })
        .borderRadius(16)
        .height(30)
        .onClick(() => {
          this.clearTimer()
          this.navigate()
        })
    }
    .width('100%')
    .height('100%')
  }
}
```


### 2. Login/Registration Page

#### 2.1 截图展示

![[登录注册.png]]{width=200}

#### 2.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct LoginPage {
  @State message: string = 'Hello World';

  build() {
    RelativeContainer() {
      Column() {
        // 添加标题
        Text('欢迎登录')
          .fontSize(24)
          .fontColor(Color.Black)
          .margin({ bottom: 40 })
          .fontWeight(FontWeight.Bold)

        // 账号输入框
        TextInput({ placeholder: '输入账号' })
          .placeholderColor(Color.Gray)
          .placeholderFont({ size: 16, weight: 400 })
          .caretColor(Color.Blue)
          .width('80%')
          .height(48)
          .margin({ bottom: 20 })
          .fontSize(16)
          .fontColor(Color.Black)
          .borderRadius(8)
          .padding(10)
          .backgroundColor(Color.White)
          .border({
            width: 1,
            color: Color.Gray
          })

        // 密码输入框
        TextInput({ placeholder: '输入密码' })
          .width('80%')
          .height(48)
          .margin({ bottom: 30 })
          .type(InputType.Password)
          .maxLength(9)
          .showPasswordIcon(true)
          .borderRadius(8)
          .padding(10)
          .backgroundColor(Color.White)
          .border({
            width: 1,
            color: Color.Gray
          })

        // 创建 Row 布局容器，用于并排显示按钮
        Row() {
          // 登录按钮
          Button('登录')
            .width('48%')  // 设置为输入框宽度的 48%，使两者加起来是 80%
            .height(40)
            .margin({ right: 14})  // 按钮之间的间距
            .backgroundColor('#ff525559')
            .fontColor(Color.White)
            .fontSize(16)
            .borderRadius(20)
            .shadow({
              radius: 4,
              color: Color.Gray,
              offsetX: 2,
              offsetY: 2
            })
            .onClick(() => {
              router.pushUrl({
                url: 'pages/lesson5_HomePage',
              }).then(() => {
                console.info('Succeeded in jumping to the second page.')
              }).catch((err: BusinessError) => {
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
              })
            })

          // 注册按钮
          Button('注册')
            .width('48%')  // 设置为输入框宽度的 48%，使两者加起来是 80%
            .height(40)
            .backgroundColor('#ff525559')
            .fontColor(Color.White)
            .fontSize(16)
            .borderRadius(20)
            .shadow({
              radius: 4,
              color: Color.Gray,
              offsetX: 2,
              offsetY: 2
            })
            .onClick(() => {
              router.pushUrl({
                url: 'pages/lesson5_HomePage',
              }).then(() => {
                console.info('Succeeded in jumping to the second page.')
              }).catch((err: BusinessError) => {
                console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
              })
            })
        }
        .width('80%')  // Row 容器的宽度设置为 80%，与输入框一致
        .margin({ top: 20 })

      }
      .width('100%')
      .alignItems(HorizontalAlign.Center)
      .padding(20)
    }
    .height('100%')
    .width('100%')
    .backgroundColor('#f5f5f5')
  }
}

```

### 3. Home Page

#### 3.1 截图展示

![[主界面.png]]{width=200}
#### 3.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import router from '@ohos.router';
import { image } from '@kit.ImageKit';        // 图像处理模块
import http from '@ohos.net.http';
import { BusinessError } from '@kit.BasicServicesKit';
async  function jsonHttpReq(): Promise<string>{
  const result: string = await new Promise((resolve:Function,reject:Function)=>{
    let httpRequest = http.createHttp();
    let url = "https://github.com/kaibin-zhang/MobileAppDevelopment/blob/main/example.json";
    let promise = httpRequest.request(
      url,
      {
        method:http.RequestMethod.GET,
        connectTimeout:600000,
        header:{'Content-Type':'application/json'}
      }
    );
    promise.then((data)=>{
      if(data.responseCode === http.ResponseCode.OK){
        console.info('Result:'+data.result);
        console.info('code:'+data.responseCode);
        let message = JSON.stringify(data.result);
        resolve(message);
      }
    })
      .catch((err:BusinessError) =>{
        console.info('error:'+JSON.stringify(err));
        reject(`Error:${err}`);
      });
  });
  console.info(`The result:${result}`);
  return result;
}

@Entry
@Component
struct ImagePage {
  // 组件状态变量
  @State pixelMap: image.PixelMap | undefined = undefined; // 存储图片像素数据
  @State loading: boolean = false;            // 加载状态标识
  @State error: string = '';                  // 错误信息
  @State showImage: boolean = false;          // 控制图片显示状态
  @State message: string = '';

  // 创建HTTP客户端实例（长连接方式）
  private httpClient = http.createHttp();

  // 网络图片加载方法
  private async loadNetworkImage() {
    const url = 'https://c-ssl.duitang.com/uploads/blog/202102/26/20210226103546_8162c.jpeg';
    try {
      // 重置状态
      this.loading = true;    // 开始加载
      this.error = '';        // 清空错误信息
      this.showImage = false; // 隐藏图片
      // 发起HTTP GET请求，指定期望返回ArrayBuffer类型数据
      const response = await this.httpClient.request(url, {
        method: http.RequestMethod.GET,
        expectDataType: http.HttpDataType.ARRAY_BUFFER
      });

      // 检查HTTP响应状态码（200表示成功）
      if (response.responseCode !== http.ResponseCode.OK) {
        throw new Error(`HTTP错误: ${response.responseCode}`);
      }

      // 将响应结果转换为ArrayBuffer
      const arrayBuffer = response.result as ArrayBuffer;
      // 创建图片源（从二进制数据）
      const imageSource = image.createImageSource(arrayBuffer);
      // 创建PixelMap图片（指定目标尺寸为300x300）
      const pixelMap = await imageSource.createPixelMap({
        desiredSize: {
          width: 300,
          height: 300
        }
      });

      // 页面图片变量
      this.pixelMap = pixelMap;  // 存储像素数据
      this.showImage = true;     // 显示图片
    } catch (error) {
      // 错误处理
      this.error = `加载失败: ${error.message}`; // 显示错误信息
      this.showImage = false;                    // 确保图片隐藏
    } finally {
      this.loading = false; // 无论成功与否，结束加载状态
    }
  }


  // 构建UI布局
  build() {
    Column() {
      // 加载状态显示
      if (this.loading) {
        Text("加载中...")
          .fontSize(20)
          .fontWeight(500)
          .fontColor(Color.Gray);
      }

      // 错误信息显示
      if (this.error) {
        Text(this.error)
          .fontSize(20)
          .fontWeight(500)
          .fontColor(Color.Gray);
      }

      // 图片显示区域
      if (this.showImage && this.pixelMap) {
        Image(this.pixelMap)
          .width(300)
          .height(300)
          .margin(20)
          .borderRadius(8)
          .transition({
            type: TransitionType.Insert, // 进入动画
            opacity: 0
          })
          .transition({
            type: TransitionType.Delete, // 退出动画
            opacity: 0
          })
      }

      // 请求图片按钮
      Button() {
        Row() {
          Text(this.showImage ? '重新加载' : '请求图片')
            .textAlign(TextAlign.Center)
            .fontSize(20)
            .margin({ top: '20.00vp', right: '20.00vp', bottom: '20.00vp', left: '20.00vp' })
            .width(150)
            .height(20)
            .fontWeight(500)
            .fontColor(Color.White);
        }
      }
      .backgroundColor('#ff525559')
      .margin({ bottom: 10 })
      .onClick(() => {
        console.log("请求图片按钮被点击");
        if (!this.loading) {
          this.loadNetworkImage();
        }
      })

      // 请求JSON按钮
      Button() {
        Row() {
          Text('请求JSON')
            .textAlign(TextAlign.Center)
            .fontSize(20)
            .margin({ top: '20.00vp', right: '20.00vp', bottom: '20.00vp', left: '20.00vp' })
            .width(150)
            .height(20)
            .fontWeight(500)
            .fontColor(Color.White);
        }
      }
      .backgroundColor('#ff525559')
      .margin({ bottom: 10 })
      .onClick(async () => {
        console.info(`Succeeded in Clicking`);
        try {
          let jsonData = await jsonHttpReq();
          await router.pushUrl({
            url: 'pages/JSONPage',
            params: { src:jsonData }
          })
            .then(() => {
              console.info(' Succeeded in jumping to the second page');
            })
            .catch((err: BusinessError) => {
              console.error(`Failed to jump to the JSON_Second. Code is ${err.code}, message is ${err.message}`);
            });
        } catch (error) {
          console.error(`Error occurred while fetching JSON data: ${error}`);
        }
      });

      // 请求Web页面按钮
      Button() {
        Row() {
          Text('请求Web')
            .textAlign(TextAlign.Center)
            .fontSize(20)
            .margin({ top: '20.00vp', right: '20.00vp', bottom: '20.00vp', left: '20.00vp' })
            .width(150)
            .height(20)
            .fontWeight(500)
            .fontColor(Color.White);
        }
      }
      .backgroundColor('#ff525559')
      .margin({ bottom: 10 })
      .onClick(() => { // 按钮点击事件
        router.pushUrl({
          url: 'pages/WebPage',
        })
      })
      Text(this.message)
        .fontSize(38)
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center)
    .backgroundColor(Color.White)
  }
}

```

### 4. Function Pages

Function Pages 是各具体功能实现的页面，盛放各自所需组件；

须从Home Page跳转；

本实验有2个Function Pages

- JSON Page
- Web Page

#### 4.1 JSON Page

##### 4.1.1 截图展示

![[JSON.png]]{width=200}

##### 4.1.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';

@Entry
@Component
struct SecondPage {
  @State receivedHtml: string = '';

  aboutToAppear() {
    //接收json
    let params = router.getParams() as Record<string, string>;
    if (params && params['src']) {
      this.receivedHtml = params['src'];
      console.info('Succeeded get src');
    }
  }


  build() {
    Column() {
      // Back button
      Button('Back')
        .type(ButtonType.Capsule)
        .margin(10)
        .onClick(() => {
          router.back();
        });

      // 滚动页面
      Scroll() {
        // 富文本输出html
        RichText(this.receivedHtml)
          .width('100%')
          .onStart(() => {
            console.log('RichText rendering started');
          })
          .onComplete(() => {
            console.log('RichText rendering completed');
          })
      }
      .width('100%')
      .height('100%')
    }
    .width('100%')
    .height('100%')
    .padding(10)
  }
}
```

#### 4.2 Web Page

##### 4.2.1 截图展示

![[web.png]]{width=200}

##### 4.2.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { BusinessError } from '@kit.BasicServicesKit'; // 导入基础服务模块的错误处理类
import web_webview from '@ohos.web.webview';
import { router } from '@kit.ArkUI'; // 导入ArkUI的路由模块
@Entry
@Component
struct WebPage {
  private webController: web_webview.WebviewController = new web_webview.WebviewController();
  build() {
   Column() {
      Web({src:$rawfile('Agricultural_Crop_Yields_WebApp.html'),controller:this.webController})
    }
    .height('100%')
    .width('100%')
  }
}
```