# 实验五报告

> 学号：3225706008
> 
> 姓名：范馨霏
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-04-02

## 一、实验目的

- 完成移动APP的原始框架，将作为后续系统的承载容器；
- 掌握教科书中网络编程相关部分练习；

## 二、实验内容

- 阅读教科书的第7章“网络编程”；
- 结合理论课要求完成本次APP框架设计；

## 三、实验要求

- Loading Page：完成起始页展示
  - 展示个性化设计
  - 可采用点击或定时方式完成跳转
- Login/Registration Page：实现登录/注册功能
  - 本次实验只要求完成页面设计
  - 具体功能在后续实验中完成
    - 主要涉及关系数据库操作
- Home Page：主界面，承担APP主要功能展示（以按钮形式）和跳转
  - 本次实验实现三个功能（按钮）
    - 请求图像
      - 要求使用Image组件的ArrayBuffer形式，<font color=red>不能直接使用URL返回</font>
      - Image组件可直接放在Home Page
    - 请求JSON
      - 采用RichText组件展示请求后的数据
      - RichText在新页面，需跳转
      - 理解异步/同步概念，实现页面跳转后的数据正确展示
    - 请求Web
      - 采用Web组件，直接请求本地HTML，展示2019年世界各国农作物产量预测系统
        - HTML文件在实验五Git课程仓库
      - Web组件在新页面，需跳转
      - 初步理解Web应用，为后续WebGIS二次开发打基础
- 撰写并提交实验报告；
  - <font color=red>实验步骤部分需严格按模板要求撰写</font>

## 四、实验步骤

### 1. Loading Page

#### 1.1 截图展示

30s后自动跳转，可以选择跳过，也可以选择先不跳
![alt text](loading.png){width=160px height=300px}   ![alt text](stop.png){width=160px height=300px}

#### 1.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
// src/main/ets/pages/Loading.ets
import { router } from '@kit.ArkUI';
import promptAction from '@ohos.promptAction';

@Entry
@Component
struct LoadingPage {
  @State message: string = '现在是北京时间:'
  @State remainingTime: number = 30  // 剩余时间
  private timerID: number = 0       // 定时器ID

  aboutToAppear() {
    // 启动倒计时
    this.timerID = setInterval(() => {
      if (this.remainingTime > 0) {
        this.remainingTime -= 1
      } else {
        this.clearTimer()
        router.pushUrl({ url: 'pages/Login1' })
      }
    }, 1000)
  }

  aboutToDisappear() {
    this.clearTimer()
  }

  // 清理定时器
  private clearTimer() {
    if (this.timerID) {
      clearInterval(this.timerID)
      this.timerID = 0
    }
  }

  build() {
    Stack() {
      // 背景图片容器
      Image($r('app.media.loadingback')) // 背景图
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover) // 保持图片比例填满容器
        .opacity(0.15) // 设置透明度 0-1 (0为全透明，1为不透明)
    Column() {

        Text(this.message)
          .fontSize(25)
          .fontColor('#86AEC8')

        Row() {
          // 显示时间组件
          TextClock()
            // 日期格式化
            .margin({ left: 20 })
            .fontSize(30)
            .format('yyyy/MM/dd  HH:mm:ss');
        }
        // 固定高度或改用百分比
        .height('6%')
        // 可选背景色
        .backgroundColor('#00000000')
        // 设置内容的对齐方式为居中对齐
        .justifyContent(FlexAlign.Center);

      Image($r('app.media.logo')) // 项目图片
        .width(255)
        .height(255)
        .margin({ bottom: 20 })

      Text('该睡觉了！').fontSize(35)
        //文本颜色
        .fontColor('#86AEC8')
          //文本位置
        .textAlign(TextAlign.Center)

      Row() {
        // 跳过按钮
        Button(`马上睡 (${this.remainingTime}s)`)
          .width(150)
          .height(45)
          .fontColor('#FFFFFF')
          .backgroundColor('#86AEC8')
          .onClick(() => {
            this.clearTimer()
            router.pushUrl({ url: 'pages/Login' })
          })

        // 间隔
        Blank()
          .width(20)

        // 停留按钮
        Button('先不睡')
          .width(150)
          .height(45)
          .fontColor('#666666')
          .backgroundColor('#EEEEEE')
          .onClick(() => {
            promptAction.showToast({ message: '先不睡了，再想睡觉请点击“马上睡”按钮', duration: 2000 })
            this.clearTimer()
          })
      }
      .margin({ top: 30 })

      // 加载进度条组件
      LoadingProgress()
        // 设置加载进度条的颜色
        .color('#86AEC8')
        .width(200)
        .height(200)
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center)
    .alignItems(HorizontalAlign.Center)
  }
    .width('100%')
    .height('100%')
  }
}

```


### 2. Login/Registration Page

#### 2.1 截图展示

点击登录按钮跳转，点击注册按钮显示弹窗，在实验六中完善功能，输入用户名，可以在主页中显示
![alt text](login.png){width=160px height=300px} ![alt text](注册.png){width=160px height=300px} ![alt text](懒羊羊.png){width=160px height=300px} ![alt text](懒羊羊登录.png){width=160px height=300px}

#### 2.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
// src/main/ets/pages/LoginPage.ets
import { router } from '@kit.ArkUI';
import {BusinessError} from '@kit.BasicServicesKit'
import promptAction from '@ohos.promptAction';

@Entry
@Component
struct LoginPage {
  @State username: string = ''
  @State password: string = ''

  build() {
    Stack() {
      // 背景图片容器
      Image($r('app.media.Loginback'))// 背景图
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover)// 保持图片比例填满容器
        .opacity(0.15) // 设置透明度 0-1 (0为全透明，1为不透明)

      Column() {

        Stack() {
          // 灰色圆环容器
          Column()
            .width(190)// 圆环总宽度 = 图片宽度 + 边框厚度*2
            .height(190)
            .borderRadius(95)// 圆角半径设为宽度的一半
            .backgroundColor('#e0e0e0') // 灰色背景

          // 原图片（缩小尺寸留出边框空间）
          Image($r('app.media.mainuser'))
            .width(180)
            .height(180)
            .margin(5)// 留出5px边框空间
            .borderRadius(100)// 保持圆形
            .clip(true)
        }
        .width(190) // 容器大小需包含边框
        .height(190)
        .margin({ bottom: 20 })

        TextInput({ placeholder: '请输入用户名' })
          .width('80%')
          .height(50)
          .margin({ bottom: 20 })
          .onChange((value: string) => {
            this.username = value
          })

        TextInput({ placeholder: '请输入密码' })
          .width('80%')
          .height(50)
          .type(InputType.Password)
          .margin({ bottom: 30 })
          .onChange((value: string) => {
            this.password = value
          })

        Row() {
          Button('登录')
            .width('40%')
            .height(50)
            .backgroundColor('#86AEC8')
            .onClick(() => {
              // 点击时输出日志信息
              console.info('Succeeded in clicking the "登录" button.')
              //跳转到Home页
              router.pushUrl({
                url: 'pages/Home',
                params: { usename: this.username }
              })// 跳转成功回调
                .then(() => {
                  // 点击时输出日志信息
                  console.info('Succeeded in jumping to the second page.')
                })// 跳转失败回调
                .catch((err: BusinessError) => {
                  // 输出错误日志（使用模板字符串拼接错误码和消息）
                  console.error('Failed to jump to the second page. Code is ${err.code}, message is ${err.message}')
                })
            })

          Blank().width('10%') // 间隔

          Button('注册')
            .width('40%')
            .height(50)
            .backgroundColor('#86AEC8')
            .onClick(() => {
              promptAction.showToast({ message: '还未开发，先点击登录按钮吧！', duration: 2000 })
            })
        }
        .margin({ bottom: 20 })
        .justifyContent(FlexAlign.SpaceBetween)
        .width('80%')

      }
      .width('100%')
      .height('100%')
      .padding(20)
      .justifyContent(FlexAlign.Center)
    }
    .width('100%')
    .height('100%')
  }
}
```

### 3. Home Page

#### 3.1 截图展示

只点击登录，默认游客模式，请求图像按钮可显示随机图片，点击请求JSON数据跳转json页面，点击访问Web系统跳转web页面，点击返回登录页可返回
![alt text](home.png){width=160px height=300px}  ![alt text](随机图片.png){width=160px height=300px}

#### 3.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
// src/main/ets/pages/Home.ets
import { router } from '@kit.ArkUI';
import image from '@ohos.multimedia.image';  // 引入图像处理模块
import http from '@ohos.net.http';          // 引入网络请求模块
import common from '@ohos.app.ability.common';
import promptAction from '@ohos.promptAction';
import { BusinessError } from '@kit.BasicServicesKit';

// 定义页面参数类型
interface PageParams {
  usename?: string;
}

@Entry
@Component
struct HomePage {
  @State message: string = '欢迎';
  // params属性声明
  private params: PageParams = {};
  @State pixelMap: PixelMap | null = null;  // 用于存储转换后的图片数据
  @State isLoading: boolean = false;        // 控制加载状态

  // 用于网络请求,获取上下文
  private context: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
  private textTimerController: TextTimerController = new TextTimerController()

  // aboutToAppear 方法：页面即将显示时触发
  aboutToAppear() {
    const params = router.getParams() as PageParams ?? {}; // 添加空值合并
    this.handleMessageParams(params);
  }

  // handleMessageParams 方法：处理页面参数
  handleMessageParams(params?: PageParams) {
    if (params?.usename) { // 使用可选链操作符
      this.message = `你好, ${params.usename}`;
    } else {
      this.message = '现在是游客模式';
    }
  }

  build() {
    Stack() {
      // 背景图片容器
      Image($r('app.media.homeback'))// 替换为你的背景图资源
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover)// 保持图片比例填满容器
        .opacity(0.15) // 设置透明度 0-1 (0为全透明，1为不透明)

    Column() {

      // 显示文本组件，绑定message状态变量
      Text(this.message)
        // 设置字体大小为50
        .fontSize(40)
          // 设置字体加粗
        .fontWeight(FontWeight.Bold)
        .fontColor('#86AEC8')

      Text('开始记录睡觉时长吧！')
        .fontSize(24)
        //文本颜色
        .fontColor('#0A7891')
          //文本位置
        .textAlign(TextAlign.Center)

      //定义TextTimer组件
      TextTimer({controller:this.textTimerController,
        //是否倒计时，默认值为false
        isCountDown:false})
        //格式化
        .format('mm:ss.SS')
          //字体颜色
        .fontColor('#225B65')
          //字体大小
        .fontSize(50)

      //控制按钮
      Row(){
        // 创建一个按钮，显示文本 "开始"，设置按钮的点击事件回调函数
        Button("开始").onClick(()=>{
          // 当按钮被点击时，开始计时器
          this.textTimerController.start()
        })
          .backgroundColor('#86AEC8')

        Blank().width(20)// 间隔

        // 创建一个按钮，显示文本 "暂停"，设置按钮的点击事件回调函数
        Button("暂停").onClick(()=>{
          // 当按钮被点击时，暂停计时器
          this.textTimerController.pause()
        })
          .backgroundColor('#86AEC8')

        Blank().width(20)// 间隔

        // 创建一个按钮，显示文本 "重置"，设置按钮的点击事件回调函数
        Button("重置").onClick(()=>{
          // 当按钮被点击时，重置计时器
          this.textTimerController.reset()
        })
          .backgroundColor('#86AEC8')
      }

      if (this.pixelMap) {
        Image(this.pixelMap)  // 使用 ArrayBuffer 转换后的 PixelMap
          .width(300)
          .height(300)
          .margin({ bottom: 20 })
      } else if (this.isLoading) {
        Progress({ value: 50, style: ProgressStyle.Ring }) // 加载中提示
          .width(50)
          .height(50)
          .margin({ bottom: 20 })
      } else {
        Text('睡不着？点点下面的按钮，玩一玩吧!')
          .fontColor('#225B65')
          .fontSize(16)
          .margin({ top:5,bottom: 5 })
      }

      Button('请求图像（随机图片）')
        .width('60%')
        .height(40)
        .margin({ bottom: 10 })
        .backgroundColor('#8DC6D0')
        .onClick(() => {
          this.requestImage()// 触发图片加载
        })

      Button('请求JSON数据')
        .width('60%')
        .height(40)
        .margin({ bottom: 10 })
        .backgroundColor('#7FCDBF')
        .onClick(() => {
          router.pushUrl({ url: 'pages/Json' })
        })

      Button('访问Web系统')
        .width('60%')
        .height(40)
        .margin({ bottom: 10 })
        .backgroundColor('#599EB5')
        .onClick(() => {
          router.pushUrl({ url: 'pages/Web' })
        })
      // 创建按钮
      Button() {
        // 按钮内文本内容
        Text('返回登录页')
          // 设置字体大小为20
          .fontSize(20)
            // 设置字体加粗
          .fontWeight(FontWeight.Bold)
          .fontColor('#FFFFFF')
      }
      // 设置按钮
      .type(ButtonType.Capsule)
      // 设置外边距（上20）
      .margin({
        top:5,bottom: 10
      })
      // 设置背景颜色为蓝色
      .backgroundColor('#86AEC8')
      // 设置按钮宽度为父容器的40%
      .width('40%')
      // 设置按钮高度为父容器的5%
      .height('5%')

      //返回按钮绑定onClick事件，点击按钮时返回到第一页
      .onClick(()=>{
        // 点击时输出日志信息
        console.info('Succeeded in clicking the "退出" button.')
        try{
          //返回第一页，完成页面跳转
          router.back()
          // 返回成功日志
          console.info('Succeeded in returning to the first page.')
        }
        catch(err) {
          // 错误处理（尝试将错误转换为BusinessError类型）
          let code = (err as BusinessError).code;
          let message = (err as BusinessError).message;
          // 输出错误日志（使用模板字符串拼接错误码和消息）
          console.error('Failed to return to the first page. Code is ${code}, message is ${message}')
        }
      })
    }
    .width('100%')
    .height('100%')
    .padding(20)
    .justifyContent(FlexAlign.Center)
  }
    .width('100%')
    .height('100%')
  }

  // 图像请求方法
  private async requestImage() {
    // 设置加载状态
    this.isLoading = true;

    try {
      // 创建 HTTP 请求
      const httpRequest = http.createHttp();
      const url = 'https://picsum.photos/300/300'; // 可提供随机图片服务的网站

      // 发送请求并获取 ArrayBuffer
      const response = await httpRequest.request(url, {
        method: http.RequestMethod.GET,
        expectDataType: http.HttpDataType.ARRAY_BUFFER // 关键：指定返回二进制数据
      });

      if (response.responseCode === 200) {
        const arrayBuffer = response.result as ArrayBuffer;

        // 将 ArrayBuffer 转换为 PixelMap
        const imageSource = image.createImageSource(arrayBuffer);
        this.pixelMap = await imageSource.createPixelMap();
      }
    } catch (error) {
      // 显示错误提示
      promptAction.showToast({
        message: '图片加载失败，请重试',
        duration: 2000
      });
    } finally {
      this.isLoading = false; // 关闭加载状态
    }
  }
}
```

### 4. Function Pages

Function Pages 是各具体功能实现的页面，盛放各自所需组件；

须从Home Page跳转；

本实验有2个Function Pages

- JSON Page
- Web Page

#### 4.1 JSON Page

##### 4.1.1 截图展示

![alt text](json.png){width=160px height=300px}  ![alt text](请求.png){width=160px height=300px}
![alt text](网页走丢.png){width=780px height=300px}
因加载原因，此处使用https://www.baidu.com/代替https://waylau.com/data/people.json

##### 4.1.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
// src/main/ets/pages/Json.ets
import { router } from '@kit.ArkUI';
import http from '@ohos.net.http';

@Entry
@Component

struct JsonPage {
  @State jsonData: string = '加载中...'
  @State message: string = '';
  @State isLoading: boolean = false;

  private httpReq() {
    this.isLoading = true;
    console.info('[JSAPP] 开始发起请求...');
    // 创建 httpRequest 对象
    let httpRequest = http.createHttp();
    let url = "https://www.baidu.com/";

    // 发起 HTTP 请求
    let promise = httpRequest.request(
      // 请求 url 地址
      url,
      {
        // 请求方式
        method: http.RequestMethod.GET,
        // 可选，默认为 60s
        connectTimeout: 60000,
        // 可选，默认为 60s
        readTimeout: 60000,
        // 开发者根据自身业务需要添加 header 字段
        header: {
          'Content-Type': 'application/json'
        }
      }
    );

    // 处理响应结果
    promise.then((data) => {
      console.info('[JSAPP] 请求成功，状态码:', data.responseCode);
      if (data.responseCode === http.ResponseCode.OK) {
        console.info('Result:' + data.result);
        console.info('code:' + data.responseCode);
        this.message = JSON.stringify(data.result);
      }else {
        console.error('[JSAPP] 请求失败，状态码:', data.responseCode);
        this.message = `请求失败，状态码：${data.responseCode}`;
      }
    }).catch((err: Error) => {
      if (err.message.includes('Network')) {
        this.message = '网络连接失败';
      } else {
        this.message = '服务器错误';
      }
      console.error(`error: ${JSON.stringify(err)}`);
    })
      .finally(() => {
        this.isLoading = false; // 请求结束
      });
  }

  private data: ResponseData| null = null;

  aboutToAppear() {
    this.fetchData()
  }

  fetchData() {
    // 模拟数据请求
    this.data = { code: 200, content: "Success" };
    this.message = this.data.content;
  }

  build() {
    Row() {
      Column() {
        if (this.isLoading) {
          Text('加载中...')
        }
        Text(this.message)
          .fontSize(38)
          .fontWeight(FontWeight.Bold)

        // 请求
        Button('请求', { type: ButtonType.Capsule })
          .width(140)
          .fontSize(40)
          .fontWeight(FontWeight.Medium)
          .margin({ top: 20, bottom: 20 })
          .onClick(() => {
            this.httpReq()
          })
          .backgroundColor('#86AEC8')
      }
    }
  }
}

interface ResponseData {
  code: number;
  content: string;
}

interface HttpRequestError extends Error {
  code: number;    // 错误码
  message: string; // 错误消息
}

```

#### 4.2 Web Page

##### 4.2.1 截图展示

![alt text](web.png){width=160px height=300px}

##### 4.2.2 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
// src/main/ets/pages/Web.ets
import web_webview from '@ohos.web.webview';
import http from '@ohos.net.http';

@Entry
@Component
struct WebPage {
  // Web 控制器
  private webController: web_webview.WebviewController = new web_webview.WebviewController();

  // 缩放比例、文本缩放比例、当前网页地址
  @State zoomFactor: number = 1.0;
  @State textZoomRatio: number = 100;
  @State currentUrl: Resource | string = $rawfile('Agricultural.html');

  // 加载在线网页
  private loadOnlinePage() {
    this.currentUrl = 'https://waylau.com/';
  }

  // JavaScript 交互方法
  test(): string {
    return 'Hello from ArkTS!';
  }

  build() {
    Column() {
      Flex({
        direction: FlexDirection.Row,
        wrap: FlexWrap.Wrap,
        justifyContent: FlexAlign.Start // 在此处设置对齐方式
      }) {
        Button('加载本地')
          .onClick(() => {
            console.log("Loading local...");
            this.currentUrl = $rawfile('Agricultural.html');
          })
          .margin(5)
          .backgroundColor('#86AEC8')

        Button('加载在线')
          .onClick(() => this.loadOnlinePage())
          .margin(5)
          .backgroundColor('#86AEC8')

        Button('放大 1.5x')
          .onClick(() => {
            this.zoomFactor *= 1.5;
            this.webController.zoom(this.zoomFactor);
          })
          .margin(5)
          .backgroundColor('#86AEC8')

        Button('缩小 0.8x')
          .onClick(() => {
            this.zoomFactor *= 0.8;
            this.webController.zoom(this.zoomFactor);
          })
          .margin(5)
          .backgroundColor('#86AEC8')

        Button('文本缩放 150%')
          .onClick(() => this.textZoomRatio = 150)
          .margin(5)
          .backgroundColor('#86AEC8')
      }
      .padding(10)
      .width('100%') // 保留宽度设置

      // Web 组件主体
      Web({
        src: this.currentUrl,
        controller: this.webController
      })
        .zoomAccess(true) // 启用手势缩放
        .textZoomRatio(this.textZoomRatio) // 文本缩放
        .onPageEnd(() => {
          console.log('网页加载完成');
        })
          // API 5 兼容方案：直接使用事件对象属性，不声明类型
        .onProgressChange((event) => {
          console.log(`加载进度: ${event['progress']}%`);
        })
        .javaScriptProxy({
          controller: this.webController,
          object: this,
          name: "arktsObj",
          methodList: ["test"]
        })

    }
    .width('100%')
    .height('100%')
  }
}
```
