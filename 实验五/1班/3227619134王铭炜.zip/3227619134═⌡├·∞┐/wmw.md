# index页面
import { BusinessError } from '@kit.BasicServicesKit';//导入页面路由模块
import { router } from '@kit.ArkUI';//导入页面路由模块

@Entry// 标识该组件为一个页面入口
@Component// 标识这是一个组件
struct Index {         // 定义名为 Index 的组件结构
  @State message: string = 'Index页面' ;
  // 定义一个状态变量 message，类型为字符串，初始值为 'Index页面'

  build() {  // 构建组件的视图方法
    Row(){  // 创建一个水平布局容器 Row
      Column(){   // 在 Row 容器中创建一个垂直布局容器 Column
        Text(this.message)// 创建一个文本组件，显示 this.message 的内容
          .fontSize(50)// 设置文本的字体大小为 50
          .fontWeight(FontWeight.Bold) //字体加粗
          .fontColor(0xff0000)//颜色红色
        //添加点击按钮
        Button() {
          Text('跳转')//按钮文本为跳转
            .fontSize(50)// 设置按钮中文本的字体大小为 50
            .fontWeight(FontWeight.Bold) //字体加粗
            .fontColor(0xffffff)//颜色白色
        }
        .type(ButtonType.Capsule)//胶囊形按钮
        .margin({
          top:20//与message文本间隔20
        })
        .backgroundColor(0x0000ff)//颜色蓝色
        .width('40%')// 设置按钮的宽度为父容器宽度的 40%
        .height('7%') // 设置按钮的高度为父容器高度的 7%
        .onClick(() => {  // 为按钮添加点击事件监听器
          console.info('Click Successes')//点击成功提示
          router.pushUrl({url:'pages/Second'}).then(()=>{//使用router.pushUrl方式进行跳转
            console.info('Loading Successes')//跳转成功提示

          }).catch((err: BusinessError)=>{
            console.error('Loading Failed.Code is ${err.code},message is ${err.message}')
          }) // 如果跳转失败，在控制台输出错误信息，包括错误码和错误消息
        })

      }
      .width('100%')//设置 Column 容器的宽度为父容器宽度的 100%
    }

    .height('100%')  // 设置 Row 容器的高度为父容器高度的 100%

  }
}


## second页面
import { BusinessError } from '@kit.BasicServicesKit';//导入页面路由模块
import { router } from '@kit.ArkUI';//导入页面路由模块

@Entry// 使用 @Entry 和 @Component 装饰器定义一个名为 Second 的组件，表示这是一个页面组件。
@Component
struct Second {
  @State message: string = 'Second页面';// 定义一个状态变量 message，初始值为字符串 'Second页面'，用于显示页面内容。
  // 定义组件的构建方法，用于构建页面的 UI 结构。
  build() {
    Row(){// 使用 Row 容器布局，表示页面内容水平排列。
      Column(){// 使用 Column 容器布局，表示页面内容垂直排列
        Text(this.message)      // 创建一个 Text 组件，用于显示文本内容
          .fontSize(50)// 设置文本字体大小为 50。
          .fontWeight(FontWeight.Bold) // 设置文本字体为加粗。
          .fontColor('0xff0000')//颜色红色
        Button(){// 创建一个 Button 组件，用于返回操作。
          Text('返回') // 在 Button 中嵌套一个 Text 组件，显示按钮文本。
            .fontSize(30)// 设置按钮文本字体大小为 30
            .fontWeight(FontWeight.Bold)// 设置按钮文本字体为加粗。
        }
        .type(ButtonType.Capsule)// 设置按钮的类型为胶囊形状。
        .margin({
          top:20// 设置按钮的外边距，顶部为 20。
        })
        .backgroundColor('rgba(255,105,10,0.85)')//85%不透明度的红色背景
        .width('40%')// 设置按钮的宽度为父容器的 40%
        .height('5%')// 设置按钮的高度为父容器的 5%
        //返回绑定的onclick事件
        .onClick(()=>{
          console.info('Clicking Successes')  // 在控制台输出点击成功的日志。
          try {
            //返回第一页
            router.back()
            // 在控制台输出返回成功的日志。
            console.info('Returning Successes')

          }catch (err){
            // 如果发生错误，捕获异常。
            // 将错误对象 err 转换为 BusinessError 类型，获取错误代码。
            let code=(err as BusinessError).code;
            let message=(err as BusinessError).message; // 获取错误消息。
            console.error('Failed to return to the first page.Code is &{code},message is &{message}' )
          }// 在控制台输出错误信息，包括错误代码和消息。
        })
      }
      .width('100%')//设置 Column 容器的宽度为 100%。
    }
    .height('100%')  // 设置 Row 容器的高度为 100%。
  }
}