# 实验五报告

> 学号：<3225706015>
> 
> 姓名：<郭佳欣>
> 
> 指导老师：<张凯斌>
> 
> 实验日期：<2025-04-07>

## 一、实验目的

- 完成移动APP的原始框架，将作为后续系统的承载容器；
- 掌握教科书中网络编程相关部分练习；

## 二、实验内容

- 阅读教科书的第7章“网络编程”；
- 结合理论课要求完成本次APP框架设计；

## 三、实验要求

- Loading Page：完成起始页展示
  - 展示个性化设计
  - 可采用点击或定时方式完成跳转
- Login/Registration Page：实现登录/注册功能
  - 本次实验只要求完成页面设计
  - 具体功能在后续实验中完成
    - 主要涉及关系数据库操作
- Home Page：主界面，承担APP主要功能展示（以按钮形式）和跳转
  - 本次实验实现三个功能（按钮）
    - 请求图像
      - 要求使用Image组件的ArrayBuffer形式，<font color=red>不能直接使用URL返回</font>
      - Image组件可直接放在Home Page
    - 请求JSON
      - 采用RichText组件展示请求后的数据
      - RichText在新页面，需跳转
      - 理解异步/同步概念，实现页面跳转后的数据正确展示
    - 请求Web
      - 采用Web组件，直接请求本地HTML，展示2019年世界各国农作物产量预测系统
        - HTML文件在实验五Git课程仓库
      - Web组件在新页面，需跳转
      - 初步理解Web应用，为后续WebGIS二次开发打基础
- 撰写并提交实验报告；
  - <font color=red>实验步骤部分需严格按模板要求撰写</font>

## 四、实验步骤

### 1. Loading Page

#### 1.1 截图展示
初始页面，可点击按钮进入登录页面
<img src=1.jpg>
登录页面，可以输入账号密码，点击下方文字可以进入注册页面，点击登录按钮可以进入主页面
<img src=2.jpg>
<img src=3.jpg>
#### 1.2 代码实现
初始页面
```typescript {.line-numbers}
import router from '@ohos.router'; // 导入路由模块，用于页面跳转

@Entry // 标记为入口组件
@Component // 标记为自定义组件
struct Index {
  build() {
    Column() { // 垂直布局容器
      Button($r('app.string.enter_button')) // 按钮组件，文本从资源文件中获取
        .width(200)
        .height(60)
        .fontSize(20)
        .onClick(() => { // 点击事件处理
          router.pushUrl({ // 路由跳转到登录页面
            url: 'pages/Login'
          });
        });
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center); // 设置布局属性：宽度100%，高度100%，内容居中
  }
}

```

Register.ets
```typescript {.line-numbers}
import router from '@ohos.router'; // 导入路由模块

@Entry
@Component
struct Register {
  @State username: string = ''; // 状态变量：用户名
  @State password: string = ''; // 状态变量：密码

  build() {
    Column() {
      // 用户名输入框
      TextInput({ placeholder: $r('app.string.username_hint') })
        .width('80%')
        .height(50)
        .margin({ bottom: 20 })
        .onChange((value: string) => { // 输入变化事件
          this.username = value; // 更新用户名状态
        });

      // 密码输入框
      TextInput({ placeholder: $r('app.string.password_hint') })
        .width('80%')
        .height(50)
        .type(InputType.Password) // 设置为密码类型
        .margin({ bottom: 30 })
        .onChange((value: string) => { // 输入变化事件
          this.password = value; // 更新密码状态
        });

      // 返回登录按钮
      Button($r('app.string.back_to_login'))
        .width('80%')
        .height(50)
        .onClick(() => {
          router.back(); // 返回上一页
        });
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center); // 布局设置
  }
}
```


### 2. Login/Registration Page

#### 2.1 截图展示

<img src=2.jpg>

#### 2.2 代码实现

```typescript {.line-numbers}
import router from '@ohos.router'; // 导入路由模块

@Entry
@Component
struct Login {
  @State username: string = ''; // 状态变量：用户名
  @State password: string = ''; // 状态变量：密码

  build() {
    Column() {
      // 用户名输入框
      TextInput({ placeholder: $r('app.string.username_hint') })
        .width('80%')
        .height(50)
        .margin({ bottom: 20 })
        .onChange((value: string) => {
          this.username = value;
        });

      // 密码输入框
      TextInput({ placeholder: $r('app.string.password_hint') })
        .width('80%')
        .height(50)
        .type(InputType.Password) // 设置为密码类型
        .margin({ bottom: 10 })
        .onChange((value: string) => {
          this.password = value;
        });

      // 注册提示文本
      Text($r('app.string.register_prompt'))
        .fontSize(14)
        .fontColor(Color.Blue)
        .margin({ bottom: 30 })
        .onClick(() => { // 点击跳转到注册页面
          router.pushUrl({
            url: 'pages/Register'
          });
        });

      // 登录按钮
      Button($r('app.string.login_button'))
        .width('80%')
        .height(50)
        .onClick(() => { // 点击跳转到主页面
          router.pushUrl({
            url: 'pages/Main'
          });
        });
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center); // 布局设置
  }
}
```

### 3. Home Page

#### 3.1 截图展示

<img src=4.jpg>
<img src=5.jpg>

#### 3.2 代码实现

```typescript {.line-numbers}
iimport router from '@ohos.router'; // 导入路由模块

@Entry
@Component
struct Main {
  @State imageSrc: ResourceStr = ''; // 状态变量：图片资源路径
  @State showImage: boolean = false; // 状态变量：是否显示图片

  build() {
    Column() {
      // 条件渲染图片组件
      if (this.showImage) {
        Image(this.imageSrc)
          .width(200)
          .height(200)
          .margin({ bottom: 20 });
      }

      // 请求图片按钮
      Button($r('app.string.request_image_button'))
        .width('80%')
        .height(50)
        .margin({ bottom: 20 })
        .onClick(() => { // 点击事件
          this.imageSrc = $r('app.media.123'); // 设置图片资源
          this.showImage = true; // 显示图片
        });

      // 请求JSON按钮
      Button($r('app.string.request_json_button'))
        .width('80%')
        .height(50)
        .margin({ bottom: 20 })
        .onClick(() => { // 点击跳转到JSON页面
          router.pushUrl({
            url: 'pages/JsonView'
          });
        });

      // 请求Web按钮
      Button($r('app.string.request_web_button'))
        .width('80%')
        .height(50)
        .onClick(() => { // 点击跳转到Web页面
          router.pushUrl({
            url: 'pages/WebView'
          });
        });
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center); // 布局设置
  }
}
```

### 4. Function Pages

Function Pages 是各具体功能实现的页面，盛放各自所需组件；

须从Home Page跳转；

本实验有2个Function Pages

- JSON Page
- Web Page

#### 4.1 JSON Page

##### 4.1.1 截图展示

<img src=6.jpg>

<img src=7.jpg>

##### 4.1.2 代码实现
JsonView.ets
```typescript {.line-numbers}
import router from '@ohos.router'; // 导入路由模块
import http from '@ohos.net.http'; // 导入HTTP模块

@Entry
@Component
struct JsonView {
  @State jsonData: string = 'Loading...'; // 状态变量：JSON数据

  // 生命周期方法：页面即将显示时调用
  aboutToAppear() {
    this.fetchJsonData(); // 获取JSON数据
  }

  // 异步获取JSON数据
  async fetchJsonData() {
    try {
      const httpRequest = http.createHttp(); // 创建HTTP请求
      const response = await httpRequest.request(
        '(https://raw.githubusercontent.com/kaibin-zhang/MobileAppDevelopment/main/example.json)',
        {
          method: http.RequestMethod.GET, // GET请求
        }
      );

      // 处理响应
      if (response.responseCode === http.ResponseCode.OK) {
        // 格式化JSON数据
        this.jsonData = JSON.stringify(JSON.parse(response.result.toString()), null, 2);
      } else {
        this.jsonData = `Request failed with code: ${response.responseCode}`;
      }
    } catch (err) {
      this.jsonData = `Error: ${err.message || JSON.stringify(err)}`;
    }
  }

  build() {
    Column() {
      // 页面标题
      Text($r('app.string.json_view_title'))
        .fontSize(20)
        .margin({ bottom: 20 });

      // 可滚动区域
      Scroll() {
        Text(this.jsonData) // 显示JSON数据
          .fontSize(14)
          .width('90%');
      }
      .width('100%')
      .height('70%');

      // 返回按钮
      Button($r('app.string.back_button'))
        .width('80%')
        .height(50)
        .margin({ top: 20 })
        .onClick(() => {
          router.back(); // 返回上一页
        });
    }
    .width('100%')
    .height('100%')
    .padding(20); // 布局设置
  }
}
```
WebView.ets
```typescript {.line-numbers}
@Entry
@Component
struct WebView {
  controller: WebController = new WebController(); // Web组件控制器

  build() {
    Column() {
      // Web组件
      Web({
        src: $rawfile('webpage.html'), // 加载本地HTML文件
        controller: this.controller // 设置控制器
      })
        .width('100%')
        .height('100%');
    }
  }
}
```