# 实验六报告

> 学号：<3225706108>
> 
> 姓名：<黄泽凯>
> 
> 指导老师：<张凯斌>
> 
> 实验日期：<2025-04-10>

## 一、实验目的

- 完成实验五中的L/R页面功能；
- 锻炼课堂所讲授的面向对象分析与设计能力；
- 实践编码能力

## 二、实验内容

- 依托教科书的第9章“数据管理”；
- 回顾实验三与实验四内容；
- 结合《课程指导》

完成本次实验。

## 三、实验要求

- Login/Registration System
  - 本次实验要求完成完整的登录/注册功能
- 基本需求
  - 三个UI Pages
    - L/R Page（实验五已进行）
      - 添加一个“角色”选项
        - 用户
        - 管理员
      - 输对用户名和密码后
        - 用户进入Home Page
        - 管理员进入Management Page
      - 如果登录信息不存在，提示进行“注册”
      - 连续3次输错密码后，关闭整个App
    - Registration Page
      - 引导用户输入注册信息
        - 用户名、性别、邮箱、密码、角色为必选项，其他自行设计
        - 需对用户输入内容进行形式判断，如数据类型等
          - 形式判断错误的，需要引导用户重新输入
      - 点击确认按钮后信息存入SQLite数据库
        - “用户”采用HarmonyOS的built-in加密存储功能
        - “管理员”采用自行加密模块处理后存储
    - Management Page
      - 此为管理员登录成功后可进入的页面
      - 具备“查询”按钮，点击返回整个注册数据库的信息
        - 跳转页面后用列表显示出来
          - 需解密后显示明文
  - 完成用例图和详细类图
    - 其他类型的图不要求
  - 完成编码实现
- 技术要求
  - 不能使用回调函数来完成异步编程，全部使用async/await形式
  - 必须有关键节点的日志输出



## 四、实验步骤

**写在前言**：我想做一个**服装相关的系统**，为了更好结合实验二三四五，我采用了对原先的实验进行了改善，并且用户的界面不是跳转之前做的homepage（因为跳转homepage不符合我的服装系统），而是跳转到展示服装信息的ClothInformation。同时一些按钮的设定也没有完全符合老师的要求（为了让这个服装系统更加贴近显示体验），但是也是达到老师这么要求的目的。

### 1. L/R Page

#### 1.1 截图展示

![[加载界面.png]]{width=200}
![[登录界面.png]]{width=200}
#### 1.2 用例图与类图

![[登录用例图.png]]
![[登录详细类图.png]]

#### 1.3 代码实现


插入代码的语法示例：
```typescript {.line-numbers}
// Login：
import { promptAction, router, AlertDialog } from '@kit.ArkUI'
import common from '@ohos.app.ability.common'; // Import context type
import UserUsers from '../../Common/database/UserUsers'
import { UserData } from '../../Common/database/table/UserInterface'
import { CryptoUtil } from '../../Common/database/CryptoUtil'
import { AdminCryptoUtil, RSAKey, uint8ArrayToString } from '../../Common/database/AdminCryptoUtil';
import { util } from '@kit.ArkTS'
import { cryptoFramework } from '@kit.CryptoArchitectureKit'
import prompt from '@ohos.promptAction'; // Correct import for promptAction

let storage = LocalStorage.getShared()

@Entry(storage)
@Component
struct Login {
  @State account: string = ''
  @State password: string = ''
  @State IS: number = 0 // Counter for failed login attempts?
  // Link to local storage, will be populated by aboutToAppear
  @LocalStorageLink('Users') users: UserData[] = []
  // Stores the currently logged-in user's data
  @LocalStorageLink('account') Account: UserData = { id: 0, name: '', sex: '', email: '', password: '', identity: '', secret_key: '' }

  // Initialize database access classes
  private userUsers = new UserUsers(getContext(this) as common.UIAbilityContext);
  // private accountUsers = new AccountUsers(getContext(this) as common.UIAbilityContext); // Initialize if needed

  // Load user data when the component appears
  async aboutToAppear(): Promise<void> {
    console.info("[Login] aboutToAppear: Loading users from database...");
    try {
      // Use await to get user data and store it
      const result: UserData[] = await this.userUsers.query();
      // Update the local storage and linked state variable
      storage.setOrCreate('Users', result);
      console.info(`[Login] Loaded ${result.length} users into storage.`);
    } catch (error) {
      console.error(`[Login] Failed to load users: ${JSON.stringify(error)}`);
      prompt.showToast({ message: 'Failed to load user data' });
      // Optionally set this.users to empty array or handle error state
      storage.setOrCreate('Users', []);
    }
  }

  // Dialog for failed login/registration prompt
  private showRegistrationPrompt() {
    AlertDialog.show({
      title: '账号或密码错误，是否进行注册？',
      message: '未找到匹配的用户信息或密码不正确。', // More informative message
      autoCancel: false,
      alignment: DialogAlignment.Center,
      offset: { dx: 0, dy: -20 },
      primaryButton: {
        value: '取消', // Changed from '否'
        action: () => {
          console.info('[Login] Registration prompt cancelled.');
          // Implement attempt limit logic if needed
          // if (this.IS >= 2) {
          //   getContext(this).getApplicationContext().terminateSelf(); // Use terminateSelf for UIAbility
          // }
          // this.IS++;
        }
      },
      secondaryButton: {
        value: '去注册', // Changed from '是'
        style: DialogButtonStyle.HIGHLIGHT,
        action: () => {
          console.info('[Login] Navigating to registration page.');
          router.pushUrl({ url: 'pages/CommonPages/register' });
        }
      }
    });
  }

  // Handle the login logic
  private async handleLogin() {
    console.info("[Login] Starting login validation for:", this.account);
    if (!this.account || !this.password) {
      prompt.showToast({ message: '请输入账号和密码' });
      return;
    }

    try {
      // Find user by account name from the loaded list
      const user = this.users.find(u => u.name === this.account);

      if (!user) {
        console.error("[Login] Account not found:", this.account);
        this.showRegistrationPrompt();
        return;
      }

      console.info("[Login] User found:", JSON.stringify(user)); // Avoid logging sensitive data in prod
      let decryptedPassword: string;

      // Decrypt password based on identity
      if (user.identity === '普通用户') {
        console.info("[Login] Decrypting AES password...");
        decryptedPassword = await CryptoUtil.decrypt(user.password);
        console.info("[Login] AES decryption complete.");
      } else { // Administrator
        console.info("[Login] Decrypting RSA password...");
        const adminCrypto = new AdminCryptoUtil();
        const rsaKey = new RSAKey(); // Assume RSAKey provides necessary key data
        const keyPair = await adminCrypto.genKeyPairByData(rsaKey.pkData, rsaKey.skData); // Ensure key data is correct
        const privateKey = keyPair.priKey;
        const base64Helper = new util.Base64Helper();
        const cipherData = base64Helper.decodeSync(user.password); // Decode base64 password
        const cipherText: cryptoFramework.DataBlob = { data: cipherData };
        const decryptData = await adminCrypto.decryptMessagePromise(privateKey, cipherText);
        decryptedPassword = uint8ArrayToString(decryptData.data); // Convert Uint8Array to string
        console.info("[Login] RSA decryption complete.");
      }

      // Compare decrypted password with input password
      // console.info("[Login] Decrypted Pwd (Debug):", decryptedPassword); // DO NOT LOG IN PRODUCTION
      if (decryptedPassword === this.password) {
        console.info("[Login] Password validation successful.");
        // Store logged-in user data
        this.Account = user; // Updates @LocalStorageLink('account')
        storage.setOrCreate('account', user); // Explicitly set in storage too

        // Navigate based on identity
        if (user.identity === '普通用户') {
          console.info("[Login] Navigating to User page.");
          router.pushUrl({ url: 'pages/UserPages/ClothInformation' }); // Adjust URL if needed
        } else {
          console.info("[Login] Navigating to Manager page.");
          router.pushUrl({ url: 'pages/ManagerPages/ManagerHomepage' }); // Adjust URL if needed
        }
      } else {
        console.error("[Login] Password mismatch.");
        this.showRegistrationPrompt();
      }
    } catch (error) {
      console.error(`[Login] Login validation process error: ${JSON.stringify(error)}`);
      prompt.showToast({ message: '登录验证失败，请重试' });
    }
  }

  // UI Build method remains largely the same
  build() {
    Column({ space: 20 }) {
      Text('欢迎登录')
        .fontSize(24)
        .fontWeight(600)
        .margin({ top: 50 })
      Stack() {
        Image($r('app.media.UNIQLO')) // Ensure image resource exists
          .width(100)
          .height(100)
          .borderRadius(50)
          .borderWidth(2)
          .borderColor('#ffeaedef')
      }
      .width(100)
      .height(100)
      .margin({ top: 20, bottom: 10 })

      TextInput({ placeholder: '输入账号', text: this.account })
        .width('80%')
        .height(50)
        .borderWidth(1)
        .borderColor('#ccc')
        .padding(10)
        .borderRadius(22)
        .onChange((value) => { this.account = value; })
        .margin({ top: 10 })

      TextInput({ placeholder: '输入密码', text: this.password })
        .type(InputType.Password)
        .width('80%')
        .borderRadius(22)
        .height(50)
        .borderWidth(1)
        .borderColor('#ccc')
        .padding(10)
        .onChange((value) => { this.password = value; })

      Button('登录')
        .width('80%')
        .height(50)
        .backgroundColor('#ff4e555a') // Use valid color format e.g., '#4E555A' or $r('app.color.login_button')
        .fontColor('#FFFFFF')
        .borderRadius(25) // Consistent rounding
        .onClick(() => {
          this.handleLogin(); // Call the async handler
        })
        .margin({ top: 20 }) // Added margin

      Row() {
        Text('没有账号？')
          .fontSize(14)
          .fontColor('#ff4e555a') // Use valid color format
        Text(' 去注册') // Added space for better separation
          .fontSize(14)
          .fontColor('#ff068fef') // Use valid color format e.g., '#068FEF' or $r('app.color.register_link')
          .fontWeight(FontWeight.Medium) // Make link slightly bolder
          .onClick(() => {
            router.pushUrl({ url: 'pages/CommonPages/register' });
          })
      }.margin({ top: 15 }) // Added margin
    }
    .height('100%')
    .width('100%')
    .padding({ left: 20, right: 20 }) // Added horizontal padding
    .alignItems(HorizontalAlign.Center)
    .backgroundColor('#F4F5F7')
  }
}
```


### 2. Registration Page

#### 2.1 截图展示

![[注册界面.png]]{width=200}

#### 2.2 用例图与类图

![[注册(用例图).png]]
![[注册(详细类图).png]]
#### 2.3 代码实现


插入代码的语法示例：
```typescript {.line-numbers}
// Register：
import { promptAction, router, AlertDialog } from '@kit.ArkUI';
import common from '@ohos.app.ability.common'; // Import context type
import UserUsers from '../../Common/database/UserUsers';
import { UserData } from '../../Common/database/table/UserInterface';
import { CryptoUtil } from '../../Common/database/CryptoUtil';
import { AdminCryptoUtil, RSAKey, stringToUint8Array } from '../../Common/database/AdminCryptoUtil';
import { util } from '@kit.ArkTS';
import { cryptoFramework } from '@kit.CryptoArchitectureKit';
import prompt from '@ohos.promptAction'; // Correct import

let storage = LocalStorage.getShared();

@Entry(storage)
@Component
struct Register {
  @State name: string = '';
  @State sex: string = '';
  @State email: string = '';
  @State password: string = '';
  @State NewPassword: string = ''; // Confirm password field
  @State identity: string = ''; // Role: '普通用户' or '管理员'
  @State secret_key: string = ''; // Admin secret key

  // Link to users in storage, updated by aboutToAppear
  @LocalStorageLink('Users') users: UserData[] = [];

  private userUsers = new UserUsers(getContext(this) as common.UIAbilityContext);

  // Load existing users when component appears to check for duplicates
  async aboutToAppear(): Promise<void> {
    console.info("[Register] aboutToAppear: Loading users from database...");
    try {
      const result: UserData[] = await this.userUsers.query();
      storage.setOrCreate('Users', result); // Update storage and linked variable
      console.info(`[Register] Loaded ${result.length} users into storage.`);
    } catch (error) {
      console.error(`[Register] Failed to load users: ${JSON.stringify(error)}`);
      prompt.showToast({ message: 'Failed to load existing user data' });
      storage.setOrCreate('Users', []); // Ensure users is an empty array on error
    }
  }

  // Validate input fields
  private validateInput(): boolean {
    if (!this.name) { prompt.showToast({ message: '用户名不能为空' }); return false; }
    if (!this.sex) { prompt.showToast({ message: '请选择性别' }); return false; }
    if (!this.email) { prompt.showToast({ message: '邮箱不能为空' }); return false; }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email)) { prompt.showToast({ message: '邮箱格式不正确' }); return false; }
    if (!this.password) { prompt.showToast({ message: '密码不能为空' }); return false; }
    if (this.password.length !== 6) { prompt.showToast({ message: '密码需为6位字符' }); return false; }
    if (this.password !== this.NewPassword) { prompt.showToast({ message: '两次输入密码不一致' }); return false; }
    if (!this.identity) { prompt.showToast({ message: '请选择角色' }); return false; }
    if (this.users.some(user => user.name === this.name)) { prompt.showToast({ message: '用户名已存在' }); return false; }
    if (this.identity === '管理员') {
      if (!this.secret_key) { prompt.showToast({ message: '管理员秘钥不能为空' }); return false; }
      // *** SECURITY WARNING: Hardcoded secret key check is insecure! ***
      // Replace '1' with a proper secure validation mechanism.
      if (this.secret_key !== '1') { prompt.showToast({ message: '管理员秘钥错误' }); return false; }
    }
    return true; // All checks passed
  }

  // Handle the registration submission
  private async handleSubmit() {
    console.info("[Register] Attempting registration submission...");
    if (!this.validateInput()) {
      console.warn("[Register] Validation failed.");
      return; // Stop if validation fails
    }

    console.info("[Register] Validation successful. Preparing user data...");
    // Generate a unique ID (using timestamp is simple but not robust for concurrency)
    const newUserId = Date.now();
    let encryptedPwd: string;

    try {
      // Encrypt password based on identity
      if (this.identity === '普通用户') {
        console.info("[Register] Encrypting password for 普通用户...");
        encryptedPwd = await CryptoUtil.encrypt(this.password);
      } else { // Administrator
        console.info("[Register] Encrypting password for 管理员...");
        const adminCrypto = new AdminCryptoUtil();
        const rsaKey = new RSAKey();
        const keyPair = await adminCrypto.genKeyPairByData(rsaKey.pkData, rsaKey.skData);
        const publicKey = keyPair.pubKey;
        const plainText: cryptoFramework.DataBlob = { data: stringToUint8Array(this.password) };
        const encryptData = await adminCrypto.encryptMessagePromise(publicKey, plainText);
        const base64Helper = new util.Base64Helper();
        encryptedPwd = base64Helper.encodeToStringSync(encryptData.data);
      }
      console.info("[Register] Password encryption complete.");

      let newUser: UserData = {
        id: newUserId, // Use generated ID
        name: this.name,
        sex: this.sex,
        email: this.email,
        password: encryptedPwd, // Use the encrypted password
        identity: this.identity,
        secret_key: this.identity === '管理员' ? this.secret_key : '' // Store secret key only for admin
      };
      console.info("[Register] Inserting new user into database:", JSON.stringify(newUser));
      // Insert data using await
      const insertResult = await this.userUsers.insertData(newUser);

      if (insertResult > 0) { // Check if insertion was successful (returned row ID > 0)
        console.info("[Register] User insertion successful, Row ID:", insertResult);

        // Refresh user list in storage after successful insertion
        const updatedUsers = await this.userUsers.query();
        storage.setOrCreate('Users', updatedUsers);
        console.info("[Register] User list in storage updated.");

        // Show success dialog and navigate to login
        AlertDialog.show({
          title: '注册成功',
          message: '欢迎您！现在可以去登录了。',
          autoCancel: false,
          alignment: DialogAlignment.Center,
          confirm: {
            value: '去登录',
            action: () => {
              console.info("[Register] Navigating to login page after successful registration.");
              router.pushUrl({ url: 'pages/CommonPages/login' });
            }
          }
        });
      } else {
        // This case might indicate an issue if insertData resolves but returns 0 or negative ID
        console.error("[Register] User insertion seemed to succeed but returned invalid ID:", insertResult);
        prompt.showToast({ message: `注册失败，请稍后重试` });
      }

    } catch (error) {
      console.error(`[Register] Registration process failed: ${JSON.stringify(error)}`);
      // Check for specific error types if needed (e.g., unique constraint violation)
      prompt.showToast({ message: `注册失败: ${error.message || '未知错误'}` });
    }
  }

  // UI Build method (remains the same logic, only references the component instance via 'this')
  build() {
    Column() {
      Text('用户注册') // UI Text remains appropriate
        .fontSize(24)
        .fontWeight(FontWeight.Bold)
        .margin({ top: 30, bottom: 20 }) // Adjusted margins

      Column({ space: 15 }) { // Slightly reduced space
        // Username Input
        TextInput({ placeholder: '请输入用户名', text: this.name })
          .height(45)
          .borderRadius(22) // Consistent rounding
          .backgroundColor('#F5F5F5')
          .padding({ left: 15, right: 15 }) // Consistent padding
          .onChange((value) => { this.name = value; })

        // Sex Selection
        Row({ space: 10 }) {
          Text('性别:')
            .fontSize(16)
            .width(60) // Fixed width for alignment
            .textAlign(TextAlign.End)
            .margin({ right: 5 })
          Button('男')
            .height(40).width('35%').borderRadius(20) // Adjusted width/rounding
            .fontColor(this.sex === '男' ? Color.White : '#333')
            .backgroundColor(this.sex === '男' ? '#007DFF' : '#F5F5F5')
            .onClick(() => { this.sex = '男'; })
          Button('女')
            .height(40).width('35%').borderRadius(20)
            .fontColor(this.sex === '女' ? Color.White : '#333')
            .backgroundColor(this.sex === '女' ? '#007DFF' : '#F5F5F5')
            .onClick(() => { this.sex = '女'; })
        }.width('100%').justifyContent(FlexAlign.Start)

        // Email Input
        TextInput({ placeholder: '请输入邮箱', text: this.email })
          .type(InputType.Email) // Use email input type
          .height(45).borderRadius(22).backgroundColor('#F5F5F5')
          .padding({ left: 15, right: 15 })
          .onChange((value) => { this.email = value; })

        // Password Input
        TextInput({ placeholder: '请输入6位密码', text: this.password })
          .type(InputType.Password).maxLength(6) // Enforce length
          .height(45).borderRadius(22).backgroundColor('#F5F5F5')
          .padding({ left: 15, right: 15 })
          .onChange((value) => { this.password = value; })

        // Confirm Password Input
        TextInput({ placeholder: '请确认密码', text: this.NewPassword })
          .type(InputType.Password).maxLength(6)
          .height(45).borderRadius(22).backgroundColor('#F5F5F5')
          .padding({ left: 15, right: 15 })
          .onChange((value) => { this.NewPassword = value; })

        // Role Selection
        Row({ space: 10 }) {
          Text('角色:')
            .fontSize(16).width(60).textAlign(TextAlign.End).margin({ right: 5 })
          Button('普通用户')
            .height(40).width('35%').borderRadius(20)
            .fontColor(this.identity === '普通用户' ? Color.White : '#333')
            .backgroundColor(this.identity === '普通用户' ? '#007DFF' : '#F5F5F5')
            .onClick(() => { this.identity = '普通用户'; this.secret_key = ''; })
          Button('管理员')
            .height(40).width('35%').borderRadius(20)
            .fontColor(this.identity === '管理员' ? Color.White : '#333')
            .backgroundColor(this.identity === '管理员' ? '#007DFF' : '#F5F5F5')
            .onClick(() => { this.identity = '管理员'; })
        }.width('100%').justifyContent(FlexAlign.Start)

        // Admin Secret Key Input (Conditional)
        if (this.identity === '管理员') {
          TextInput({ placeholder: '请输入管理秘钥', text: this.secret_key })
            .type(InputType.Password) // Use password type for secret key
            .height(45).borderRadius(22).backgroundColor('#F5F5F5')
            .padding({ left: 15, right: 15 })
            .onChange((value) => { this.secret_key = value; })
            .margin({ top: 5 }) // Add slight top margin
        }

        // Register Button
        Button('注册')
          .width('100%') // Make button full width of parent
          .height(50).borderRadius(25)
          .fontSize(18).fontWeight(FontWeight.Medium)
          .backgroundColor('#4CAF50') // Changed color for register
          .fontColor(Color.White)
          .margin({ top: 20 }) // Adjusted margin
          .onClick(() => {
            this.handleSubmit(); // Call async handler
          })

        // Link to Login
        Row() {
          Text('已有账号？')
            .fontSize(14).fontColor('#666')
          Text(' 去登录')
            .fontSize(14).fontColor('#007DFF').fontWeight(FontWeight.Medium)
            .onClick(() => { router.pushUrl({ url: 'pages/CommonPages/login' }); })
        }
        .justifyContent(FlexAlign.Center)
        .margin({ top: 15, bottom: 20 }) // Adjusted margins

      }
      .width('90%') // Constrain width of the form area
      .padding(20) // Add padding inside the form area
      .backgroundColor(Color.White)
      .borderRadius(16)
      .shadow({ radius: 5, color: '#20000000' }) // Softer shadow

    }
    .width('100%').height('100%')
    .backgroundColor('#F0F0F0') // Changed background slightly
    .justifyContent(FlexAlign.Center) // Center the form vertically
    .padding({ bottom: 30 }) // Ensure space at the bottom
  }
}
```

### 3. Management Page

#### 3.1 截图展示（末尾补充了用户界面的展示）
![[管理者功能界面.png]]{width=200}
![[服装信息管理界面.png]]{width=200}
![[用户信息查询界面.png]]{width=200}
![[用户界面.png]]{width=200}


#### 3.2 用例图与类图

![[管理者用例图.png]]
![[管理者详细类图.png]]

#### 3.3 代码实现

插入代码的语法示例：
```typescript {.line-numbers}
//ManagerHomepage.ets

import { router } from '@kit.ArkUI';

let storage = LocalStorage.getShared();

@Entry(storage)
@Component
struct HomePage {
  // 日志方法，包含组件、级别和时间戳
  private log(level: 'info' | 'warn' | 'error', message: string) {
    const prefix = `[HomePage][${level.toUpperCase()}][${new Date().toISOString()}] `;
    console[level](`${prefix}${message}`);
  }

  aboutToAppear(): void {
    this.log('info', 'HomePage 组件即将出现');
  }

  build() {
    Column() {
      Column() {
        Row() {
          Blank()
            .layoutWeight(1);

          Text('退出登录')
            .border({ width: 1 })
            .padding(8)
            .onClick(() => {
              this.log('info', '退出登录按钮点击');
              router.pushUrl({ url: 'pages/CommonPages/login' });
            });
        }

        Column({ space: 55 }) {
          Button('用户信息查询')
            .type(ButtonType.Capsule)
            .width(200)
            .height(60)
            .fontColor('#FFFFFF')
            .fontSize(20)
            .backgroundColor('#ff4e555a')
            .border({ width: 1 })
            .onClick(() => {
              this.log('info', '用户信息查询按钮点击');
              router.pushUrl({ url: 'pages/ManagerPages/UserInformation' });
            });

          Button('服装信息管理')
            .type(ButtonType.Capsule)
            .width(200)
            .height(60)
            .fontSize(20)
            .fontColor('#FFFFFF')
            .backgroundColor('#ff4e555a')
            .border({ width: 1 })
            .onClick(() => {
              this.log('info', '服装信息管理按钮点击');
              router.pushUrl({ url: 'pages/ManagerPages/ManagerCloth' });
            });
        }
        .margin({ top: 150 });
      }
      .height('100%')
      .width('90%');
    }
    .height('100%')
    .width('100%');
  }
}

```
```typescript {.line-numbers}
//ManagerCloth.ets

import { AccountData } from '../../Common/database/table/AccountInterface';
import AccountUsers from '../../Common/database/AccountUsers';
import common from '@ohos.app.ability.common'; // Import context type
import promptAction from '@ohos.promptAction';
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit'; // For specific error type handling

let storage = LocalStorage.getShared(); // Assuming shared storage is needed

@Entry(storage) // Make sure storage is properly initialized if linked vars are used
@Component
struct Index {
  // @State message: string = '查询结果'; // Seems unused, can be removed
  // State for Add form - use strings for input fields
  @State addArtNoStr: string = '';
  @State addName: string = '';
  @State addPriceStr: string = '';
  @State addAmountStr: string = '';

  // State for Update form
  @State updateArtNoStr: string = '';
  @State updateName: string = '';
  @State updatePriceStr: string = '';
  @State updateAmountStr: string = '';

  // State for Delete form
  @State deleteArtNoStr: string = '';

  // @State isFilterStock: boolean = false; // Filter state, not used in provided build
  scroller: Scroller = new Scroller()
  @State dataList: AccountData[] = []; // Holds the displayed data
  @State isLoading: boolean = false; // Optional: for loading indicators

  // Database handler instance - Assuming AccountUsers constructor is refactored
  private accountUsers = new AccountUsers(getContext(this) as common.UIAbilityContext);

  // @LocalStorageLink('AccountDataCommodity') AccountDataCommodity: AccountData[] = []; // Example if needed

  // Load initial data when the component appears
  async aboutToAppear(): Promise<void> {
    console.info("[Index] Component appearing. Loading initial data...");
    await this.refreshDataList();
  }

  // --- Reusable Data Refresh Function ---
  async refreshDataList(): Promise<void> {
    console.info("[Index] Refreshing data list...");
    this.isLoading = true; // Optional: Show loading state
    try {
      const result = await this.accountUsers.query(); // Await the query
      this.dataList = result; // Update the state variable directly
      console.info(`[Index] Data list refreshed. ${result.length} items loaded.`);
    } catch (error) {
      console.error(`[Index] Failed to query data: ${JSON.stringify(error)}`);
      promptAction.showToast({ message: '查询数据失败' });
      this.dataList = []; // Clear list on error
    } finally {
      this.isLoading = false; // Optional: Hide loading state
    }
  }

  // --- Input Validation Helper ---
  // (Could be expanded with more specific checks)
  private validateAccountData(artNo: number, name: string, price: number, amount: number): { isValid: boolean; message?: string } {
    if (isNaN(artNo) || artNo <= 0) return { isValid: false, message: '请输入有效的货号 (正数)' };
    if (!name?.trim()) return { isValid: false, message: '请输入商品名称' };
    if (isNaN(price) || price < 0) return { isValid: false, message: '请输入有效的价格 (非负数)' };
    if (isNaN(amount) || amount < 0 || !Number.isInteger(amount)) return { isValid: false, message: '请输入有效的数量 (非负整数)' };
    return { isValid: true };
  }


  // --- Action Handlers (Async) ---

  async handleAdd(): Promise<void> {
    console.info("[Index] Add button clicked.");
    const artNo = parseInt(this.addArtNoStr);
    const name = this.addName;
    const price = parseFloat(this.addPriceStr);
    const amount = parseInt(this.addAmountStr);

    const validation = this.validateAccountData(artNo, name, price, amount);
    if (!validation.isValid) {
      promptAction.showToast({ message: validation.message });
      return;
    }

    const newAccount: AccountData = { ArtNo: artNo, Name: name, Price: price, Amount: amount };
    this.isLoading = true; // Optional

    try {
      const exists = await this.accountUsers.checkArtNoExists(newAccount.ArtNo);
      if (exists) {
        promptAction.showDialog({ message: '该商品货号已存在' });
        console.warn(`[Index] Add failed: ArtNo ${newAccount.ArtNo} already exists.`);
      } else {
        console.info("[Index] Adding new item:", JSON.stringify(newAccount));
        await this.accountUsers.insertData(newAccount);
        promptAction.showToast({ message: '添加成功' });
        console.info("[Index] Item added successfully.");
        await this.refreshDataList(); // Refresh list after adding
        // Clear add form fields
        this.addArtNoStr = ''; this.addName = ''; this.addPriceStr = ''; this.addAmountStr = '';
      }
    } catch (error) {
      console.error(`[Index] Add failed: ${JSON.stringify(error)}`);
      promptAction.showToast({ message: `添加失败: ${error.message || '未知错误'}` });
      await this.refreshDataList(); // Refresh list even on error to ensure consistency
    } finally {
      this.isLoading = false; // Optional
    }
  }

  async handleUpdate(): Promise<void> {
    console.info("[Index] Update button clicked.");
    const artNo = parseInt(this.updateArtNoStr);
    const name = this.updateName; // Allow empty name for update? Decide based on requirement
    const price = parseFloat(this.updatePriceStr);
    const amount = parseInt(this.updateAmountStr);

    // Validate ArtNo separately for update
    if (isNaN(artNo) || artNo <= 0) {
      promptAction.showToast({ message: '请输入要更新的有效货号' });
      return;
    }
    // Validate other fields only if they are provided (or require them)
    if (this.updateName && !name?.trim()) { promptAction.showToast({ message: '名称不能为空' }); return; } // Example: If name is provided, it cannot be empty
    if (this.updatePriceStr && (isNaN(price) || price < 0)) { promptAction.showToast({ message: '请输入有效的价格' }); return; }
    if (this.updateAmountStr && (isNaN(amount) || amount < 0 || !Number.isInteger(amount))) { promptAction.showToast({ message: '请输入有效的数量' }); return; }

    // Construct the update object - decide how to handle partial updates
    // Simplest: assume all fields are meant to be updated if provided
    const updatedAccount: AccountData = {
      ArtNo: artNo,
      // Only include fields if they have values, or fetch existing first for true partial update
      Name: name, // Send current value (could be empty if user cleared it)
      Price: isNaN(price) ? 0 : price, // Default to 0 or fetch existing if invalid/empty
      Amount: isNaN(amount) ? 0 : amount // Default to 0 or fetch existing if invalid/empty
    };

    this.isLoading = true; // Optional

    try {
      const exists = await this.accountUsers.checkArtNoExists(updatedAccount.ArtNo);
      if (!exists) {
        promptAction.showDialog({ message: '要更新的商品不存在' });
        console.warn(`[Index] Update failed: ArtNo ${updatedAccount.ArtNo} does not exist.`);
      } else {
        console.info("[Index] Updating item:", JSON.stringify(updatedAccount));
        const affectedRows = await this.accountUsers.updateData(updatedAccount); // updateData returns affected row count
        if (affectedRows > 0) {
          promptAction.showToast({ message: '更新成功' });
          console.info(`[Index] Item updated successfully. ${affectedRows} rows affected.`);
          await this.refreshDataList();
          // Clear update form fields
          this.updateArtNoStr = ''; this.updateName = ''; this.updatePriceStr = ''; this.updateAmountStr = '';
        } else {
          promptAction.showToast({ message: '更新未影响任何记录 (数据可能未更改)' });
          console.warn("[Index] Update completed but no rows were affected.");
          await this.refreshDataList(); // Still refresh to be safe
        }
      }
    } catch (error) {
      console.error(`[Index] Update failed: ${JSON.stringify(error)}`);
      promptAction.showToast({ message: `更新失败: ${error.message || '未知错误'}` });
      await this.refreshDataList(); // Refresh list even on error
    } finally {
      this.isLoading = false; // Optional
    }
  }

  async handleDelete(): Promise<void> {
    console.info("[Index] Delete button clicked.");
    const artNo = parseInt(this.deleteArtNoStr);

    if (isNaN(artNo) || artNo <= 0) {
      promptAction.showToast({ message: '请输入有效的货号进行删除' });
      return;
    }

    this.isLoading = true; // Optional

    try {
      const exists = await this.accountUsers.checkArtNoExists(artNo);
      if (!exists) {
        promptAction.showDialog({ message: '要删除的商品不存在' });
        console.warn(`[Index] Delete failed: ArtNo ${artNo} does not exist.`);
      } else {
        // Confirmation Dialog
        const confirmRes = await promptAction.showDialog({
          title: '确认删除',
          message: `确定要删除货号为 ${artNo} 的商品吗？此操作无法撤销。`,
          buttons: [
            { text: '取消', color: '#666666' },
            { text: '确定删除', color: '#FF0000' } // Red for destructive action
          ]
        });

        if (confirmRes.index === 1) { // Index 1 is '确定删除'
          console.info("[Index] Deleting item with ArtNo:", artNo);
          // Pass only needed data for deletion predicate
          const accountToDelete: AccountData = { ArtNo: artNo, Name: '', Price: 0, Amount: 0 };
          const affectedRows = await this.accountUsers.deleteData(accountToDelete); // deleteData returns affected rows
          if (affectedRows > 0) {
            promptAction.showToast({ message: '删除成功' });
            console.info(`[Index] Item deleted successfully. ${affectedRows} rows affected.`);
            await this.refreshDataList();
            this.deleteArtNoStr = ''; // Clear delete form field
          } else {
            // This case is less likely if checkArtNoExists passed, but possible race condition or other issue
            promptAction.showToast({ message: '删除失败 (商品可能已被删除)' });
            console.warn("[Index] Delete completed but no rows were affected.");
            await this.refreshDataList(); // Refresh anyway
          }
        } else {
          console.info("[Index] Deletion cancelled by user.");
        }
      }
    } catch (error) {
      // Handle errors from checkArtNoExists, showDialog, or deleteData
      if (error instanceof BusinessError) { // Catch specific dialog errors if needed
        console.warn(`[Index] Dialog error/dismissed: ${error.code} - ${error.message}`)
      } else {
        console.error(`[Index] Delete operation failed: ${JSON.stringify(error)}`);
        promptAction.showToast({ message: `删除失败: ${error.message || '未知错误'}` });
        await this.refreshDataList(); // Refresh list even on error
      }
    } finally {
      this.isLoading = false; // Optional
    }
  }


  // --- UI Build Method (Mostly unchanged, just onClick handlers updated) ---
  build() {
    Scroll(this.scroller) { // Use the scroller instance
      Column({ space: 20 }) { // Add space between main sections
        // --- Header ---
        Row({ space: 16 }) {
          Text("服装信息管理系统")
            .fontSize(28) // Slightly smaller
            .fontWeight(FontWeight.Bold)
            .layoutWeight(1) // Allow text to take available space
            .textAlign(TextAlign.Start) // Align left

          Button('返回')
            .type(ButtonType.Normal)
            .width(80).height(40)
            .fontColor('#333') // Better contrast
            .backgroundColor('#E0E0E0')
            .borderRadius(8)
            .onClick(() => {
              console.info("[Index] Navigating back to ManagerHomepage.");
              router.pushUrl({ url: 'pages/ManagerPages/ManagerHomepage' });
            })
        }
        .width('100%') // Ensure row takes full width
        .margin({ bottom: 10 }) // Add margin below header

        // --- Add Section ---
        Column({ space: 10 }) {
          Text("添加新商品").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start)
          Row({ space: 10 }) {
            TextInput({ placeholder: '货号', text: this.addArtNoStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addArtNoStr = value)
            TextInput({ placeholder: '名称', text: this.addName })
              .width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addName = value)
          }.width('100%')
          Row({ space: 10 }) {
            TextInput({ placeholder: '价格', text: this.addPriceStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addPriceStr = value)
            TextInput({ placeholder: '数量', text: this.addAmountStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addAmountStr = value)
          }.width('100%')
          Button('添加商品')
            .width('100%').height(45).margin({ top: 5 })
            .backgroundColor('#4CAF50').fontColor(Color.White).borderRadius(8)
            .onClick(async () => { await this.handleAdd(); }) // Call async handler
        }
        .padding(15).borderRadius(12).backgroundColor("#f0f0f0").width('100%')

        // --- Update Section ---
        Column({ space: 10 }) {
          Text("更新商品信息").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start)
          Row({ space: 10 }) {
            TextInput({ placeholder: '货号 (必填)', text: this.updateArtNoStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updateArtNoStr = value)
            TextInput({ placeholder: '新名称', text: this.updateName })
              .width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updateName = value)
          }.width('100%')
          Row({ space: 10 }) {
            TextInput({ placeholder: '新价格', text: this.updatePriceStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updatePriceStr = value)
            TextInput({ placeholder: '新数量', text: this.updateAmountStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updateAmountStr = value)
          }.width('100%')
          Button('更新商品')
            .width('100%').height(45).margin({ top: 5 })
            .backgroundColor('#FFA726').fontColor(Color.White).borderRadius(8) // Orange for update
            .onClick(async () => { await this.handleUpdate(); }) // Call async handler
        }
        .padding(15).borderRadius(12).backgroundColor("#f0f0f0").width('100%')

        // --- Delete Section ---
        Column({ space: 10 }) {
          Text("删除商品").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start)
          TextInput({ placeholder: '输入要删除的货号', text: this.deleteArtNoStr })
            .type(InputType.Number).width('100%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
            .onChange((value) => this.deleteArtNoStr = value)
          Button('删除商品')
            .width('100%').height(45).margin({ top: 5 })
            .backgroundColor('#F44336').fontColor(Color.White).borderRadius(8) // Red for delete
            .onClick(async () => { await this.handleDelete(); }) // Call async handler
        }
        .padding(15).borderRadius(12).backgroundColor("#f0f0f0").width('100%')

        // --- Data Display Section ---
        Column() {
          Text("商品列表").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start).margin({ bottom: 10 })
          // Table Header
          Row() {
            Text('货号').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
            Text('名称').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
            Text('价格').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
            Text('数量').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
          }
          .width('100%').borderRadius(6).border({ width: 1, color: '#ccc' })

          // Data Rows / Loading / Empty State
          Stack({ alignContent: Alignment.TopStart }) { // Use Stack for potential overlay
            if (this.isLoading) {
              Progress({ type: ProgressType.Linear }).width('100%').margin({ top: 5 })
            } else if (this.dataList.length > 0) {
              ForEach(this.dataList, (item: AccountData) => {
                Row() {
                  Text(item.ArtNo.toString()).width('25%').textAlign(TextAlign.Center).padding(8)
                  Text(item.Name).width('25%').textAlign(TextAlign.Center).padding(8).textOverflow({overflow: TextOverflow.Ellipsis}).maxLines(1) // Prevent long names breaking layout
                  Text(item.Price.toFixed(2)).width('25%').textAlign(TextAlign.Center).padding(8) // Format price
                  Text(item.Amount.toString()).width('25%').textAlign(TextAlign.Center).padding(8)
                }
                .width('100%')
                .border({ width: { bottom: 1 }, color: '#e0e0e0' }) // Border between rows
              }, (item: AccountData) => item.ArtNo.toString()) // Key generator
            } else {
              Text("没有商品信息可显示")
                .width('100%')
                .padding(20)
                .textAlign(TextAlign.Center)
                .fontColor('#888')
            }
          } // End Stack

          // Refresh Button (Moved below list)
          Button('刷新列表')
            .width('100%').height(45).margin({ top: 15 })
            .backgroundColor('#2196F3').fontColor(Color.White).borderRadius(8) // Blue for refresh
            .onClick(async () => { await this.refreshDataList(); }) // Call async refresh

        }
        .width('100%').margin({ top: 20 }) // Add margin above the list section

      } // End main Column
      .width('95%') // Constrain content width slightly
      .padding({ top: 20, bottom: 30 }) // Add padding top/bottom
      .alignItems(HorizontalAlign.Center) // Center content horizontally

    } // End Scroll
    .width('100%').height('100%')
    .scrollable(ScrollDirection.Vertical)
    .scrollBar(BarState.Auto) // Show scrollbar only when needed
    .backgroundColor('#FAFAFA') // Slightly off-white background
  }
}
```
```typescript {.line-numbers}
//UserInformation.ets
import { UserData } from '../../Common/database/table/UserInterface';
import { router } from '@kit.ArkUI';
import { CryptoUtil } from '../../Common/database/CryptoUtil';
import { AdminCryptoUtil, RSAKey, uint8ArrayToString } from '../../Common/database/AdminCryptoUtil';
import { util } from '@kit.ArkTS';
import { cryptoFramework } from '@kit.CryptoArchitectureKit';

let storage = LocalStorage.getShared();

@Entry(storage)
@Component
struct UserInformation {
  @LocalStorageLink('Users') users: UserData[] = [];
  @State decryptedList: UserData[] = [];

  // 日志方法，带组件名、日志级别和时间戳
  private log(level: 'info' | 'warn' | 'error', message: string) {
    const prefix = `[UserInfo][${level.toUpperCase()}][${new Date().toISOString()}] `;
    console[level](`${prefix}${message}`);
  }

  aboutToAppear(): void {
    this.log('info', '组件即将出现，加载本地用户数据');
    // 从本地取出原始列表
    this.users = storage.get('Users') || [];
    this.log('info', `共载入 ${this.users.length} 条用户记录`);
    this.decryptAll();
  }

  private async decryptAll(): Promise<void> {
    this.log('info', '开始解密所有用户密码');
    const list: UserData[] = [];
    for (const item of this.users) {
      this.log('info', `解密用户 ${item.name} (ID:${item.id}) 密码开始`);
      let plainPwd: string;
      if (item.identity === '普通用户') {
        // 普通用户使用AES解密
        plainPwd = await CryptoUtil.decrypt(item.password);
      } else {
        // 管理员使用RSA解密
        const adminCrypto = new AdminCryptoUtil();
        const rsaKey = new RSAKey();
        const keyPair = await adminCrypto.genKeyPairByData(rsaKey.pkData, rsaKey.skData);
        const privateKey = keyPair.priKey;
        const base64Helper = new util.Base64Helper();
        const cipherData = base64Helper.decodeSync(item.password);
        const cipherText: cryptoFramework.DataBlob = { data: cipherData };
        const decryptData = await adminCrypto.decryptMessagePromise(privateKey, cipherText);
        plainPwd = uint8ArrayToString(decryptData.data);
      }
      this.log('info', `解密用户 ${item.name} (ID:${item.id}) 密码完成`);

      // 手动构建一个新对象，避免使用对象 spread
      const newUser: UserData = {
        id: item.id,
        name: item.name,
        sex: item.sex,
        email: item.email,
        password: plainPwd,
        identity: item.identity,
        secret_key: item.secret_key
      };
      list.push(newUser);
    }
    this.decryptedList = list;
    this.log('info', `所有用户解密完成，共 ${list.length} 条记录`);
  }

  build() {
    Column() {
      // 头部导航栏
      Row() {
        Text('用户信息')
          .fontSize(30)
          .fontWeight(FontWeight.Bold)
          .fontColor('#1a1a1a')
          .layoutWeight(1);

        Button('返回')
          .type(ButtonType.Normal)
          .width(80)
          .height(40)
          .fontColor('#ff151414')
          .backgroundColor('#ffffff')
          .borderRadius(8)
          .onClick(() => {
            this.log('info', '点击返回，跳转到管理首页');
            router.pushUrl({ url: 'pages/ManagerPages/ManagerHomepage' });
          });
      }
      .width('90%')
      .padding({ top: 15, bottom: 15 })
      .backgroundColor('#f5f5f5')
      .borderRadius(12);

      // 用户列表
      List({ space: 15 }) {
        ForEach(this.decryptedList, (item: UserData) => {
          ListItem() {
            Column() {
              // 用户基本信息行
              Row() {
                Text(item.name)
                  .fontSize(24)
                  .fontWeight(FontWeight.Bold)
                  .fontColor('#333333');

                // 角色徽章
                Text(item.identity)
                  .fontSize(18)
                  .fontColor('#ffffff')
                  .backgroundColor(item.identity === '管理员' ? '#ff8000' : '#4CAF50')
                  .padding({ left: 10, right: 10, top: 4, bottom: 4 })
                  .borderRadius(15)
                  .margin({ left: 10 });
              }
              .width('100%')
              .padding({ bottom: 12 });

              Row() {
                Image(item.sex === '女' ? $r('app.media.woman') : $r('app.media.man'))
                  .width('20%')
                  .borderRadius(24)
                  .margin({ right: 10 });
                Column({ space: 8 }) {
                  this.InfoItem('性别', item.sex);
                  this.InfoItem('邮箱', item.email);
                  this.InfoItem('密码', item.password);
                }
                .width('80%')
                .padding(20)
                .backgroundColor('#f9f9f9')
                .borderRadius(8);
              }
            }
            .padding(16)
            .backgroundColor('#ffffff')
            .borderRadius(12)
            .shadow({ radius: 8, color: '#1a000000', offsetX: 2, offsetY: 2 });
          }
          .margin({ bottom: 15 });
        })
      }
      .width('100%')
      .padding(15)
      .layoutWeight(1)
      .backgroundColor('#f0f0f0');
    }
    .width('100%')
    .height('100%')
    .backgroundColor('#f5f5f5');
  }

  // 自定义信息项组件
  @Builder
  InfoItem(label: string, value: string) {
    Row() {
      Text(label + '：')
        .fontSize(15)
        .fontColor('#666666')
        .width(45);

      Text(value)
        .fontSize(15)
        .fontColor('#333333')
        .layoutWeight(1)
        .textAlign(TextAlign.End);
    }
    .border({ width: 0.5, color: '#eeeeee' });
  }
}

```
#### 4. 与以上页面有所关联的代码

```typescript {.line-numbers}
//CommonConstants.ets
import { relationalStore } from '@kit.ArkData'
import { AccountTable } from '../database/table/AccountInterface'
import { UserTable } from '../database/table/UserInterface'

export default class CommonConstants {
  static readonly STONE_CONFIG: relationalStore.StoreConfig = {
    name: 'database3.db',
    securityLevel: relationalStore.SecurityLevel.S1
  }

  static readonly ACCOUNT_TABLE: AccountTable = {
    tableName: 'accountTable2',
    sqlCreate: 'CREATE TABLE IF NOT EXISTS accountTable2 (ArtNo INTEGER PRIMARY KEY, Name TEXT, Price INTEGER, Amount INTEGER)',
    columns: ['ArtNo', 'Name', 'Price', 'Amount']
  }

  static readonly USER_TABLE: UserTable = {
    tableName: 'Users',
    sqlCreate: `
            CREATE TABLE IF NOT EXISTS Users (
                ID INTEGER PRIMARY KEY,
                name TEXT,
                sex TEXT,
                email TEXT,
                password TEXT,
                identity TEXT,
                secret_key TEXT
            )
        `,
    columns: ['ID', 'name', 'sex', 'email', 'password', 'identity', 'secret_key']
  };
}
```
```typescript {.line-numbers}
//AccountInterface.ets
// 定义账户数据接口
export interface AccountData {
  ArtNo: number;          // 货号
  Name: string; // 商品名称
  Price: number;     // 价格
  Amount: number;       // 数量
}
// 定义账户表结构接口
export interface AccountTable {
  tableName: string;     // 表名
  sqlCreate: string;     // 建表 SQL 语句
  columns: Array<string>; // 列名数组
}
```
```typescript {.line-numbers}
//UserInterface.ets
export interface UserData {
  id: number;
  name: string;
  sex: string;
  email: string;
  password: string;
  identity: string;
  secret_key: string;
}

export interface UserTable {
  tableName: string;
  sqlCreate: string;
  columns: Array<string>;
}
```

```typescript {.line-numbers}
//AdminCryptoUtil.ets
import cryptoFramework from '@ohos.security.cryptoFramework';
import util from '@ohos.util';

export class AdminCryptoUtil {
  // 加密消息（使用公钥）
  async encryptMessagePromise(publicKey: cryptoFramework.PubKey, plainText: cryptoFramework.DataBlob) {
    let cipher = cryptoFramework.createCipher('RSA1024|PKCS1');
    await cipher.init(cryptoFramework.CryptoMode.ENCRYPT_MODE, publicKey, null);
    let encryptData = await cipher.doFinal(plainText);
    return encryptData;
  }

  // 解密消息（使用私钥）
  async decryptMessagePromise(privateKey: cryptoFramework.PriKey, cipherText: cryptoFramework.DataBlob) {
    let decoder = cryptoFramework.createCipher('RSA1024|PKCS1');
    await decoder.init(cryptoFramework.CryptoMode.DECRYPT_MODE, privateKey, null);
    let decryptData = await decoder.doFinal(cipherText);
    return decryptData;
  }

  // 生成RSA密钥对（根据固定数据）
  async genKeyPairByData(pubKeyData: Uint8Array, priKeyData: Uint8Array) {
    let pubKeyBlob: cryptoFramework.DataBlob = { data: pubKeyData };
    let priKeyBlob: cryptoFramework.DataBlob = { data: priKeyData };
    let rsaGenerator = cryptoFramework.createAsyKeyGenerator('RSA1024');
    let keyPair = await rsaGenerator.convertKey(pubKeyBlob, priKeyBlob);
    console.info('convertKey success');
    return keyPair;
  }
}

export class RSAKey {
  // 公钥数据
  pkData = new Uint8Array([48, 129, 159, 48, 13, 6, 9, 42, 134, 72, 134, 247, 13, 1, 1, 1, 5, 0, 3, 129, 141, 0, 48, 129, 137, 2, 129, 129, 0, 197, 64, 10, 198, 14, 110, 65, 92, 206, 35, 28, 123, 153, 24, 134, 255, 145, 74, 42, 173, 40, 215, 146, 58, 143, 46, 10, 195, 154, 160, 69, 196, 220, 152, 179, 44, 111, 200, 84, 78, 215, 73, 210, 181, 12, 29, 70, 68, 36, 135, 153, 89, 230, 202, 130, 212, 111, 243, 234, 92, 131, 62, 145, 50, 73, 48, 104, 245, 46, 70, 45, 157, 147, 143, 140, 162, 156, 216, 220, 49, 121, 142, 194, 33, 223, 201, 0, 16, 163, 210, 240, 118, 92, 147, 121, 220, 17, 114, 24, 52, 125, 135, 176, 88, 21, 83, 86, 17, 156, 88, 250, 48, 79, 86, 128, 248, 105, 208, 133, 140, 13, 153, 164, 191, 136, 164, 44, 53, 2, 3, 1, 0, 1]);

  // 私钥数据
  skData = new Uint8Array([48, 130, 2, 119, 2, 1, 0, 48, 13, 6, 9, 42, 134, 72, 134, 247, 13, 1, 1, 1, 5, 0, 4, 130, 2, 97, 48, 130, 2, 93, 2, 1, 0, 2, 129, 129, 0, 197, 64, 10, 198, 14, 110, 65, 92, 206, 35, 28, 123, 153, 24, 134, 255, 145, 74, 42, 173, 40, 215, 146, 58, 143, 46, 10, 195, 154, 160, 69, 196, 220, 152, 179, 44, 111, 200, 84, 78, 215, 73, 210, 181, 12, 29, 70, 68, 36, 135, 153, 89, 230, 202, 130, 212, 111, 243, 234, 92, 131, 62, 145, 50, 73, 48, 104, 245, 46, 70, 45, 157, 147, 143, 140, 162, 156, 216, 220, 49, 121, 142, 194, 33, 223, 201, 0, 16, 163, 210, 240, 118, 92, 147, 121, 220, 17, 114, 24, 52, 125, 135, 176, 88, 21, 83, 86, 17, 156, 88, 250, 48, 79, 86, 128, 248, 105, 208, 133, 140, 13, 153, 164, 191, 136, 164, 44, 53, 2, 3, 1, 0, 1, 2, 129, 128, 70, 75, 184, 139, 53, 1, 94, 17, 240, 244, 218, 101, 193, 253, 215, 190, 164, 204, 197, 192, 200, 89, 107, 39, 171, 119, 65, 38, 204, 168, 105, 180, 234, 217, 16, 161, 185, 132, 175, 103, 25, 154, 153, 153, 36, 36, 26, 178, 150, 66, 45, 8, 185, 19, 90, 228, 210, 177, 30, 200, 177, 141, 78, 184, 248, 59, 113, 154, 145, 73, 160, 24, 73, 157, 86, 207, 186, 32, 95, 200, 106, 252, 107, 69, 170, 193, 216, 196, 181, 142, 74, 203, 15, 18, 89, 228, 152, 19, 239, 21, 233, 98, 121, 214, 57, 187, 111, 239, 223, 248, 199, 70, 223, 108, 108, 113, 234, 144, 155, 95, 246, 144, 244, 122, 39, 55, 127, 81, 2, 65, 0, 246, 96, 188, 0, 0, 104, 221, 105, 139, 144, 63, 175, 209, 87, 179, 162, 88, 192, 99, 82, 125, 53, 54, 48, 70, 245, 239, 37, 15, 242, 247, 84, 115, 187, 196, 95, 156, 40, 165, 60, 64, 102, 13, 229, 243, 2, 149, 0, 232, 226, 221, 192, 95, 11, 12, 208, 5, 181, 98, 62, 210, 190, 141, 235, 2, 65, 0, 204, 244, 34, 10, 105, 80, 76, 116, 163, 35, 231, 168, 187, 206, 189, 101, 215, 103, 80, 115, 86, 11, 34, 127, 203, 114, 84, 188, 121, 174, 169, 31, 142, 2, 182, 27, 140, 225, 157, 227, 71, 98, 15, 203, 187, 213, 5, 190, 20, 121, 8, 30, 193, 100, 232, 101, 141, 8, 124, 20, 29, 78, 6, 95, 2, 65, 0, 204, 43, 225, 224, 6, 118, 224, 117, 100, 200, 199, 94, 70, 23, 109, 175, 173, 232, 208, 230, 61, 8, 105, 189, 156, 48, 150, 91, 154, 89, 248, 136, 173, 215, 254, 166, 84, 220, 130, 1, 234, 68, 40, 100, 84, 251, 224, 202, 254, 51, 115, 28, 198, 38, 124, 25, 175, 129, 94, 199, 61, 17, 216, 189, 2, 64, 72, 230, 129, 129, 48, 138, 134, 87, 106, 123, 231, 247, 165, 173, 216, 194, 115, 198, 228, 223, 209, 120, 46, 114, 68, 92, 75, 117, 170, 214, 140, 131, 147, 208, 181, 19, 193, 157, 178, 186, 87, 246, 178, 101, 166, 79, 20, 54, 211, 51, 101, 199, 2, 197, 48, 192, 134, 84, 193, 69, 170, 82, 201, 131, 2, 65, 0, 213, 165, 55, 166, 131, 210, 195, 56, 250, 147, 195, 61, 205, 208, 189, 185, 40, 52, 50, 119, 137, 23, 246, 46, 220, 108, 52, 23, 152, 154, 94, 32, 144, 195, 184, 249, 21, 168, 12, 57, 222, 18, 60, 117, 81, 157, 72, 30, 155, 190, 165, 242, 228, 139, 240, 184, 145, 170, 103, 210, 160, 161, 135, 13]);
}

// 工具方法：字符串转Uint8Array
export function stringToUint8Array(str: string): Uint8Array {
  const arr = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) {
    arr[i] = str.charCodeAt(i);
  }
  return arr;
}

// 工具方法：Uint8Array转字符串
export function uint8ArrayToString(uint8Array: Uint8Array): string {
  let result = '';
  for (let i = 0; i < uint8Array.length; i++) {
    result += String.fromCharCode(uint8Array[i]);
  }
  return result;
}
```

```typescript {.line-numbers}
//CryptoUtil.ets:
import cryptoFramework from '@ohos.security.cryptoFramework';
import util from '@ohos.util';
import { BusinessError } from '@ohos.base';

export class CryptoUtil {
  private static readonly FIXED_KEY = '1234567890abcdef'; // 16 字节 AES-128 密钥
  private static readonly AES_ALGORITHM = 'AES128|ECB|PKCS5';

  // 字符串转 Uint8Array
  private static stringToUint8Array(str: string): Uint8Array {
    const arr = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) {
      arr[i] = str.charCodeAt(i);
    }
    return arr;
  }

  // Uint8Array 转字符串 (不使用 apply/call)
  private static uint8ArrayToString(uint8Array: Uint8Array): string {
    let result = '';
    for (let i = 0; i < uint8Array.length; i++) {
      result += String.fromCharCode(uint8Array[i]);
    }
    return result;
  }

  // 加密方法
  static async encrypt(plainText: string): Promise<string> {
    try {
      // 1. 创建 SymKeyGenerator 并转成 SymKey
      const keyData = CryptoUtil.stringToUint8Array(CryptoUtil.FIXED_KEY);
      const symKeyBlob: cryptoFramework.DataBlob = { data: keyData };
      const symKeyGenerator = cryptoFramework.createSymKeyGenerator('AES128');
      const symKey = await symKeyGenerator.convertKey(symKeyBlob);

      // 2. 创建 Cipher 并初始化
      const cipher = cryptoFramework.createCipher(CryptoUtil.AES_ALGORITHM);
      await cipher.init(cryptoFramework.CryptoMode.ENCRYPT_MODE, symKey, null);

      // 3. 执行加密
      const plainData = CryptoUtil.stringToUint8Array(plainText); // 使用自定义方法处理
      const cipherBlob = await cipher.doFinal({ data: plainData });

      // 4. Base64 编码
      const base64Helper = new util.Base64Helper();
      return base64Helper.encodeToStringSync(cipherBlob.data);
    } catch (err) {
      const e = err as BusinessError;
      console.error(`加密失败: ${e.message}`);
      return '';
    }
  }

  // 解密方法
  static async decrypt(cipherText: string): Promise<string> {
    try {
      // 1. 创建 SymKeyGenerator 并转成 SymKey
      const keyData = CryptoUtil.stringToUint8Array(CryptoUtil.FIXED_KEY);
      const symKeyBlob: cryptoFramework.DataBlob = { data: keyData };
      const symKeyGenerator = cryptoFramework.createSymKeyGenerator('AES128');
      const symKey = await symKeyGenerator.convertKey(symKeyBlob);

      // 2. 创建 Cipher 并初始化
      const cipher = cryptoFramework.createCipher(CryptoUtil.AES_ALGORITHM);
      await cipher.init(cryptoFramework.CryptoMode.DECRYPT_MODE, symKey, null);

      // 3. Base64 解码
      const base64Helper = new util.Base64Helper();
      // 确保输入是有效的 Base64 字符串
      if (!cipherText || cipherText.trim() === '') {
        throw new Error('输入的密文为空');
      }

      try {
        // 尝试解码
        const decodedData = base64Helper.decodeSync(cipherText);

        // 4. 执行解密
        const plainBlob = await cipher.doFinal({ data: decodedData });

        // 5. 使用自定义方法将 Uint8Array 转为字符串
        return CryptoUtil.uint8ArrayToString(plainBlob.data);
      } catch (decodeErr) {
        console.error(`Base64解码失败: ${(decodeErr as BusinessError).message}`);
        throw new Error('Base64解码失败，可能输入的密文格式不正确');
      }
    } catch (err) {
      const e = err as BusinessError;
      console.error(`解密失败: ${e.message}`);
      return '';
    }
  }

}
```
```typescript {.line-numbers}
// Rbdfunction.ets:
import { relationalStore } from '@kit.ArkData';
import common from '@ohos.app.ability.common'; // Import context type
import RdbUtil from './RdbUtil';

// 数据库操作工具类（继承自 RdbUtil）
export default class RdbFunctions extends RdbUtil {

  constructor(context: common.UIAbilityContext, tableName: string, sqlCreateTable: string, columns: Array<string>) {
    super(context, tableName, sqlCreateTable, columns);
  }

  // 插入数据 (Async/Await version)
  async insertData(data: relationalStore.ValuesBucket): Promise<number> {
    const store = await this.ensureDatabaseReady(); // Ensure connection is ready
    const valueBucket = data;
    return new Promise((resolve, reject) => {
      store.insert(this.tableName, valueBucket, (err, ret) => {
        if (err) {
          console.error('[RdbFunctions]', `insertData() failed, err: ${JSON.stringify(err)}`);
          reject(err); // Reject promise on error
        } else {
          console.info(`[RdbFunctions] insertData() finished, rowId: ${ret}`);
          resolve(ret); // Resolve with the inserted row ID
        }
      });
    });
  }

  // 删除数据 (Async/Await version)
  async deleteData(predicates: relationalStore.RdbPredicates): Promise<number> {
    const store = await this.ensureDatabaseReady();
    return new Promise((resolve, reject) => {
      store.delete(predicates, (err, ret) => {
        if (err) {
          console.error('[RdbFunctions]', `deleteData() failed, err: ${JSON.stringify(err)}`);
          reject(err);
        } else {
          console.info(`[RdbFunctions] deleteData() finished, affected rows: ${ret}`);
          resolve(ret); // Resolve with the number of affected rows
        }
      });
    });
  }

  // 更新数据 (Async/Await version)
  async updateData(predicates: relationalStore.RdbPredicates, data: relationalStore.ValuesBucket): Promise<number> {
    const store = await this.ensureDatabaseReady();
    const valueBucket = data;
    console.log('[RdbFunctions] Executing update, data:', JSON.stringify(valueBucket));
    return new Promise((resolve, reject) => {
      store.update(valueBucket, predicates, (err, ret) => {
        if (err) {
          console.error('[RdbFunctions]', `updateData() failed, code: ${err.code}, message: ${err.message}`);
          reject(err);
        } else {
          console.info(`[RdbFunctions] updateData() finished, affected rows: ${ret}`);
          resolve(ret); // Resolve with the number of affected rows
        }
      });
    });
  }

  // 查询数据 (Async/Await version)
  async query(predicates: relationalStore.RdbPredicates): Promise<relationalStore.ResultSet> {
    const store = await this.ensureDatabaseReady();
    return new Promise((resolve, reject) => {
      store.query(predicates, this.columns, (err, resultSet) => { // Ensure columns are passed if needed by your logic
        if (err) {
          console.error('[RdbFunctions]', `query() failed: ${JSON.stringify(err)}`);
          reject(err);
        } else {
          console.info('[RdbFunctions]', `query() finished successfully.`);
          resolve(resultSet); // Resolve with the ResultSet
        }
      });
    });
  }
}
```
```typescript {.line-numbers}
// RdbUtil.ets:
import { relationalStore } from '@kit.ArkData';
import common from '@ohos.app.ability.common'; // Import context type if needed, adjust path as necessary
import CommonConstants from "../Constants/CommonConstants";

// 数据库工具基类
export default class RdbUtil {
  rdbStore: relationalStore.RdbStore | null = null;
  tableName: string = '';
  sqlCreateTable: string = '';
  columns: Array<string> = [];
  context: common.UIAbilityContext; // Use specific context type

  // 构造函数初始化表信息和上下文
  constructor(context: common.UIAbilityContext, tableName: string, sqlCreateTable: string, columns: Array<string>) {
    this.context = context; // 存储上下文
    this.tableName = tableName;
    this.sqlCreateTable = sqlCreateTable;
    this.columns = columns;
  }

  // 获取数据库连接 (Async/Await version)
  async getRdbStore(): Promise<relationalStore.RdbStore> {
    // If store already exists, return it directly
    if (this.rdbStore) {
      return this.rdbStore;
    }

    return new Promise((resolve, reject) => {
      relationalStore.getRdbStore(
        this.context, // 使用存储的上下文
        CommonConstants.STONE_CONFIG, // Make sure CommonConstants.STONE_CONFIG is correctly defined
        (err, rdb) => {
          if (err) {
            console.error(`[RdbUtil] getRdbStore() failed, err: ${JSON.stringify(err)}`);
            reject(err); // Reject the promise on error
          } else {
            this.rdbStore = rdb;
            // Execute table creation silently, handle potential errors if necessary
            this.rdbStore.executeSql(this.sqlCreateTable).then(() => {
              console.info("[RdbUtil] getRdbStore() succeeded and table checked/created.");
              resolve(this.rdbStore); // Resolve the promise with the store instance
            }).catch(execErr => {
              console.error(`[RdbUtil] executeSql for table creation failed, err: ${JSON.stringify(execErr)}`);
              // Depending on requirements, you might still resolve or reject here
              // Resolving allows connection even if table creation had issues (e.g., already exists)
              resolve(this.rdbStore);
            });
          }
        }
      );
    });
  }

  // Ensure the database connection is ready before operations
  protected async ensureDatabaseReady(): Promise<relationalStore.RdbStore> {
    if (!this.rdbStore) {
      console.info("[RdbUtil] Database store not initialized. Getting store...");
      await this.getRdbStore(); // Wait for the store to be ready
      if (!this.rdbStore) {
        // This should ideally not happen if getRdbStore resolves correctly
        throw new Error("Failed to initialize RDB store after getting it.");
      }
      console.info("[RdbUtil] Database store initialized.");
    }
    return this.rdbStore;
  }
}
```

```typescript {.line-numbers}
// AccountUser.ets：
import { relationalStore } from '@kit.ArkData';
import common from '@ohos.app.ability.common'; // Import context type
import RdbFunctions from './RdbFunctions';
import { AccountData } from './table/AccountInterface';
import CommonConstants from '../Constants/CommonConstants';

export default class AccountUsers {
  private accountUsers: RdbFunctions;
  // No need to store context here if RdbFunctions handles it
  // private context: common.UIAbilityContext;

  // Constructor can be simplified, initialization happens on demand
  constructor(context: common.UIAbilityContext) {
    // this.context = context; // No longer needed here
    this.accountUsers = new RdbFunctions(
      context, // Pass context to RdbFunctions
      CommonConstants.ACCOUNT_TABLE.tableName,
      CommonConstants.ACCOUNT_TABLE.sqlCreate,
      CommonConstants.ACCOUNT_TABLE.columns
    );
    // Removed initial getRdbStore call with callback
    console.info('[AccountUsers] Initialized.');
  }

  // Optional: Method to explicitly initialize the connection if needed early
  async initializeDb(): Promise<void> {
    try {
      await this.accountUsers.getRdbStore();
      console.info('[AccountUsers] Database connection ensured.');
    } catch (error) {
      console.error(`[AccountUsers] Failed to initialize database: ${JSON.stringify(error)}`);
      // Optionally re-throw or handle as needed
      throw error;
    }
  }

  // Optional: Wrapper for getRdbStore if direct access is needed (unlikely now)
  // async getRdbStore(): Promise<relationalStore.RdbStore> {
  //   return this.accountUsers.getRdbStore();
  // }

  async insertData(account: AccountData): Promise<number> {
    const valueBucket = generateBucket(account);
    console.log('[AccountUsers] Inserting data:', JSON.stringify(valueBucket));
    // insertData now returns the row ID or throws an error
    return this.accountUsers.insertData(valueBucket);
  }

  async deleteData(account: AccountData): Promise<number> {
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    predicates.equalTo('ArtNo', account.ArtNo);
    console.log('[AccountUsers] Deleting data for ArtNo:', account.ArtNo);
    return this.accountUsers.deleteData(predicates);
  }

  async updateData(account: AccountData): Promise<number> {
    const valueBucket = generateBucket(account);
    console.log('[AccountUsers] Updating data:', JSON.stringify(valueBucket));
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    predicates.equalTo('ArtNo', account.ArtNo);
    // No need to manually getRdbStore here, updateData handles it
    const affectedRows = await this.accountUsers.updateData(predicates, valueBucket);
    console.log(`[AccountUsers] Update operation result: ${affectedRows} rows affected.`);
    return affectedRows; // Return number of affected rows
  }

  async query(): Promise<AccountData[]> {
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    // No need to manually getRdbStore here, query handles it
    console.log('[AccountUsers] Querying all data...');
    const resultSet = await this.accountUsers.query(predicates);
    let count = resultSet.rowCount;
    const result: AccountData[] = [];

    if (count === 0) {
      console.log('[AccountUsers] Query no result!');
    } else {
      resultSet.goToFirstRow();
      for (let i = 0; i < count; i++) {
        let tmp: AccountData = { ArtNo: 0, Name: '', Price: 0, Amount: 0 };
        // Use try-catch for column access as getColumnIndex might throw if column name is wrong
        try {
          tmp.ArtNo = resultSet.getDouble(resultSet.getColumnIndex('ArtNo'));
          tmp.Name = resultSet.getString(resultSet.getColumnIndex('Name'));
          tmp.Price = resultSet.getDouble(resultSet.getColumnIndex('Price'));
          tmp.Amount = resultSet.getDouble(resultSet.getColumnIndex('Amount'));
          result.push(tmp); // Use push instead of index assignment
        } catch (e) {
          console.error(`[AccountUsers] Error reading row ${i}: ${e.message}`);
          // Skip this row or handle error appropriately
        }
        resultSet.goToNextRow();
      }
      console.log(`[AccountUsers] Query found ${result.length} records.`);
    }
    // Ensure ResultSet is closed
    resultSet.close();
    return result;
  }

  async checkArtNoExists(artNo: number): Promise<boolean> {
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    predicates.equalTo('ArtNo', artNo);
    predicates.limitAs(1); // Optimization: only need to know if at least one exists
    console.log('[AccountUsers] Checking existence for ArtNo:', artNo);

    let resultSet: relationalStore.ResultSet | null = null;
    try {
      resultSet = await this.accountUsers.query(predicates);
      const exists = resultSet.rowCount > 0;
      console.log(`[AccountUsers] ArtNo ${artNo} exists: ${exists}`);
      return exists;
    } catch (error) {
      console.error(`[AccountUsers] Error checking ArtNo existence: ${JSON.stringify(error)}`);
      return false; // Or re-throw error depending on desired behavior
    } finally {
      // Ensure ResultSet is closed even if errors occur
      if (resultSet) {
        resultSet.close();
      }
    }
  }
}

// Helper function: Convert AccountData to database key-value pair
function generateBucket(account: AccountData): relationalStore.ValuesBucket {
  let obj: relationalStore.ValuesBucket = {};
  obj.ArtNo = account.ArtNo;
  obj.Name = account.Name;
  obj.Price = account.Price;
  obj.Amount = account.Amount;
  return obj;
}
```
```typescript {.line-numbers}
// Userusers.ets：
import { relationalStore } from '@kit.ArkData';
import common from '@ohos.app.ability.common'; // Import context type
import RdbFunctions from './RdbFunctions';
import { UserData } from './table/UserInterface';
import CommonConstants from '../Constants/CommonConstants';

export default class UserUsers {
  private userUsers: RdbFunctions;

  constructor(context: common.UIAbilityContext) {
    this.userUsers = new RdbFunctions(
      context, // 传递上下文
      CommonConstants.USER_TABLE.tableName,
      CommonConstants.USER_TABLE.sqlCreate,
      CommonConstants.USER_TABLE.columns
    );
    // Removed initial getRdbStore call with callback
    console.info('[UserUsers] Initialized.');
  }

  // Optional: Method to explicitly initialize the connection
  async initializeDb(): Promise<void> {
    try {
      await this.userUsers.getRdbStore();
      console.info('[UserUsers] Database connection ensured.');
    } catch (error) {
      console.error(`[UserUsers] Failed to initialize database: ${JSON.stringify(error)}`);
      throw error;
    }
  }

  // Optional: Wrapper for getRdbStore
  // async getRdbStore(): Promise<relationalStore.RdbStore> {
  //   return this.userUsers.getRdbStore();
  // }

  async insertData(user: UserData): Promise<number> {
    const valueBucket = generateUserBucket(user);
    console.log('[UserUsers] Inserting user data:', JSON.stringify(valueBucket));
    return this.userUsers.insertData(valueBucket);
  }

  async deleteData(user: UserData): Promise<number> {
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.USER_TABLE.tableName
    );
    predicates.equalTo('ID', user.id); // Use ID as the primary key condition
    console.log('[UserUsers] Deleting user data for ID:', user.id);
    const affectedRows = await this.userUsers.deleteData(predicates);
    console.log(`[UserUsers] Delete operation result: ${affectedRows} rows affected.`);
    return affectedRows;
  }

  async updateData(user: UserData): Promise<number> {
    const valueBucket = generateUserBucket(user);
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.USER_TABLE.tableName
    );
    predicates.equalTo('ID', user.id);
    console.log('[UserUsers] Updating user data for ID:', user.id);
    // No need to manually getRdbStore here
    const affectedRows = await this.userUsers.updateData(predicates, valueBucket);
    console.log(`[UserUsers] Update operation result: ${affectedRows} rows affected.`);
    return affectedRows;
  }

  async query(): Promise<UserData[]> {
    let predicates = new relationalStore.RdbPredicates(CommonConstants.USER_TABLE.tableName);
    console.log('[UserUsers] Querying all user data...');
    const resultSet = await this.userUsers.query(predicates);
    const result: UserData[] = [];
    let count = resultSet.rowCount;

    if (count === 0) {
      console.log('[UserUsers] Query no result!');
    } else {
      resultSet.goToFirstRow();
      for (let i = 0; i < count; i++) {
        try {
          let tmp: UserData = {
            id: resultSet.getLong(resultSet.getColumnIndex('ID')),
            name: resultSet.getString(resultSet.getColumnIndex('name')),
            sex: resultSet.getString(resultSet.getColumnIndex('sex')),
            email: resultSet.getString(resultSet.getColumnIndex('email')),
            password: resultSet.getString(resultSet.getColumnIndex('password')), // Keep encrypted pwd here
            identity: resultSet.getString(resultSet.getColumnIndex('identity')),
            secret_key: resultSet.getString(resultSet.getColumnIndex('secret_key'))
          };
          result.push(tmp);
        } catch(e) {
          console.error(`[UserUsers] Error reading row ${i}: ${e.message}`);
        }
        resultSet.goToNextRow();
      }
      console.log(`[UserUsers] Query found ${result.length} user records.`);
    }
    resultSet.close();
    return result;
  }
}

// Helper function to generate ValuesBucket for UserData
function generateUserBucket(user: UserData): relationalStore.ValuesBucket {
  let obj: relationalStore.ValuesBucket = {};
  // IMPORTANT: Only include fields that exist in your USER_TABLE.columns definition
  // Assuming ID is auto-generated and not needed in insert/update bucket usually
  // obj.ID = user.id; // Uncomment if ID needs to be explicitly set/updated
  obj.name = user.name;
  obj.sex = user.sex;
  obj.email = user.email;
  obj.password = user.password; // Store the encrypted password
  obj.identity = user.identity;
  obj.secret_key = user.secret_key;
  return obj;
}
```

```typescript {.line-numbers}
//ManagerCloth.ets

import { AccountData } from '../../Common/database/table/AccountInterface';
import AccountUsers from '../../Common/database/AccountUsers';
import common from '@ohos.app.ability.common'; // Import context type
import promptAction from '@ohos.promptAction';
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit'; // For specific error type handling

let storage = LocalStorage.getShared(); // Assuming shared storage is needed

@Entry(storage) // Make sure storage is properly initialized if linked vars are used
@Component
struct Index {
  // @State message: string = '查询结果'; // Seems unused, can be removed
  // State for Add form - use strings for input fields
  @State addArtNoStr: string = '';
  @State addName: string = '';
  @State addPriceStr: string = '';
  @State addAmountStr: string = '';

  // State for Update form
  @State updateArtNoStr: string = '';
  @State updateName: string = '';
  @State updatePriceStr: string = '';
  @State updateAmountStr: string = '';

  // State for Delete form
  @State deleteArtNoStr: string = '';

  // @State isFilterStock: boolean = false; // Filter state, not used in provided build
  scroller: Scroller = new Scroller()
  @State dataList: AccountData[] = []; // Holds the displayed data
  @State isLoading: boolean = false; // Optional: for loading indicators

  // Database handler instance - Assuming AccountUsers constructor is refactored
  private accountUsers = new AccountUsers(getContext(this) as common.UIAbilityContext);

  // @LocalStorageLink('AccountDataCommodity') AccountDataCommodity: AccountData[] = []; // Example if needed

  // Load initial data when the component appears
  async aboutToAppear(): Promise<void> {
    console.info("[Index] Component appearing. Loading initial data...");
    await this.refreshDataList();
  }

  // --- Reusable Data Refresh Function ---
  async refreshDataList(): Promise<void> {
    console.info("[Index] Refreshing data list...");
    this.isLoading = true; // Optional: Show loading state
    try {
      const result = await this.accountUsers.query(); // Await the query
      this.dataList = result; // Update the state variable directly
      console.info(`[Index] Data list refreshed. ${result.length} items loaded.`);
    } catch (error) {
      console.error(`[Index] Failed to query data: ${JSON.stringify(error)}`);
      promptAction.showToast({ message: '查询数据失败' });
      this.dataList = []; // Clear list on error
    } finally {
      this.isLoading = false; // Optional: Hide loading state
    }
  }

  // --- Input Validation Helper ---
  // (Could be expanded with more specific checks)
  private validateAccountData(artNo: number, name: string, price: number, amount: number): { isValid: boolean; message?: string } {
    if (isNaN(artNo) || artNo <= 0) return { isValid: false, message: '请输入有效的货号 (正数)' };
    if (!name?.trim()) return { isValid: false, message: '请输入商品名称' };
    if (isNaN(price) || price < 0) return { isValid: false, message: '请输入有效的价格 (非负数)' };
    if (isNaN(amount) || amount < 0 || !Number.isInteger(amount)) return { isValid: false, message: '请输入有效的数量 (非负整数)' };
    return { isValid: true };
  }


  // --- Action Handlers (Async) ---

  async handleAdd(): Promise<void> {
    console.info("[Index] Add button clicked.");
    const artNo = parseInt(this.addArtNoStr);
    const name = this.addName;
    const price = parseFloat(this.addPriceStr);
    const amount = parseInt(this.addAmountStr);

    const validation = this.validateAccountData(artNo, name, price, amount);
    if (!validation.isValid) {
      promptAction.showToast({ message: validation.message });
      return;
    }

    const newAccount: AccountData = { ArtNo: artNo, Name: name, Price: price, Amount: amount };
    this.isLoading = true; // Optional

    try {
      const exists = await this.accountUsers.checkArtNoExists(newAccount.ArtNo);
      if (exists) {
        promptAction.showDialog({ message: '该商品货号已存在' });
        console.warn(`[Index] Add failed: ArtNo ${newAccount.ArtNo} already exists.`);
      } else {
        console.info("[Index] Adding new item:", JSON.stringify(newAccount));
        await this.accountUsers.insertData(newAccount);
        promptAction.showToast({ message: '添加成功' });
        console.info("[Index] Item added successfully.");
        await this.refreshDataList(); // Refresh list after adding
        // Clear add form fields
        this.addArtNoStr = ''; this.addName = ''; this.addPriceStr = ''; this.addAmountStr = '';
      }
    } catch (error) {
      console.error(`[Index] Add failed: ${JSON.stringify(error)}`);
      promptAction.showToast({ message: `添加失败: ${error.message || '未知错误'}` });
      await this.refreshDataList(); // Refresh list even on error to ensure consistency
    } finally {
      this.isLoading = false; // Optional
    }
  }

  async handleUpdate(): Promise<void> {
    console.info("[Index] Update button clicked.");
    const artNo = parseInt(this.updateArtNoStr);
    const name = this.updateName; // Allow empty name for update? Decide based on requirement
    const price = parseFloat(this.updatePriceStr);
    const amount = parseInt(this.updateAmountStr);

    // Validate ArtNo separately for update
    if (isNaN(artNo) || artNo <= 0) {
      promptAction.showToast({ message: '请输入要更新的有效货号' });
      return;
    }
    // Validate other fields only if they are provided (or require them)
    if (this.updateName && !name?.trim()) { promptAction.showToast({ message: '名称不能为空' }); return; } // Example: If name is provided, it cannot be empty
    if (this.updatePriceStr && (isNaN(price) || price < 0)) { promptAction.showToast({ message: '请输入有效的价格' }); return; }
    if (this.updateAmountStr && (isNaN(amount) || amount < 0 || !Number.isInteger(amount))) { promptAction.showToast({ message: '请输入有效的数量' }); return; }

    // Construct the update object - decide how to handle partial updates
    // Simplest: assume all fields are meant to be updated if provided
    const updatedAccount: AccountData = {
      ArtNo: artNo,
      // Only include fields if they have values, or fetch existing first for true partial update
      Name: name, // Send current value (could be empty if user cleared it)
      Price: isNaN(price) ? 0 : price, // Default to 0 or fetch existing if invalid/empty
      Amount: isNaN(amount) ? 0 : amount // Default to 0 or fetch existing if invalid/empty
    };

    this.isLoading = true; // Optional

    try {
      const exists = await this.accountUsers.checkArtNoExists(updatedAccount.ArtNo);
      if (!exists) {
        promptAction.showDialog({ message: '要更新的商品不存在' });
        console.warn(`[Index] Update failed: ArtNo ${updatedAccount.ArtNo} does not exist.`);
      } else {
        console.info("[Index] Updating item:", JSON.stringify(updatedAccount));
        const affectedRows = await this.accountUsers.updateData(updatedAccount); // updateData returns affected row count
        if (affectedRows > 0) {
          promptAction.showToast({ message: '更新成功' });
          console.info(`[Index] Item updated successfully. ${affectedRows} rows affected.`);
          await this.refreshDataList();
          // Clear update form fields
          this.updateArtNoStr = ''; this.updateName = ''; this.updatePriceStr = ''; this.updateAmountStr = '';
        } else {
          promptAction.showToast({ message: '更新未影响任何记录 (数据可能未更改)' });
          console.warn("[Index] Update completed but no rows were affected.");
          await this.refreshDataList(); // Still refresh to be safe
        }
      }
    } catch (error) {
      console.error(`[Index] Update failed: ${JSON.stringify(error)}`);
      promptAction.showToast({ message: `更新失败: ${error.message || '未知错误'}` });
      await this.refreshDataList(); // Refresh list even on error
    } finally {
      this.isLoading = false; // Optional
    }
  }

  async handleDelete(): Promise<void> {
    console.info("[Index] Delete button clicked.");
    const artNo = parseInt(this.deleteArtNoStr);

    if (isNaN(artNo) || artNo <= 0) {
      promptAction.showToast({ message: '请输入有效的货号进行删除' });
      return;
    }

    this.isLoading = true; // Optional

    try {
      const exists = await this.accountUsers.checkArtNoExists(artNo);
      if (!exists) {
        promptAction.showDialog({ message: '要删除的商品不存在' });
        console.warn(`[Index] Delete failed: ArtNo ${artNo} does not exist.`);
      } else {
        // Confirmation Dialog
        const confirmRes = await promptAction.showDialog({
          title: '确认删除',
          message: `确定要删除货号为 ${artNo} 的商品吗？此操作无法撤销。`,
          buttons: [
            { text: '取消', color: '#666666' },
            { text: '确定删除', color: '#FF0000' } // Red for destructive action
          ]
        });

        if (confirmRes.index === 1) { // Index 1 is '确定删除'
          console.info("[Index] Deleting item with ArtNo:", artNo);
          // Pass only needed data for deletion predicate
          const accountToDelete: AccountData = { ArtNo: artNo, Name: '', Price: 0, Amount: 0 };
          const affectedRows = await this.accountUsers.deleteData(accountToDelete); // deleteData returns affected rows
          if (affectedRows > 0) {
            promptAction.showToast({ message: '删除成功' });
            console.info(`[Index] Item deleted successfully. ${affectedRows} rows affected.`);
            await this.refreshDataList();
            this.deleteArtNoStr = ''; // Clear delete form field
          } else {
            // This case is less likely if checkArtNoExists passed, but possible race condition or other issue
            promptAction.showToast({ message: '删除失败 (商品可能已被删除)' });
            console.warn("[Index] Delete completed but no rows were affected.");
            await this.refreshDataList(); // Refresh anyway
          }
        } else {
          console.info("[Index] Deletion cancelled by user.");
        }
      }
    } catch (error) {
      // Handle errors from checkArtNoExists, showDialog, or deleteData
      if (error instanceof BusinessError) { // Catch specific dialog errors if needed
        console.warn(`[Index] Dialog error/dismissed: ${error.code} - ${error.message}`)
      } else {
        console.error(`[Index] Delete operation failed: ${JSON.stringify(error)}`);
        promptAction.showToast({ message: `删除失败: ${error.message || '未知错误'}` });
        await this.refreshDataList(); // Refresh list even on error
      }
    } finally {
      this.isLoading = false; // Optional
    }
  }


  // --- UI Build Method (Mostly unchanged, just onClick handlers updated) ---
  build() {
    Scroll(this.scroller) { // Use the scroller instance
      Column({ space: 20 }) { // Add space between main sections
        // --- Header ---
        Row({ space: 16 }) {
          Text("服装信息管理系统")
            .fontSize(28) // Slightly smaller
            .fontWeight(FontWeight.Bold)
            .layoutWeight(1) // Allow text to take available space
            .textAlign(TextAlign.Start) // Align left

          Button('返回')
            .type(ButtonType.Normal)
            .width(80).height(40)
            .fontColor('#333') // Better contrast
            .backgroundColor('#E0E0E0')
            .borderRadius(8)
            .onClick(() => {
              console.info("[Index] Navigating back to ManagerHomepage.");
              router.pushUrl({ url: 'pages/ManagerPages/ManagerHomepage' });
            })
        }
        .width('100%') // Ensure row takes full width
        .margin({ bottom: 10 }) // Add margin below header

        // --- Add Section ---
        Column({ space: 10 }) {
          Text("添加新商品").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start)
          Row({ space: 10 }) {
            TextInput({ placeholder: '货号', text: this.addArtNoStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addArtNoStr = value)
            TextInput({ placeholder: '名称', text: this.addName })
              .width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addName = value)
          }.width('100%')
          Row({ space: 10 }) {
            TextInput({ placeholder: '价格', text: this.addPriceStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addPriceStr = value)
            TextInput({ placeholder: '数量', text: this.addAmountStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.addAmountStr = value)
          }.width('100%')
          Button('添加商品')
            .width('100%').height(45).margin({ top: 5 })
            .backgroundColor('#4CAF50').fontColor(Color.White).borderRadius(8)
            .onClick(async () => { await this.handleAdd(); }) // Call async handler
        }
        .padding(15).borderRadius(12).backgroundColor("#f0f0f0").width('100%')

        // --- Update Section ---
        Column({ space: 10 }) {
          Text("更新商品信息").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start)
          Row({ space: 10 }) {
            TextInput({ placeholder: '货号 (必填)', text: this.updateArtNoStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updateArtNoStr = value)
            TextInput({ placeholder: '新名称', text: this.updateName })
              .width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updateName = value)
          }.width('100%')
          Row({ space: 10 }) {
            TextInput({ placeholder: '新价格', text: this.updatePriceStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updatePriceStr = value)
            TextInput({ placeholder: '新数量', text: this.updateAmountStr })
              .type(InputType.Number).width('48%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
              .onChange((value) => this.updateAmountStr = value)
          }.width('100%')
          Button('更新商品')
            .width('100%').height(45).margin({ top: 5 })
            .backgroundColor('#FFA726').fontColor(Color.White).borderRadius(8) // Orange for update
            .onClick(async () => { await this.handleUpdate(); }) // Call async handler
        }
        .padding(15).borderRadius(12).backgroundColor("#f0f0f0").width('100%')

        // --- Delete Section ---
        Column({ space: 10 }) {
          Text("删除商品").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start)
          TextInput({ placeholder: '输入要删除的货号', text: this.deleteArtNoStr })
            .type(InputType.Number).width('100%').height(40).backgroundColor('#FFFFFF').borderRadius(6)
            .onChange((value) => this.deleteArtNoStr = value)
          Button('删除商品')
            .width('100%').height(45).margin({ top: 5 })
            .backgroundColor('#F44336').fontColor(Color.White).borderRadius(8) // Red for delete
            .onClick(async () => { await this.handleDelete(); }) // Call async handler
        }
        .padding(15).borderRadius(12).backgroundColor("#f0f0f0").width('100%')

        // --- Data Display Section ---
        Column() {
          Text("商品列表").fontSize(18).fontWeight(FontWeight.Medium).alignSelf(ItemAlign.Start).margin({ bottom: 10 })
          // Table Header
          Row() {
            Text('货号').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
            Text('名称').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
            Text('价格').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
            Text('数量').width('25%').fontWeight(FontWeight.Bold).textAlign(TextAlign.Center).padding(8).backgroundColor('#e0e0e0')
          }
          .width('100%').borderRadius(6).border({ width: 1, color: '#ccc' })

          // Data Rows / Loading / Empty State
          Stack({ alignContent: Alignment.TopStart }) { // Use Stack for potential overlay
            if (this.isLoading) {
              Progress({ type: ProgressType.Linear }).width('100%').margin({ top: 5 })
            } else if (this.dataList.length > 0) {
              ForEach(this.dataList, (item: AccountData) => {
                Row() {
                  Text(item.ArtNo.toString()).width('25%').textAlign(TextAlign.Center).padding(8)
                  Text(item.Name).width('25%').textAlign(TextAlign.Center).padding(8).textOverflow({overflow: TextOverflow.Ellipsis}).maxLines(1) // Prevent long names breaking layout
                  Text(item.Price.toFixed(2)).width('25%').textAlign(TextAlign.Center).padding(8) // Format price
                  Text(item.Amount.toString()).width('25%').textAlign(TextAlign.Center).padding(8)
                }
                .width('100%')
                .border({ width: { bottom: 1 }, color: '#e0e0e0' }) // Border between rows
              }, (item: AccountData) => item.ArtNo.toString()) // Key generator
            } else {
              Text("没有商品信息可显示")
                .width('100%')
                .padding(20)
                .textAlign(TextAlign.Center)
                .fontColor('#888')
            }
          } // End Stack

          // Refresh Button (Moved below list)
          Button('刷新列表')
            .width('100%').height(45).margin({ top: 15 })
            .backgroundColor('#2196F3').fontColor(Color.White).borderRadius(8) // Blue for refresh
            .onClick(async () => { await this.refreshDataList(); }) // Call async refresh

        }
        .width('100%').margin({ top: 20 }) // Add margin above the list section

      } // End main Column
      .width('95%') // Constrain content width slightly
      .padding({ top: 20, bottom: 30 }) // Add padding top/bottom
      .alignItems(HorizontalAlign.Center) // Center content horizontally

    } // End Scroll
    .width('100%').height('100%')
    .scrollable(ScrollDirection.Vertical)
    .scrollBar(BarState.Auto) // Show scrollbar only when needed
    .backgroundColor('#FAFAFA') // Slightly off-white background
  }
}
```
```typescript {.line-numbers}
//UserInformation.ets
import { UserData } from '../../Common/database/table/UserInterface';
import { router } from '@kit.ArkUI';
import { CryptoUtil } from '../../Common/database/CryptoUtil';
import { AdminCryptoUtil, RSAKey, uint8ArrayToString } from '../../Common/database/AdminCryptoUtil';
import { util } from '@kit.ArkTS';
import { cryptoFramework } from '@kit.CryptoArchitectureKit';

let storage = LocalStorage.getShared();

@Entry(storage)
@Component
struct UserInformation {
  @LocalStorageLink('Users') users: UserData[] = [];
  @State decryptedList: UserData[] = [];

  // 日志方法，带组件名、日志级别和时间戳
  private log(level: 'info' | 'warn' | 'error', message: string) {
    const prefix = `[UserInfo][${level.toUpperCase()}][${new Date().toISOString()}] `;
    console[level](`${prefix}${message}`);
  }

  aboutToAppear(): void {
    this.log('info', '组件即将出现，加载本地用户数据');
    // 从本地取出原始列表
    this.users = storage.get('Users') || [];
    this.log('info', `共载入 ${this.users.length} 条用户记录`);
    this.decryptAll();
  }

  private async decryptAll(): Promise<void> {
    this.log('info', '开始解密所有用户密码');
    const list: UserData[] = [];
    for (const item of this.users) {
      this.log('info', `解密用户 ${item.name} (ID:${item.id}) 密码开始`);
      let plainPwd: string;
      if (item.identity === '普通用户') {
        // 普通用户使用AES解密
        plainPwd = await CryptoUtil.decrypt(item.password);
      } else {
        // 管理员使用RSA解密
        const adminCrypto = new AdminCryptoUtil();
        const rsaKey = new RSAKey();
        const keyPair = await adminCrypto.genKeyPairByData(rsaKey.pkData, rsaKey.skData);
        const privateKey = keyPair.priKey;
        const base64Helper = new util.Base64Helper();
        const cipherData = base64Helper.decodeSync(item.password);
        const cipherText: cryptoFramework.DataBlob = { data: cipherData };
        const decryptData = await adminCrypto.decryptMessagePromise(privateKey, cipherText);
        plainPwd = uint8ArrayToString(decryptData.data);
      }
      this.log('info', `解密用户 ${item.name} (ID:${item.id}) 密码完成`);

      // 手动构建一个新对象，避免使用对象 spread
      const newUser: UserData = {
        id: item.id,
        name: item.name,
        sex: item.sex,
        email: item.email,
        password: plainPwd,
        identity: item.identity,
        secret_key: item.secret_key
      };
      list.push(newUser);
    }
    this.decryptedList = list;
    this.log('info', `所有用户解密完成，共 ${list.length} 条记录`);
  }

  build() {
    Column() {
      // 头部导航栏
      Row() {
        Text('用户信息')
          .fontSize(30)
          .fontWeight(FontWeight.Bold)
          .fontColor('#1a1a1a')
          .layoutWeight(1);

        Button('返回')
          .type(ButtonType.Normal)
          .width(80)
          .height(40)
          .fontColor('#ff151414')
          .backgroundColor('#ffffff')
          .borderRadius(8)
          .onClick(() => {
            this.log('info', '点击返回，跳转到管理首页');
            router.pushUrl({ url: 'pages/ManagerPages/ManagerHomepage' });
          });
      }
      .width('90%')
      .padding({ top: 15, bottom: 15 })
      .backgroundColor('#f5f5f5')
      .borderRadius(12);

      // 用户列表
      List({ space: 15 }) {
        ForEach(this.decryptedList, (item: UserData) => {
          ListItem() {
            Column() {
              // 用户基本信息行
              Row() {
                Text(item.name)
                  .fontSize(24)
                  .fontWeight(FontWeight.Bold)
                  .fontColor('#333333');

                // 角色徽章
                Text(item.identity)
                  .fontSize(18)
                  .fontColor('#ffffff')
                  .backgroundColor(item.identity === '管理员' ? '#ff8000' : '#4CAF50')
                  .padding({ left: 10, right: 10, top: 4, bottom: 4 })
                  .borderRadius(15)
                  .margin({ left: 10 });
              }
              .width('100%')
              .padding({ bottom: 12 });

              Row() {
                Image(item.sex === '女' ? $r('app.media.woman') : $r('app.media.man'))
                  .width('20%')
                  .borderRadius(24)
                  .margin({ right: 10 });
                Column({ space: 8 }) {
                  this.InfoItem('性别', item.sex);
                  this.InfoItem('邮箱', item.email);
                  this.InfoItem('密码', item.password);
                }
                .width('80%')
                .padding(20)
                .backgroundColor('#f9f9f9')
                .borderRadius(8);
              }
            }
            .padding(16)
            .backgroundColor('#ffffff')
            .borderRadius(12)
            .shadow({ radius: 8, color: '#1a000000', offsetX: 2, offsetY: 2 });
          }
          .margin({ bottom: 15 });
        })
      }
      .width('100%')
      .padding(15)
      .layoutWeight(1)
      .backgroundColor('#f0f0f0');
    }
    .width('100%')
    .height('100%')
    .backgroundColor('#f5f5f5');
  }

  // 自定义信息项组件
  @Builder
  InfoItem(label: string, value: string) {
    Row() {
      Text(label + '：')
        .fontSize(15)
        .fontColor('#666666')
        .width(45);

      Text(value)
        .fontSize(15)
        .fontColor('#333333')
        .layoutWeight(1)
        .textAlign(TextAlign.End);
    }
    .border({ width: 0.5, color: '#eeeeee' });
  }
}

```
```typescript {.line-numbers}
//ClothInformation.ets
import { router } from '@kit.ArkUI';
import AccountUsers from '../../Common/database/AccountUsers';
import { AccountData } from '../../Common/database/table/AccountInterface';

let storage = LocalStorage.getShared();

@Entry(storage)
@Component
struct User_Acc {
  @State dataList: AccountData[] = [];
  @LocalStorageLink('AccountDataCommodity') AccountDataCommodity: AccountData[] = [];

  // 统一日志方法
  private log(level: 'info' | 'warn' | 'error', message: string) {
    const prefix = `[UserAcc][${level.toUpperCase()}][${new Date().toISOString()}] `;
    console[level](`${prefix}${message}`);
  }

  private accountUsers = new AccountUsers(getContext(this), () => {
    this.log('info', '数据库初始化成功');
  });

  aboutToAppear(): void {
    this.log('info', '组件即将出现，开始查询账户数据');
    this.accountUsers.query((result: AccountData[]) => {
      this.dataList = result;
      this.log('info', `查询完成，共获取 ${result.length} 条记录`);
    });
  }

  build() {
    Column() {
      // 顶部导航栏
      Row({ space: 16 }) {
        Text("XX服装店")
          .fontSize(28)
          .fontWeight(FontWeight.Bold)
          .fontColor('#1a1a1a')
          .layoutWeight(1);

        Button('退出登录')
          .type(ButtonType.Normal)
          .width(100)
          .height(40)
          .fontSize(16)
          .backgroundColor('#ff4444')
          .fontColor('#ffffff')
          .borderRadius(8)
          .onClick(() => {
            this.log('info', '退出登录按钮点击，跳转登录页面');
            router.pushUrl({ url: 'pages/CommonPages/login' });
          });
      }
      .width('90%')
      .padding({ top: 15, bottom: 15 })
      .margin({ top: 10 });

      // 商品列表
      List({ space: 15 }) {
        ForEach(this.dataList, (item: AccountData) => {
          ListItem() {
            Row({ space: 18 }) {
              // 商品图片
              Image($r('app.media.Clothes'))
                .width(100)
                .aspectRatio(1)
                .borderRadius(8)
                .objectFit(ImageFit.Cover);

              // 商品信息
              Column() {
                this.InfoItem('货号', item.ArtNo.toString());
                this.InfoItem('名称', item.Name);
                this.InfoItem('价格', `$${item.Price}`);
                this.InfoItem('库存', `${item.Amount}件`);
              }
              .layoutWeight(1)
              .height(120)
              .justifyContent(FlexAlign.SpaceBetween);
            }
            .padding(16)
            .backgroundColor('#ffffff')
            .borderRadius(20)
            .shadow({ radius: 6, color: '#1a000000', offsetX: 1, offsetY: 1 });
          }
        });
      }
      .width('100%')
      .padding(18)
      .layoutWeight(1)
      .backgroundColor('#f5f5f5');
    }
    .height('100%')
    .width('100%')
    .backgroundColor('#f0f0f0');
  }

  // 自定义信息项组件
  @Builder
  InfoItem(label: string, value: string) {
    Row() {
      Text(label + '：')
        .fontSize(16)
        .fontColor('#666666')
        .width(60);

      Text(value)
        .fontSize(16)
        .fontColor('#333333')
        .layoutWeight(1)
        .textAlign(TextAlign.End)
        .maxLines(1)
        .textOverflow({ overflow: TextOverflow.Ellipsis });
    }
    .width('100%');
  }
}

```
