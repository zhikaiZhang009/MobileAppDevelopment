```java
// 导入ArkUI的路由模块，用于页面返回操作
import { router } from '@kit.ArkUI';
// 导入基础服务错误类型，用于错误处理
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry装饰器标记此为页面入口组件
@Entry// @Entry start
  // @Component装饰器声明自定义组件
@Component// @Component start
struct Second {// struct Index start
  // @State装饰器管理组件状态，message变化会触发UI更新
  @State message: string = 'Hi there'

  // build方法描述UI结构
  build() {// build() start
    // Row横向布局容器
    Row() {// Row() start
      // Column纵向布局容器（作为Row的唯一子元素）
      Column() {// Column() start
        // 显示状态变量message的文本组件
        Text(this.message)// Text() start
          .fontSize(50)          // 字体大小50
          .fontWeight(FontWeight.Bold)  // 加粗字体
        // Text() end
        Image('image/fafu.jpg').width(200)// 创建图片组件，加载路径为'image/fafu.jpg'的图片
        // 创建第一个文本输入框（普通输入模式）
        TextInput({placeholder:'请输入、、、、'})// 设置占位符提示文本
          .placeholderColor(Color.Grey)// 设置占位符文本颜色为灰色
          .placeholderFont({size:14,weight:400})// 设置占位符字体样式
          .caretColor(Color.Blue)// 设置输入光标的颜色为蓝色
          .width(300)// 设置输入框宽度为300单位
          .height(40)// 设置输入框高度为40单位
          .margin(20)// 设置外边距为20单位
          .fontSize(24)// 设置输入文本字号为24单位
          .fontColor(Color.Black)// 设置输入文本颜色为黑色
        
        TextInput({placeholder:'请输入、、、、'})// 创建第二个文本输入框（密码输入模式）
          .width(300)// 宽度300单位
          .height(40)// 高度40单位
          .margin(20)// 高度40单位
          .fontSize(24)// 输入文本字号24单位
          .type(InputType.Password)// 设置输入类型为密码模式（显示为圆点）
          .maxLength(9)// 限制最大输入长度为9个字符
          .showPasswordIcon(true)// 显示密码可见性切换图标（眼睛图标）

        // 返回按钮组件
        Button() {// Button() start
          // 按钮内的文本组件
          Text('Back')// Text() start
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }// Text() end
        // Button() end

        // 设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        // 设置上边距20
        .margin({// margin对象字面量 start
          top: 20
        })// margin对象字面量 end
        // 设置背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        // 设置宽度为父容器的40%
        .width('40%')
        // 设置高度为父容器的5%
        .height('5%')
        // 绑定点击事件处理
        .onClick(() => {// onClick回调函数 start
          // 点击时输出日志
          console.info(`Succeeded in clicking the 'Back' button.`)

          try {//try start
            // 使用路由模块返回上一页
            router.back()
            // 返回成功日志
            console.info('Succeeded in returning to the first page.')
          }//try end
          catch (err) {//catch() start
            // 错误类型转换（TypeScript类型断言）
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            // 输出带错误码的日志
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          }//catch() end
        })//onClick回调函数 start
      }//Column() end
      // Column占满父容器宽度
      .width('100%')
    }// Row() end
    // Row占满父容器高度
    .height('100%')
  }// build() end
}// struct Index end
// @Component end
// @Entry end
```