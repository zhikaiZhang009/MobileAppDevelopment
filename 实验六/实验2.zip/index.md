# 实验二
### 学号：3225706100
### 姓名：黄永实


```java
// 导入ArkUI的路由模块，用于页面跳转管理
import { router } from '@kit.ArkUI';
// 导入基础服务错误类型，用于错误处理
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry装饰器标记此为应用入口组件
@Entry// @Entry start
  // @Component装饰器声明自定义组件
@Component// @Component start
struct Index {// struct Index start
  // @State装饰器管理组件状态，message变化会触发UI更新
  @State message: string = 'Hello World'
  @State progressValue: number = 0
  // build方法描述UI结构
  build() {// build() start
    // Row横向布局容器
    Row() {// Row() start
      // Column纵向布局容器（Row的唯一子元素）
      Column() {// Column() start
      // 创建时间显示组件，格式为年月日时分秒（YYYYMMDD hh:mm:ss）
        TextClock()
        .margin(20)// 设置外边距为20单位
        .fontSize(30)// 设置字体大小为30单位
        .format('YYYYMMDD hh:mm:ss')// 设置时间格式：年-月-日 时:分:秒
        // 创建搜索框组件
        Search({placeholder:'输入内容、、、、、'})// 设置占位符提示文本
          .searchButton('搜索')// 设置搜索按钮显示为"搜索"
          .width(300)// 设置搜索框宽度为300单位
          .height(80)// 设置搜索框高度为80单位
          .placeholderColor(Color.Grey)// 设置占位符文本颜色为灰色
          .placeholderFont({size:24,weight:400})// 设置占位符字体样式
          .textFont({size:24,weight:400})// 设置输入文本的字体样式
        // 创建跑马灯组件（第一条）
        Marquee({
          start:true,                     // 自动开始滚动
          step:12,                        // 每次滚动步长12像素
          loop:-1,                        // 循环次数为无限（-1表示无限循环）
          fromStart:true,                 // 从头开始滚动
          src:"          HarmonyOS也称为鸿蒙系统"  // 滚动显示的文本内容（开头添加空格留出起始空白）
          }).fontSize(20)                   // 设置字体大小为20单位
        // 创建跑马灯组件（第二条）
        Marquee({
          start:true,                     // 自动开始滚动
          step:12,                        // 每次滚动步长12像素
          loop:-1,                        // 循环次数为无限
          fromStart:true,                 // 从头开始滚动
          src:"在系统的单设备系统能力基础上,HarmonyOS提出了基于同一套系统能力、适配多种终端形态的分布理念。"  // 长文本内容
        }).fontSize(20)                   // 设置字体大小为20单位
        // 文本组件显示状态变量message
        Text(this.message)// Text() start
          .fontSize(50)          // 字体大小50
          .fontWeight(FontWeight.Bold)  // 加粗字体
        // Text() end
        Image('image/OIP-C.jpg').width(200)// 创建图片组件，加载路径为'image/OIP-C.jpg'的图片
        Progress({value:0, total:100, type:ProgressType.Capsule})// 创建胶囊型进度条组件
        .color(Color.Grey).width(200).height(50).value(this.progressValue)//设置样式
        Row().width('100%').height(5)// 创建一个空行作为分隔线（宽度100%，高度5单位）
        
        Button("进度条+5")// 创建按钮，点击后增加进度值
          .onClick(()=>{// 点击事件回调
            this.progressValue += 5// 每次点击增加5%进度
            if (this.progressValue > 100){
              this.progressValue = 0// 超过100%时重置为0
            }
          })
         
        Slider({ // 创建滑动条组件
          value:40,// 初始值为40
          min:10,// 最小值为10
          max:100,// 最大值为100
          style:SliderStyle.OutSet,// 滑动条样式为外凸效果
        }).blockColor('#191970').trackColor('#ADD8E6').selectedColor('#4169E1')
          .showTips(true).width('80%')
        // 按钮组件开始
        Button() {// Button() start
          // 按钮内的文本组件
          Text('Next')// Text() start
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }// Text() end
        // Button() end

        // 设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        // 设置上边距20
        .margin({ // margin对象字面量 start
          top: 20
        })// margin对象字面量 end
        // 设置背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        // 设置宽度为父容器的40%
        .width('40%')
        // 设置高度为父容器的5%
        .height('5%')
        // 绑定点击事件处理

        .onClick(() => {// onClick回调函数 start
          // 点击时输出日志
          console.info(`Succeeded in clicking the 'Next' button.`)

          // 使用路由模块跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() => {// then回调 start
            // 跳转成功回调
            console.info('Succeeded in jumping to the second page.')
          }).catch((err: BusinessError) => {// catch回调 start
            // 跳转失败回调，输出错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })// catch回调 end
        })// onClick回调函数 end
      }// Column() end
      // Column占满父容器宽度
      .width('100%')
    }// Row() end
    // Row占满父容器高度
    .height('100%')
  }// build() end
}// struct Index end
// @Component end
// @Entry end
```