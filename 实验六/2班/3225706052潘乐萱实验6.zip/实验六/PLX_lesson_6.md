
# 实验六报告

> 学号：3225706052
> 
> 姓名：潘乐萱
> 
> 指导老师：张凯斌
> 
> 实验日期：<2025-04-30

## 一、实验目的

- 完成实验五中的L/R页面功能；
- 锻炼课堂所讲授的面向对象分析与设计能力；
- 实践编码能力

## 二、实验内容

- 依托教科书的第9章“数据管理”；
- 回顾实验三与实验四内容；
- 结合《课程指导》

完成本次实验。

## 三、实验要求

- Login/Registration System
  - 本次实验要求完成完整的登录/注册功能
- 基本需求
  - 三个UI Pages
    - L/R Page（实验五已进行）
      - 添加一个“角色”选项
        - 用户
        - 管理员
      - 输对用户名和密码后
        - 用户进入Home Page
        - 管理员进入Management Page
      - 如果登录信息不存在，提示进行“注册”
      - 连续3次输错密码后，关闭整个App
    - Registration Page
      - 引导用户输入注册信息
        - 用户名、性别、邮箱、密码、角色为必选项，其他自行设计
        - 需对用户输入内容进行形式判断，如数据类型等
          - 形式判断错误的，需要引导用户重新输入
      - 点击确认按钮后信息存入SQLite数据库
        - “用户”采用HarmonyOS的built-in加密存储功能
        - “管理员”采用自行加密模块处理后存储
    - Management Page
      - 此为管理员登录成功后可进入的页面
      - 具备“查询”按钮，点击返回整个注册数据库的信息
        - 跳转页面后用列表显示出来
          - 需解密后显示明文
  - 完成用例图和详细类图
    - 其他类型的图不要求
  - 完成编码实现
- 技术要求
  - 不能使用回调函数来完成异步编程，全部使用async/await形式
  - 必须有关键节点的日志输出



## 四、实验步骤

### 1. L/R Page

#### 1.1 截图展示

![登陆界面](Screenshot_2025-04-30T195715.png)

#### 1.2 用例图与类图

![类图](image.png)
![用例图](image-1.png)

#### 1.3 代码实现

插入代码的语法示例：
```typescript {.line-numbers}
import router from '@ohos.router';
import common from '@ohos.app.ability.common';
import rdb from '@ohos.data.rdb';
import http from '@ohos.net.http';
import UserAccount from '../common/database/AccountUsers';
import { promptAction } from '@kit.ArkUI';

@Entry
@Component
struct Index {
  @State private username: string = '';
  @State private password: string = '';
  @State private isSecure: boolean = true;
  @State private isLoading: boolean = false;
  @State private rdbStore: rdb.RdbStore | null = null;
  @State private userModel: UserAccount = new UserAccount();
  @State private errorCount: number = 0;
  private context = getContext(this) as common.UIAbilityContext;

  async aboutToAppear() {
    await this.userModel.init();
  }

  async componentDidMount() {
    console.info('[LoginPage] 组件挂载');
    try {
      await this.userModel.init();
      console.info('[LoginPage] 数据库初始化确认完成');
    } catch (error) {
      console.error('[LoginPage] 数据库初始化异常:', error);
      this.showToast('数据库启动失败，请重启应用');
    }
  }

  private showToast(message: string): void {
    promptAction.showToast({
      message: message,
      duration: 2000
    });
  }

  private validateInput(): boolean {
    const isValid = !!this.username.trim() && !!this.password.trim();
    if (!isValid) {
      console.warn('[LoginPage] Validation failed: incomplete information');
      this.showToast('请输入完整信息');
    }
    return isValid;
  }

  private handleLoginError(): void {
    this.errorCount++;

    if (this.errorCount >= 3) {
      console.warn('[LoginPage] 连续3次登录失败，终止应用');
      this.context.terminateSelf();
      return;
    }

    const remaining = 3 - this.errorCount;
    this.showToast(`密码错误，剩余${remaining}次尝试机会`);
    console.warn(`[LoginPage] 登录失败，已尝试次数：${this.errorCount}`);
  }

  async validateUser() {
    if (!this.validateInput()) return false;
    try {
      const user = await this.userModel.findUser(this.username);
      if (!user) {
        this.showToast('用户不存在，请注册');
        return false;
      }
      const isValid = await this.userModel.validateUser(this.username, this.password);
      if (isValid) {
        this.errorCount = 0;
        if (user.account_type === 0) {
          router.pushUrl({ url: 'pages/ManagementPage' });
        } else {
          router.pushUrl({ url: 'pages/HomePage' });
        }
        return true;
      } else {
        this.errorCount++;
        if (this.errorCount >= 3) {
          this.context.terminateSelf();
        }
        this.showToast(`密码错误，剩余${3 - this.errorCount}次尝试`);
        return false;
      }
    } catch (error) {
      console.error('登录异常:', error);
      return false;
    }
  }

  build() {
    Column() {
      // 背景图片
      Image('https://img.freepik.com/free-photo/abstract-grunge-texture-background_53876-127345.jpg')
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover)
        .blur(5)
        .opacity(0.3)
        .position({ x: 0, y: 0 })

      // 内容容器
      Column() {
        // 顶部图标区域
        Column() {
          Image('https://img.tukuppt.com/png_preview/00/06/06/ZnMgajOiqY.jpg!/fw/780')
            .width(120)
            .height(120)
            .margin({ bottom: 20 })
            .borderRadius(60)
            .shadow({ radius: 12, color: Color.Gray, offsetX: 2, offsetY: 4 })

          Text('欢迎登录')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
            .fontColor('#3A3A3A')
            .margin({ bottom: 40 })
        }
        .width('100%')
        .alignItems(HorizontalAlign.Center)

        // 表单区域
        Column() {
          // 用户名输入框
          TextInput({
            text: this.username,
            placeholder: '请输入用户名'
          })
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })
            .onChange((value: string) => {
              this.username = value;
            })

          // 密码输入框
          TextInput({
            text: this.password,
            placeholder: '请输入密码'
          })
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .type(InputType.Password)
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })
            .onChange((value: string) => {
              this.password = value;
            })

          // 辅助功能区
          Row() {
            // 记住密码区域
            Row() {
              Checkbox()
                .select(false)
                .onChange((checked: boolean) => {
                  // 处理记住密码状态
                })

              Text('记住密码')
                .fontSize(14)
                .fontColor('#6B6B6B')
                .margin({ left: 8 })
            }
            .alignItems(VerticalAlign.Center)
          }
          .width('90%')
          .margin({ bottom: 30 })
        }

        // 按钮区域
        Column() {
          // 登录按钮
          Button('立即登录', { type: ButtonType.Capsule })
            .width('90%')
            .height(48)
            .backgroundColor('#7D8A6E')
            .fontColor(Color.White)
            .fontSize(18)
            .fontWeight(FontWeight.Medium)
            .margin({ bottom: 15 })
            .onClick(async () => {
              console.info('[LoginPage] Login button clicked');
              if (!this.validateInput()) return;
              this.isLoading = true;

              try {
                console.info(`[LoginPage] 正在验证用户：${this.username}`);
                const user = await this.userModel.validateUser(this.username, this.password);

                if (user) {
                  console.info('[LoginPage] 登录成功，用户类型:', user.account_type);
                  this.errorCount = 0;

                  user.account_type === 0
                    ? router.pushUrl({ url: 'pages/ManagementPage' })
                    : router.pushUrl({ url: 'pages/HomePage' });
                } else {
                  this.handleLoginError();
                }
              } catch (error) {
                console.error('[LoginPage] 登录过程异常:', error);
                this.handleLoginError();
              } finally {
                this.isLoading = false;
              }
            })

          // 注册按钮
          Button('快速注册', { type: ButtonType.Capsule })
            .width('90%')
            .height(48)
            .backgroundColor('#A5A5A5')
            .fontColor(Color.White)
            .fontSize(18)
            .fontWeight(FontWeight.Medium)
            .onClick(() => {
              router.pushUrl({
                url: 'pages/RegisterPage',
                params: { from: 'login' }
              });
            })
        }
        .width('100%')
        .alignItems(HorizontalAlign.Center)
      }
      .width('100%')
      .height('100%')
      .padding(20)
      .backgroundColor('#F5F0E6')
      .justifyContent(FlexAlign.SpaceBetween)
    }
  }
}
```


### 2. Registration Page

#### 2.1 截图展示

![普通用户注册](Screenshot_2025-04-30T195511.png)
![管理员注册](Screenshot_2025-04-30T195651.png)

#### 2.2 用例图与类图

![类图](image-2.png)
![用例图](image-3.png)

#### 2.3 代码实现

```typescript {.line-numbers}
import router from '@ohos.router';
import UserAccount from '../common/database/AccountUsers';
import { AccountData } from '../common/database/AccountInterface';
import promptAction from '@ohos.promptAction';

@Entry
@Component
struct RegisterPage {
  @State username: string = '';
  @State age: number = 18;
  @State password: string = '';
  @State confirmPwd: string = '';
  @State accountType: number = 1;
  @State isLoading: boolean = false;
  @State gender: string = '男';
  @State email: string = '';
  private userModel: UserAccount = new UserAccount();

  private showToast(message: string): void {
    promptAction.showToast({
      message: message,
      duration: 2000
    });
  }

  async aboutToAppear() {
    await this.userModel.init();
  }

  build() {
    Column() {
      // 背景图片
      Image('https://img.freepik.com/free-photo/abstract-grunge-texture-background_53876-127345.jpg')
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover)
        .blur(5)
        .opacity(0.3)
        .position({ x: 0, y: 0 })

      // 内容容器
      Column() {
        // 顶部标题区域
        Column() {
          Text('用户注册')
            .fontSize(32)
            .fontWeight(FontWeight.Bold)
            .fontColor('#3A3A3A')
            .margin({ top: 40, bottom: 30 })
        }
        .width('100%')
        .alignItems(HorizontalAlign.Center)

        // 表单区域
        Column() {
          // 用户名输入
          TextInput({ text: this.username, placeholder: '请输入用户名' })
            .onChange(v => this.username = v)
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })

          // 年龄输入
          TextInput({ text: this.age.toString(), placeholder: '请输入年龄' })
            .type(InputType.Number)
            .onChange(v => this.age = parseInt(v) || 0)
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })

          // 性别输入
          TextInput({ text: this.gender, placeholder: '请输入性别（男/女）' })
            .onChange(v => this.gender = v)
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })

          // 邮箱输入
          TextInput({ text: this.email, placeholder: '请输入邮箱' })
            .onChange(v => this.email = v)
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })

          // 密码输入
          TextInput({ text: this.password, placeholder: '请输入密码（至少6位）' })
            .type(InputType.Password)
            .onChange(v => this.password = v)
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })

          // 确认密码输入
          TextInput({ text: this.confirmPwd, placeholder: '请再次输入密码' })
            .type(InputType.Password)
            .onChange(v => this.confirmPwd = v)
            .width('90%')
            .height(50)
            .padding(12)
            .fontSize(16)
            .fontColor('#3A3A3A')
            .placeholderColor('#6B6B6B')
            .borderColor('#E0E0E0')
            .borderWidth(1)
            .borderRadius(8)
            .backgroundColor('#FFFFFF')
            .shadow({ radius: 4, color: Color.Gray, offsetX: 1, offsetY: 2 })
            .margin({ bottom: 20 })

          // 账户类型选择
          Column() {
            Text('账户类型')
              .fontSize(16)
              .fontColor('#6B6B6B')
              .margin({ bottom: 10 })

            Row() {
              Toggle({ type: ToggleType.Checkbox, isOn: this.accountType === 0 })
                .size({ width: 24, height: 24 })
                .onChange((isOn: boolean) => {
                  if (isOn) this.accountType = 0
                })
              Text('管理员').margin({ left: 8 })
                .fontSize(16)
                .fontColor('#3A3A3A')

              Toggle({ type: ToggleType.Checkbox, isOn: this.accountType === 1 })
                .size({ width: 24, height: 24 })
                .margin({ left: 30 })
                .onChange((isOn: boolean) => {
                  if (isOn) this.accountType = 1
                })
              Text('普通用户').margin({ left: 8 })
                .fontSize(16)
                .fontColor('#3A3A3A')
            }
            .width('90%')
            .margin({ bottom: 15 })
          }
          .width('100%')
          .alignItems(HorizontalAlign.Start)
          .padding({ left: '5%' })

          // 注册按钮
          Button('立即注册', { type: ButtonType.Capsule })
            .width('90%')
            .height(48)
            .backgroundColor('#7D8A6E')
            .fontColor(Color.White)
            .fontSize(18)
            .fontWeight(FontWeight.Medium)
            .margin({ bottom: 15 })
            .onClick(async () => {
              console.info('[RegisterPage] Registration started for:', this.username);
              if (!this.validateInput()) return;

              this.isLoading = true;
              try {
                console.info(`[RegisterPage] Checking username availability: ${this.username}`);
                if (await this.userModel.findUser(this.username)) {
                  this.showToast('用户名已存在');
                  return;
                }

                const newUser: AccountData = {
                  username: this.username,
                  age: this.age,
                  password: this.password,
                  account_type: this.accountType,
                  gender: this.gender,
                  email: this.email
                };

                const success = await this.userModel.createUser(newUser);
                if (success) {
                  this.showToast('注册成功');
                  router.back();
                } else {
                  this.showToast('注册失败');
                }
              } catch (error) {
                console.error('[RegisterPage] Registration error:', error);
                this.showToast(`注册失败：${error instanceof Error ? error.message : '未知错误'}`);
              } finally {
                this.isLoading = false;
              }
            })
        }
        .width('100%')
        .alignItems(HorizontalAlign.Center)
        .padding({ bottom: 40 })
      }
      .width('100%')
      .height('100%')
      .backgroundColor('#F5F0E6')
    }
  }

  private validateInput(): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email)) {
      this.showToast('邮箱格式错误');
      return false;
    }
    if (!/^[\w-]{4,16}$/.test(this.username)) {
      this.showToast('用户名格式不正确');
      console.warn(`[RegisterPage] Invalid username format: ${this.username}`);
      return false;
    }
    if (this.password.length < 6) {
      this.showToast('密码至少6位');
      console.warn(`[RegisterPage] password  : ${this.password}`);
      return false;
    }
    if (this.password !== this.confirmPwd) {
      this.showToast('两次密码不一致');
      console.warn(`[RegisterPage] confirmPwd  : ${this.password}`);
      return false;
    }
    return true;
  }
}
```

### 3. Management Page

#### 3.1 截图展示

![管理员进入管理页面](Screenshot_2025-04-30T195727.png)

#### 3.2 用例图与类图

![类图](image-4.png)
![用例图](image-5.png)

#### 3.3 代码实现

```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import router from '@ohos.router';
import CommonConstants from '../common/constants/CommonConstants';
import UserAccount from '../common/database/AccountUsers';
import { AccountData } from '../common/database/AccountInterface';
import RdbFunctions from '../common/database/RdbFunctions';
import { promptAction } from '@kit.ArkUI';

@Entry
@Component
struct ManagementPage {
  @State users: AccountData[] = [];
  @State private isLoading: boolean = false;
  private userModel: UserAccount = new UserAccount();

  // 角色类型映射表
  private readonly roleMap: Record<number, string> = {
    0: '管理员',
    1: '普通用户'
  };

  async aboutToAppear() {
    await this.userModel.init();
    await this.loadAllUsers();
  }

  // 加载所有用户数据
  private async loadAllUsers(): Promise<void> {
    try {
      console.info('[Management] 开始加载用户数据');
      const predicates = new relationalStore.RdbPredicates(
        CommonConstants.ACCOUNT_TABLE.tableName
      );

      // 添加调试日志
      console.debug('[Management] 查询谓词:', JSON.stringify(predicates));

      const resultSet = await this.userModel.rdbFunctions.query(predicates);
      console.info(`[Management] 查询完成，结果存在: ${!!resultSet}, 行数: ${resultSet?.rowCount}`);

      if (!resultSet || resultSet.rowCount === 0) {
        console.warn('[Management] 无有效数据');
        this.users = [];
        return;
      }

      const tempUsers: AccountData[] = [];
      while (resultSet.goToNextRow()) {
        try {
          console.debug('[Management] 当前行数据:', resultSet.getRow());
          const user = this.parseUser(resultSet);
          console.debug('[Management] 解析用户:', JSON.stringify(user));
          tempUsers.push(user);
        } catch (e) {
          console.error('[Management] 行数据解析失败:', e);
        }
      }

      console.info('[Management] 有效用户数:', tempUsers.length);
      this.users = [...tempUsers]; // 使用展开运算符触发刷新
    } catch (error) {
      console.error('[Management] 加载失败:', error);
      this.showToast('数据加载失败');
    }
  }

  // 解析结果集并解密密码
  private parseUser(rs: relationalStore.ResultSet): AccountData {
    const getColumnIndex = (name: string): number => {
      const index = rs.getColumnIndex(name);
      if (index === -1) throw new Error(`列[${name}]不存在`);
      return index;
    };

    return {
      id: rs.getDouble(getColumnIndex('id')),
      username: rs.getString(getColumnIndex('username')),
      age: rs.getDouble(getColumnIndex('age')),
      password: this.userModel.decryptPassword(
        rs.getString(getColumnIndex('password')),
        rs.getDouble(getColumnIndex('account_type'))
      ),
      account_type: rs.getDouble(getColumnIndex('account_type')),
      gender: rs.getString(getColumnIndex('gender')),
      email: rs.getString(getColumnIndex('email'))
    };
  }

  // 显示操作反馈
  private showToast(message: string): void {
    promptAction.showToast({
      message: message,
      duration: 2000
    });
  }

  build() {
    Column() {
      // 背景图片
      Image('https://img.freepik.com/free-photo/abstract-grunge-texture-background_53876-127345.jpg')
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover)
        .blur(5)
        .opacity(0.3)
        .position({ x: 0, y: 0 })

      // 内容容器
      Column() {
        // 头部操作区
        Row() {
          Button('刷新记录')
            .width(120)
            .height(40)
            .backgroundColor('#7D8A6E')
            .fontColor(Color.White)
            .fontSize(16)
            .borderRadius(8)
            .onClick(async () => {
              console.info('[Management] 手动刷新记录');
              await this.loadAllUsers();
            })
            .margin(10)

          Button('退出登录')
            .width(120)
            .height(40)
            .backgroundColor('#A5A5A5')
            .fontColor(Color.White)
            .fontSize(16)
            .borderRadius(8)
            .onClick(() => router.back())
            .margin(10)
        }
        .justifyContent(FlexAlign.SpaceBetween)
        .width('100%')

        // 数据加载指示器
        if (this.isLoading) {
          LoadingProgress()
            .color('#7D8A6E')
            .margin(20)
        }

        // 数据列表
        List({ space: 10 }) {
          if (this.users.length === 0) {
            ListItem() {
              Text('暂无用户数据')
                .fontSize(18)
                .fontColor('#6B6B6B')
                .margin(20)
            }
          }

          ForEach(this.users, (user: AccountData, index) => {
            ListItem() {
              Column() {
                // 用户名
                Row() {
                  Text('用户名:')
                    .fontColor('#6B6B6B')
                    .width(80)
                  Text(user.username)
                    .fontColor('#3A3A3A')
                    .fontWeight(FontWeight.Medium)
                }
                .margin({ bottom: 8 })

                // 用户年龄
                Row() {
                  Text('年龄:')
                    .fontColor('#6B6B6B')
                    .width(80)
                  Text(user.age.toString())
                    .fontColor('#3A3A3A')
                }
                .margin({ bottom: 8 })

                // 角色类型
                Row() {
                  Text('角色类型:')
                    .fontColor('#6B6B6B')
                    .width(80)
                  Text(this.roleMap[user.account_type])
                    .fontColor(user.account_type === 0 ? '#A5A5A5' : '#7D8A6E')
                    .fontWeight(FontWeight.Medium)
                }
                .margin({ bottom: 8 })

                // 性别
                Row() {
                  Text('性别:')
                    .fontColor('#6B6B6B')
                    .width(80)
                  Text(user.gender)
                    .fontColor('#3A3A3A')
                }
                .margin({ bottom: 8 })

                // 邮箱
                Row() {
                  Text('邮箱:')
                    .fontColor('#6B6B6B')
                    .width(80)
                  Text(user.email)
                    .fontColor('#3A3A3A')
                }
                .margin({ bottom: 8 })

                // 明文密码 - 隐藏部分字符
                Row() {
                  Text('密码:')
                    .fontColor('#6B6B6B')
                    .width(80)
                  Text(user.password.replace(/(?<=.).(?=..)/g, '*'))
                    .fontColor('#3A3A3A')
                    .fontSize(14)
                }
              }
              .padding(15)
              .backgroundColor('#FFFFFF')
              .borderRadius(10)
              .shadow({ radius: 3, color: Color.Gray, offsetX: 1, offsetY: 2 })
              .alignItems(HorizontalAlign.Start)
            }
            .margin({ left: 15, right: 15, bottom: 10 })
          })
        }
        .width('100%')
        .height('80%')
        .layoutWeight(1)
        .backgroundColor('#FFFFFF')
      }
      .padding(10)
      .backgroundColor('#F5F0E6')
      .height('100%')
    }
  }
}
```
### 4.Home Page
#### 4.1截图演示
![普通用户登录进入主页面](Screenshot_2025-04-30T195544-1.png)
#### 4.2代码实现
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';
import {http} from '@kit.NetworkKit';
import { image } from '@kit.ImageKit';
import { BusinessError } from '@kit.BasicServicesKit';
import { Size } from '@ohos/hypium';
@Entry
@Component
struct Homepage{
  @State message: string = '禁止 Hello World';
  @State imagePixel: PixelMap | undefined = undefined;
  //请求图像
  private imageHttpReq(){
    let httpRequest = http.createHttp();
    let url: string = "https://c-ssl.duitang.com/uploads/item/202004/09/20200409213726_qshls.jpg";
    let promise = httpRequest.request(
      url,
      {
        method:http.RequestMethod.GET,
        connectTimeout:60000,
        readTimeout:60000,
        header:{
          'Content-Type':'application/json'
        }
      });

    //处理响应结果
    promise.then((data) => {
      if(data.responseCode === http.ResponseCode.OK){
        console.info('Result:' + data.result);
        console.info('code:' + data.responseCode);

        let imageData:ArrayBuffer = data.result as ArrayBuffer;
        let imageSource:image.ImageSource = image.createImageSource(imageData)
        class sizeTmp{
          height: number = 100
          width: number = 100
        }
        let options:Record<string , number | boolean | sizeTmp> = {
          'alphaType':0,
          'editable':false,
          'pixelFormat':3,
          'scaleMode':1,
          'size': {height: 100, width: 100}
        };
        imageSource.createPixelMap(options).then((pixelMap: PixelMap) => {
          this.imagePixel = pixelMap});
      }
    }).catch((err : BusinessError) => {
      console .info('error:' + JSON.stringify(err));
    });
  };
  // JSON请求方法
  private jsonHttpReq() {
    let httpRequest = http.createHttp()
    let url = "https://github.com/kaibin-zhang/MobileAppDevelopment/blob/main/example.json"
    let promise = httpRequest.request(
      //请求url
      url,
      {
        //请求方法
        method:http.RequestMethod.GET,
        //可选，默认为60s
        connectTimeout:60000,
        readTimeout:60000,
        header:{
          'Content-Type':'application/json',
          'Accept': 'application/json' // 明确声明接受JSON
        }
      });
    promise.then((data) =>{
      if (data.responseCode === http.ResponseCode.OK) {
        console.info('Result:' + data.result);
        console.info('code:' + data.responseCode);
      }
    }).catch((err:BusinessError) => {
      console.info('error:' + JSON.stringify(err));
    });
  }


  build() {
    Column({ space: 20 }) {
      // 标题区域
      Text('欢迎使用本应用')
        .fontSize(28)
        .fontWeight(FontWeight.Bold)
        .fontColor('#333')
        .margin({ top: 40, bottom: 30 })

      // 功能按钮区域
      Column({ space: 15 }) {
        Button('请求图像')
          .width('80%')
          .height(50)
          .backgroundColor('#4A90E2')
          .fontColor(Color.White)
          .fontSize(18)
          .borderRadius(8)
          .onClick(() => this.imageHttpReq())

        if (this.imagePixel) {
          Image(this.imagePixel)
            .width(200)
            .height(200)
            .borderRadius(8)
            .margin({ top: 10 })
        }

        Button('请求JSON数据')
          .width('80%')
          .height(50)
          .backgroundColor('#34C759')
          .fontColor(Color.White)
          .fontSize(18)
          .borderRadius(8)
          .onClick(() => this.jsonHttpReq())

        Button('访问网页')
          .width('80%')
          .height(50)
          .backgroundColor('#FF9500')
          .fontColor(Color.White)
          .fontSize(18)
          .borderRadius(8)
          .onClick(() => router.pushUrl({ url: 'pages/WebPage' }))

        Button('退出登录')
          .width('80%')
          .height(50)
          .backgroundColor('#FF3B30')
          .fontColor(Color.White)
          .fontSize(18)
          .borderRadius(8)
          .onClick(() => router.back())
      }
      .alignItems(HorizontalAlign.Center)
    }
    .width('100%')
    .height('100%')
    .padding(20)
    .backgroundColor('#F5F5F5')
    .justifyContent(FlexAlign.Center)
  }
}

```
### 5.相关代码实现
#### 5.1 CommonConstants.ets
```typescript {.line-numbers}
import{ relationalStore } from '@kit.ArkData'
import {AccountTable } from '../database/AccountInterface'

export default class CommonConstants {
  static readonly STONE_CONFIG: relationalStore.StoreConfig = {
    name: 'user.db',
    securityLevel: relationalStore.SecurityLevel.S1
  }

  static readonly ACCOUNT_TABLE: AccountTable = {
    tableName: 'user_account',
    sqlCreate: `CREATE TABLE IF NOT EXISTS user_account (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    age INTEGER NOT NULL,
    password TEXT NOT NULL,
    account_type INTEGER DEFAULT 1,
    gender TEXT,
    email TEXT
  )`,
    columns: ['id', 'username', 'age', 'password', 'account_type', 'gender', 'email']
  }
}
```
#### 5.2 AccountUsers.ets
```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import CommonConstants from '../constants/CommonConstants';
import RdbFunctions from '../database/RdbFunctions';
import { AccountData } from '../database/AccountInterface';
import util from '@ohos.util';

/**
 * 用户账户管理类，负责用户数据的增删改查操作
 */
export default class UserAccount {
  public rdbFunctions: RdbFunctions;

  constructor() {
    // 初始化数据库操作类
    this.rdbFunctions = new RdbFunctions(
      CommonConstants.ACCOUNT_TABLE.tableName,
      CommonConstants.ACCOUNT_TABLE.sqlCreate,
      CommonConstants.ACCOUNT_TABLE.columns
    );
  }

  /**
   * 初始化数据库连接
   * @returns Promise<void>
   */
  async init(): Promise<void> {
    console.debug('[UserAccount] 正在初始化数据库...');
    try {
      await this.rdbFunctions.initRdbStore();
      console.debug('[UserAccount] 数据库初始化成功');
    } catch (error) {
      console.error('[UserAccount] 数据库初始化失败:', error);
    }
  }

  /**
   * 创建新用户
   * @param user 用户数据对象
   * @returns Promise<boolean> 是否创建成功
   */
  async createUser(user: AccountData): Promise<boolean> {
    console.debug(`[UserAccount] 正在创建用户: ${user.username}`);

    try {
      // 检查用户是否已存在
      const existingUser = await this.findUser(user.username);
      if (existingUser) {
        console.warn(`[UserAccount] 用户 ${user.username} 已存在，创建操作中止`);
        return false;
      }

      // 生成数据桶并插入数据库
      const valueBucket = this.generateBucket(user);
      const success = await this.rdbFunctions.insertData(valueBucket);

      if (success) {
        console.debug(`[UserAccount] 用户 ${user.username} 创建成功`);
      } else {
        console.warn(`[UserAccount] 用户 ${user.username} 创建失败`);
      }

      return success;
    } catch (error) {
      console.error('[UserAccount] 创建用户过程中发生错误:', error);
      return false;
    }
  }

  /**
   * 根据用户名查找用户
   * @param username 用户名
   * @returns Promise<AccountData | null> 用户对象或null
   */
  async findUser(username: string): Promise<AccountData | null> {
    console.debug(`[UserAccount] 正在查找用户: ${username}`);

    try {
      const predicates = new relationalStore.RdbPredicates(
        CommonConstants.ACCOUNT_TABLE.tableName
      );
      predicates.equalTo('username', username);

      const resultSet = await this.rdbFunctions.query(predicates);

      if (!resultSet || resultSet.rowCount === 0) {
        console.debug(`[UserAccount] 未找到用户: ${username}`);
        return null;
      }

      resultSet.goToFirstRow();
      return this.parseResultSet(resultSet);
    } catch (error) {
      console.error(`[UserAccount] 查找用户 ${username} 时发生错误:`, error);
      return null;
    }
  }

  /**
   * 解析结果集为用户对象
   * @param resultSet 数据库查询结果集
   * @returns AccountData 用户对象
   */
  private parseResultSet(resultSet: relationalStore.ResultSet): AccountData {
    const getColumnIndex = (name: string): number => {
      const index = resultSet.getColumnIndex(name);
      if (index === -1) throw new Error(`列 ${name} 不存在`);
      return index;
    };

    return {
      id: resultSet.getDouble(getColumnIndex('id')),
      username: resultSet.getString(getColumnIndex('username')),
      age: resultSet.getDouble(getColumnIndex('age')),
      password: resultSet.getString(getColumnIndex('password')),
      account_type: resultSet.getDouble(getColumnIndex('account_type')),
      gender: resultSet.getString(getColumnIndex('gender')),
      email: resultSet.getString(getColumnIndex('email'))
    };
  }

  /**
   * 生成用于插入数据库的值桶
   * @param user 用户数据对象
   * @returns ValuesBucket 数据库值桶
   */
  private generateBucket(user: AccountData): relationalStore.ValuesBucket {
    return {
      username: user.username,
      age: user.age,
      password: this.hashPassword(user.password, user.account_type),
      account_type: user.account_type,
      gender: user.gender,
      email: user.email
    };
  }

  /**
   * 密码加密方法
   * @param password 明文密码
   * @param accountType 账户类型
   * @returns string 加密后的密码
   */
  private hashPassword(password: string, accountType: number): string {
    const textEncoder = new util.TextEncoder();
    const base64 = new util.Base64Helper();

    // 管理员账户使用Base64编码，普通用户使用简单反转
    if (accountType === 0) {
      return base64.encodeToStringSync(textEncoder.encode(password));
    } else {
      return password.split('').reverse().join('');
    }
  }

  /**
   * 密码解密方法
   * @param encrypted 加密后的密码
   * @param accountType 账户类型
   * @returns string 解密后的密码
   */
  public decryptPassword(encrypted: string, accountType: number): string {
    console.debug(`[解密] 原始密文: ${encrypted}, 类型: ${accountType}`);
    const base64 = new util.Base64Helper();
    const textDecoder = new util.TextDecoder();

    try {
      // 管理员账户使用Base64解码，普通用户使用简单反转
      if (accountType === 0) {
        const decodedBytes = base64.decodeSync(encrypted);
        return textDecoder.decode(decodedBytes);
      } else {
        return encrypted.split('').reverse().join('');
      }
    } catch (e) {
      console.error('[解密失败] 错误信息:', e);
      return encrypted; // 解密失败返回原始密文
    }
  }

  /**
   * 验证用户凭证
   * @param username 用户名
   * @param password 密码
   * @returns Promise<AccountData | null> 用户对象或null
   */
  public async validateUser(username: string, password: string): Promise<AccountData | null> {
    console.debug(`[UserAccount] 正在验证用户凭证: ${username}`);

    try {
      const user = await this.findUser(username);
      if (!user) {
        console.debug(`[UserAccount] 用户 ${username} 不存在`);
        return null;
      }

      // 对输入密码进行相同加密处理后比较
      const inputHash = this.hashPassword(password, user.account_type);
      const isValid = inputHash === user.password;

      if (isValid) {
        console.debug(`[UserAccount] 用户 ${username} 验证成功`);
      } else {
        console.debug(`[UserAccount] 用户 ${username} 密码验证失败`);
      }

      return isValid ? user : null;
    } catch (error) {
      console.error(`[UserAccount] 验证用户 ${username} 过程中发生错误:`, error);
      return null;
    }
  }
}
```
#### 5.3 AccountInterface.ets
```typescript {.line-numbers}
export interface AccountData {
  id?: number;
  username: string;
  age: number;
  password: string;
  account_type: number; 
  gender: string;
  email: string;
}

export interface AccountTable {
  tableName: string;
  sqlCreate: string;
  columns:  string[];
}

export interface UserModel {
  createUser(user: AccountData): Promise<boolean>;
  findUser(username: string): Promise<AccountData | null>;
  validateUser(username: string, password: string): Promise<boolean>;
}

```
#### 5.4 RdbUtil.ets
```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import CommonConstants from "../constants/CommonConstants";

/**
 * 数据库工具类，负责RDB数据库的初始化和操作
 */
export default class RdbUtil {
  public rdbStore: relationalStore.RdbStore | null = null;
  public tableName: string = '';
  public sqlCreateTable: string = '';
  public columns: Array<string> = [];

  /**
   * 构造函数
   * @param tableName 表名
   * @param sqlCreateTable 创建表的SQL语句
   * @param columns 表列名数组
   */
  constructor(tableName: string, sqlCreateTable: string, columns: Array<string>) {
    this.tableName = tableName;
    this.sqlCreateTable = sqlCreateTable;
    this.columns = columns;
  }

  /**
   * 获取RDB存储实例（回调方式）
   * @param callback 获取到存储实例后的回调函数
   */
  getRdbStore(callback: Function = () => {}) {
    // 回调函数校验
    if (!callback || typeof callback === 'undefined' || callback === undefined) {
      console.debug('[RdbUtil] getRdbStore() 回调函数未提供');
      return;
    }

    // 如果存储实例已存在，直接调用回调
    if (this.rdbStore != null) {
      console.debug('[RdbUtil] RDB存储实例已存在');
      callback();
      return;
    }

    // 获取应用上下文
    const context: Context = getContext(this) as Context;

    // 获取RDB存储实例
    relationalStore.getRdbStore(context, CommonConstants.STONE_CONFIG, (err, rdb) => {
      if (err) {
        console.error(`[RdbUtil] 获取RDB存储实例失败，错误: ${err.code}-${err.message}`);
        return;
      }

      this.rdbStore = rdb;
      // 执行建表SQL
      this.rdbStore.executeSql(this.sqlCreateTable);
      console.debug('[RdbUtil] RDB存储实例获取并初始化完成');
    });
  }

  /**
   * 初始化RDB存储（Promise方式）
   * @returns Promise<void>
   */
  async initRdbStore(): Promise<void> {
    // 如果存储实例已存在，直接返回
    if (this.rdbStore) {
      console.debug('[RdbUtil] RDB存储实例已初始化');
      return;
    }

    // 获取应用上下文
    const context = getContext(this) as Context;
    console.debug(`[RdbUtil] 初始化RDB存储，上下文信息: ${JSON.stringify(context)}`);

    return new Promise((resolve, reject) => {
      // 获取RDB存储实例
      relationalStore.getRdbStore(context, CommonConstants.STONE_CONFIG, (err, rdb) => {
        if (err) {
          console.error('[RdbUtil] 数据库连接失败:', err);
          reject(new Error(`数据库初始化失败: ${err.code}-${err.message}`));
          return;
        }

        try {
          this.rdbStore = rdb;
          console.debug(`[RdbUtil] 执行建表SQL: ${this.sqlCreateTable}`);
          this.rdbStore.executeSql(this.sqlCreateTable); // 新建表

          console.debug('[RdbUtil] 数据库初始化成功');
          resolve();
        } catch (executeError) {
          console.error('[RdbUtil] SQL执行异常:', executeError);
          reject(new Error(`SQL错误: ${executeError.message}`));
        }
      });
    });
  }
}
```
#### 5.5 RdbFunctions.ets
```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import RdbUtil from './RdbUtil'


/**
 * 数据库操作类，继承自RdbUtil，提供基本的CRUD操作
 */
export default class RdbFunctions extends RdbUtil {
  /**
   * 构造函数
   * @param tableName 表名
   * @param sqlCreate 创建表的SQL语句
   * @param columns 表列名数组
   */
  constructor(
    tableName: string,
    sqlCreate: string,
    columns: string[]
  ) {
    super(tableName, sqlCreate, columns);
  }

  /**
   * 插入数据到指定表
   * @param data 要插入的数据值桶
   * @returns Promise<boolean> 是否插入成功
   */
  async insertData(data: relationalStore.ValuesBucket): Promise<boolean> {
    console.debug(`[RdbFunctions] 正在向表 ${this.tableName} 插入数据`);

    return new Promise((resolve, reject) => {
      if (!this.rdbStore) {
        console.error('[RdbFunctions] 数据库存储实例未初始化');
        resolve(false);
        return;
      }

      this.rdbStore.insert(this.tableName, data, (err, ret) => {
        if (err) {
          console.error(`[RdbFunctions] 插入失败: ${err.code}-${err.message}`);
          resolve(false);
          return;
        }
        console.debug(`[RdbFunctions] 插入成功，行ID: ${ret}`);
        resolve(true);
      });
    });
  }

  /**
   * 根据条件删除数据
   * @param predicates 查询条件
   * @returns Promise<boolean> 是否删除成功（至少删除一行）
   */
  async deleteData(predicates: relationalStore.RdbPredicates): Promise<boolean> {
    return new Promise((resolve, reject) => {
      if (!this.rdbStore) {
        console.error('[RdbFunctions] 数据库存储实例未初始化');
        resolve(false);
        return;
      }

      this.rdbStore.delete(predicates, (err, ret) => {
        if (err) {
          console.error(`[RdbFunctions] 删除失败: ${err.code}-${err.message}`);
          resolve(false);
          return;
        }
        console.debug(`[RdbFunctions] 删除了 ${ret} 行数据`);
        resolve(ret > 0);
      });
    });
  }

  /**
   * 根据条件更新数据
   * @param predicates 查询条件
   * @param data 要更新的数据值桶
   * @returns Promise<boolean> 是否更新成功（至少更新一行）
   */
  async updateData(
    predicates: relationalStore.RdbPredicates,
    data: relationalStore.ValuesBucket
  ): Promise<boolean> {
    console.debug(`[RdbFunctions] 正在更新表 ${this.tableName}`);

    return new Promise((resolve, reject) => {
      if (!this.rdbStore) {
        console.error('[RdbFunctions] 数据库存储实例未初始化');
        resolve(false);
        return;
      }

      this.rdbStore.update(data, predicates, (err, ret) => {
        if (err) {
          console.error(`[RdbFunctions] 更新失败: ${err.code}-${err.message}`);
          resolve(false);
          return;
        }
        console.debug(`[RdbFunctions] 更新了 ${ret} 行数据`);
        resolve(ret > 0);
      });
    });
  }

  /**
   * 根据条件查询数据
   * @param predicates 查询条件
   * @returns Promise<relationalStore.ResultSet | null> 查询结果集或null
   */
  async query(predicates: relationalStore.RdbPredicates): Promise<relationalStore.ResultSet | null> {
    return new Promise((resolve) => {
      if (!this.rdbStore) {
        console.error('[RdbFunctions] 数据库存储实例未初始化');
        resolve(null);
        return;
      }

      this.rdbStore.query(predicates, (err, result) => {
        if (err) {
          console.error(`[RdbFunctions] 查询出错: ${err.code}-${err.message}`);
          resolve(null);
          return;
        }
        resolve(result);
      });
    });
  }
}
```