# 实验三报告

> 学号：<3225706014>
> 
> 姓名：<林晨璇>
> 
> 指导老师：<张凯斌老师>
> 
> 实验日期：<2025-03-24>

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；
  - 注意：UML图只是OOAD中的一部分（代码相关的部分），并不是OOAD的全部。例如：
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习；

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；

## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图

![alt text](用例图.png)

#### 1.2 用例规约

#### 1.21 添加学生成绩

| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 添加学生成绩 | 
| 执行者 | 教师 | 
| 前置条件 | 1. 用户已登录系统<br>2. 数据库连接正常 | 
| 触发事件 | 教师选择"添加成绩"功能并填写表单 | 
| 主成功场景 | 1. 系统验证输入字段完整性<br>2. 验证分数为有效数字(0-100)<br>3. 验证日期格式(YYYY-MM-DD)<br>4. 将成绩记录插入数据库<br>5. 返回操作成功提示 | 
| 扩展场景 | 1. 输入验证失败：高亮错误字段并提示具体规则<br>2. 学号重复：提示"该学号记录已存在"<br>3. 数据库错误：记录日志并提示稍后重试 | 
| 最小保证 | 1. 错误操作记录日志<br>2. 事务回滚保证数据一致性 | 
| 后置条件 | 数据库中存在新增的成绩记录 | 
| 优先级 | 高 | 
| 频度 | 每周约50次 | 
| 输入 | 学号(文本)、姓名(文本)、科目(文本)、分数(数字)、考试日期(文本)、班级(文本) | 
| 输出 | 操作状态(成功/失败)、新增记录ID | 
| 异常 | 1. 必填字段为空<br>2. 分数超出范围<br>3. 日期格式错误<br>4. 数据库连接超时<br>5. 主键冲突 | 
| 附加信息 | 分数支持1位小数，日期使用ISO8601格式 |

#### 1.22 按科目查询成绩

| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 按科目查询成绩 | 
| 执行者 | 教师/管理员 | 
| 前置条件 | 1. 用户已登录系统<br>2. 数据库中存在至少1条记录 | 
| 触发事件 | 用户输入科目名称并点击查询按钮 | 
| 主成功场景 | 1. 系统验证科目名称不为空<br>2. 执行数据库查询<br>3. 格式化显示查询结果（按分数降序排列）<br>4. 显示统计信息（平均分/最高分/最低分） | 
| 扩展场景 | 1. 无查询结果：显示"未找到相关记录"<br>2. 模糊查询：显示名称包含关键词的所有科目成绩 | 
| 最小保证 | 记录查询操作日志 | 
| 后置条件 | 无数据变更 | 
| 优先级 | 中 | 
| 频度 | 每周约30次 | 
| 输入 | 科目名称(文本) | 
| 输出 | 成绩列表（包含：学号、姓名、分数、考试日期）、统计指标 | 
| 异常 | 1. 科目名称为空<br>2. 查询超时(>5秒)<br>3. 结果集过大(>1000条) | 
| 附加信息 | 支持分页显示，每页20条记录 |

#### 1.23 删除学生成绩

| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 删除学生成绩 | 
| 执行者 | 管理员 | 
| 前置条件 | 1. 管理员权限已验证<br>2. 目标记录存在 | 
| 触发事件 | 管理员输入学号并确认删除 | 
| 主成功场景 | 1. 系统验证学号有效性<br>2. 弹出二次确认对话框<br>3. 执行数据库删除操作<br>4. 返回删除记录数 | 
| 扩展场景 | 1. 记录不存在：提示"未找到对应学号"<br>2. 级联删除：同时删除关联的补考记录 | 
| 最小保证 | 1. 记录删除操作日志<br>2. 数据库备份机制 | 
| 后置条件 | 数据库中目标记录被标记删除 | 
| 优先级 | 高 | 
| 频度 | 每月约5次 | 
| 输入 | 学号(文本) | 
| 输出 | 删除记录数、操作状态 | 
| 异常 | 1. 学号格式错误<br>2. 外键约束冲突<br>3. 权限不足 | 
| 附加信息 | 采用逻辑删除而非物理删除 |

#### 1.24 更新学生成绩

| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 更新学生成绩 | 
| 执行者 | 教师 | 
| 前置条件 | 1. 目标记录存在<br>2. 用户有编辑权限 | 
| 触发事件 | 教师修改成绩字段并提交 | 
| 主成功场景 | 1. 系统加载原始数据<br>2. 验证修改后的字段有效性<br>3. 执行数据库更新<br>4. 显示修改后的完整记录 | 
| 扩展场景 | 1. 并发修改：提示"该记录已被其他用户修改"<br>2. 历史版本：可查看修改前后的差异对比 | 
| 最小保证 | 记录修改前后的数据快照 | 
| 后置条件 | 数据库中存在更新后的记录 | 
| 优先级 | 高 | 
| 频度 | 每周约20次 | 
| 输入 | 学号(文本)、待修改字段键值对 | 
| 输出 | 受影响记录数、更新后的完整记录 | 
| 异常 | 1. 字段校验失败<br>2. 乐观锁冲突<br>3. 记录不存在 | 
| 附加信息 | 每次更新自动记录操作人和时间戳 | 

### 2. 总体设计

#### 2.1 类图（静态视图）

![alt text](类图.png)

#### 2.2 活动图（动态视图）

![alt text](活动图.png)

### 3. 详细设计

#### 3.1 详细类图

![alt text](详细类图.png)

#### 3.2 包图

![alt text](包图.png)

# 实验四
### 4. 编码

#### 4.1 代码实现

##### RdbUtil.ts页面：
```typescript {.line-numbers}
import relationalStore from '@ohos.data.relationalStore';
import common from '@ohos.app.ability.common';

export class RdbUtil {
  private rdbStore: relationalStore.RdbStore | null = null;
  private context: common.Context | null = null;

  // 设置全局上下文
  setGlobalContext(context: common.Context) {
    this.context = context;
  }

  // 初始化数据库
  initDatabase(config: relationalStore.StoreConfig, callback: (err: Error) => void) {
    if (!this.context) {
      callback(new Error('Context not set'));
      return;
    }

    relationalStore.getRdbStore(this.context, config, (err, store) => {
      if (err) {
        callback(err);
        return;
      }
      this.rdbStore = store;
      callback(null);
    });
  }

  // 创建RdbPredicates对象
  createPredicates(table: string): relationalStore.RdbPredicates {
    return new relationalStore.RdbPredicates(table);
  }

  // 创建ValuesBucket对象
  createValuesBucket(): relationalStore.ValuesBucket {
    return {};
  }

  // 执行SQL语句
  executeSql(sql: string, args: Array<relationalStore.ValueType> = [], callback: (err: Error) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'));
      return;
    }
    this.rdbStore.executeSql(sql, args, callback);
  }

  // 查询数据
  query(predicates: relationalStore.RdbPredicates,
    columns?: Array<string>,
    callback?: (err: Error, resultSet: relationalStore.ResultSet) => void) {
    if (!this.rdbStore) {
      callback?.(new Error('RdbStore is not initialized'), null);
      return;
    }
    if (callback) {
      this.rdbStore.query(predicates, columns, callback);
    }
  }

  // 插入数据
  insert(table: string, values: relationalStore.ValuesBucket,
    callback: (err: Error, rowId: number) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'), -1);
      return;
    }
    this.rdbStore.insert(table, values, callback);
  }

  // 更新数据
  update(values: relationalStore.ValuesBucket,
    predicates: relationalStore.RdbPredicates,
    callback: (err: Error, rowsAffected: number) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'), 0);
      return;
    }
    this.rdbStore.update(values, predicates, callback);
  }

  // 删除数据
  delete(predicates: relationalStore.RdbPredicates,
    callback: (err: Error, rowsAffected: number) => void) {
    if (!this.rdbStore) {
      callback(new Error('RdbStore is not initialized'), 0);
      return;
    }
    this.rdbStore.delete(predicates, callback);
  }
}
```
##### ScoreData.ts页面：
```typescript {.line-numbers}
import relationalStore from '@ohos.data.relationalStore';

export class ScoreData {
  // 数据库配置
  static STORE_CONFIG: relationalStore.StoreConfig = {
    name: 'ScoreData.db',
    securityLevel: relationalStore.SecurityLevel.S1,
    encrypt: false
  };

  // 表名
  static TABLE_NAME: string = 'score';

  // 创建表的SQL语句
  static SQL_CREATE_TABLE: string = `
    CREATE TABLE IF NOT EXISTS ${ScoreData.TABLE_NAME} (
      student_id TEXT PRIMARY KEY,
      student_name TEXT NOT NULL,
      subject TEXT NOT NULL,
      score REAL NOT NULL,
      exam_date TEXT NOT NULL,
      class TEXT NOT NULL
    )`;
}
```
##### ScoreTable.ts页面：
```typescript {.line-numbers}
import { ScoreData } from './ScoreData';
import { RdbUtil } from '../common/RdbUtil';

export class ScoreTable {
  private rdbUtil: RdbUtil;

  constructor(rdbUtil: RdbUtil) {
    this.rdbUtil = rdbUtil;
  }

  // 初始化数据库
  initDatabase(callback: (err: Error) => void) {
    this.rdbUtil.initDatabase(ScoreData.STORE_CONFIG, (err) => {
      if (err) {
        callback(err);
        return;
      }
      // 创建表
      this.rdbUtil.executeSql(ScoreData.SQL_CREATE_TABLE, [], callback);
    });
  }

  // 添加学生成绩
  addScore(studentId: string, studentName: string, subject: string, score: number,
    examDate: string, className: string, callback: (err: Error, rowId: number) => void) {
    const values = this.rdbUtil.createValuesBucket();
    values.student_id = studentId;
    values.student_name = studentName;
    values.subject = subject;
    values.score = score;
    values.exam_date = examDate;
    values.class = className;

    this.rdbUtil.insert(ScoreData.TABLE_NAME, values, callback);
  }

  // 删除学生成绩
  deleteScore(studentId: string, callback: (err: Error, rowsAffected: number) => void) {
    const predicates = this.rdbUtil.createPredicates(ScoreData.TABLE_NAME);
    predicates.equalTo('student_id', studentId);
    this.rdbUtil.delete(predicates, callback);
  }

  // 更新学生成绩
  updateScore(studentId: string, studentName: string, subject: string, score: number,
    examDate: string, className: string, callback: (err: Error, rowsAffected: number) => void) {
    const predicates = this.rdbUtil.createPredicates(ScoreData.TABLE_NAME);
    predicates.equalTo('student_id', studentId);

    const values = this.rdbUtil.createValuesBucket();
    values.student_name = studentName;
    values.subject = subject;
    values.score = score;
    values.exam_date = examDate;
    values.class = className;

    this.rdbUtil.update(values, predicates, callback);
  }

  // 查询所有学生成绩
  queryAllScores(callback: (err: Error, result: Array<ScoreInfo>) => void) {
    const predicates = this.rdbUtil.createPredicates(ScoreData.TABLE_NAME);

    this.rdbUtil.query(predicates, null, (err, resultSet) => {
      if (err) {
        callback(err, null);
        return;
      }

      const scores: Array<ScoreInfo> = [];
      while (resultSet.goToNextRow()) {
        scores.push({
          studentId: resultSet.getString(resultSet.getColumnIndex('student_id')),
          studentName: resultSet.getString(resultSet.getColumnIndex('student_name')),
          subject: resultSet.getString(resultSet.getColumnIndex('subject')),
          score: resultSet.getDouble(resultSet.getColumnIndex('score')),
          examDate: resultSet.getString(resultSet.getColumnIndex('exam_date')),
          className: resultSet.getString(resultSet.getColumnIndex('class'))
        });
      }
      resultSet.close();
      callback(null, scores);
    });
  }

  // 根据学号查询学生成绩
  queryScoreById(studentId: string, callback: (err: Error, score: ScoreInfo) => void) {
    const predicates = this.rdbUtil.createPredicates(ScoreData.TABLE_NAME);
    predicates.equalTo('student_id', studentId);

    this.rdbUtil.query(predicates, null, (err, resultSet) => {
      if (err) {
        callback(err, null);
        return;
      }

      if (resultSet.goToFirstRow()) {
        const score = {
          studentId: resultSet.getString(resultSet.getColumnIndex('student_id')),
          studentName: resultSet.getString(resultSet.getColumnIndex('student_name')),
          subject: resultSet.getString(resultSet.getColumnIndex('subject')),
          score: resultSet.getDouble(resultSet.getColumnIndex('score')),
          examDate: resultSet.getString(resultSet.getColumnIndex('exam_date')),
          className: resultSet.getString(resultSet.getColumnIndex('class'))
        };
        resultSet.close();
        callback(null, score);
      } else {
        resultSet.close();
        callback(new Error('Score not found'), null);
      }
    });
  }

  // 按科目查询成绩
  queryScoresBySubject(subject: string, callback: (err: Error, result: Array<ScoreInfo>) => void) {
    const predicates = this.rdbUtil.createPredicates(ScoreData.TABLE_NAME);
    predicates.equalTo('subject', subject);

    this.rdbUtil.query(predicates, null, (err, resultSet) => {
      if (err) {
        callback(err, null);
        return;
      }

      const scores: Array<ScoreInfo> = [];
      while (resultSet.goToNextRow()) {
        scores.push({
          studentId: resultSet.getString(resultSet.getColumnIndex('student_id')),
          studentName: resultSet.getString(resultSet.getColumnIndex('student_name')),
          subject: resultSet.getString(resultSet.getColumnIndex('subject')),
          score: resultSet.getDouble(resultSet.getColumnIndex('score')),
          examDate: resultSet.getString(resultSet.getColumnIndex('exam_date')),
          className: resultSet.getString(resultSet.getColumnIndex('class'))
        });
      }
      resultSet.close();
      callback(null, scores);
    });
  }
}

interface ScoreInfo {
  studentId: string;
  studentName: string;
  subject: string;
  score: number;
  examDate: string;
  className: string;
}
```
##### Index.ts页面：
```typescript {.line-numbers}
import { ScoreData } from '../database/ScoreData';
import { ScoreTable } from '../database/ScoreTable';
import { RdbUtil } from '../common/RdbUtil';

@Entry
@Component
struct Index {
  @State message: string = '学生成绩管理系统';
  @State studentId: string = '';
  @State studentName: string = '';
  @State subject: string = '';
  @State score: string = '';
  @State examDate: string = '';
  @State className: string = '';
  @State queryResult: string = '';

  private rdbUtil: RdbUtil = new RdbUtil();
  private scoreTable: ScoreTable = new ScoreTable(this.rdbUtil);

  aboutToAppear() {
    // 设置全局上下文
    this.rdbUtil.setGlobalContext(getContext(this));

    // 初始化数据库
    this.scoreTable.initDatabase((err) => {
      if (err) {
        console.error('Failed to initialize database');
        this.message = '数据库初始化失败';
      } else {
        this.message = '数据库初始化成功';
      }
    });
  }

  build() {
    Column() {
      // 标题
      Text('学生成绩管理系统')
        .fontSize(30)
        .fontWeight(FontWeight.Bold)
        .margin(20)

      Text(this.message)
        .fontSize(20)
        .margin(10)

      // 输入字段
      TextInput({ placeholder: '学号' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.studentId = value;
        })

      TextInput({ placeholder: '学生姓名' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.studentName = value;
        })

      TextInput({ placeholder: '科目' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.subject = value;
        })

      TextInput({ placeholder: '分数' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.score = value;
        })

      TextInput({ placeholder: '考试日期(YYYY-MM-DD)' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.examDate = value;
        })

      TextInput({ placeholder: '班级' })
        .width('90%')
        .height(40)
        .margin(5)
        .onChange((value: string) => {
          this.className = value;
        })

      // 操作按钮
      Row() {
        Button('添加成绩')
          .onClick(() => {
            this.addScore();
          })
          .margin(5)

        Button('删除成绩')
          .onClick(() => {
            this.deleteScore();
          })
          .margin(5)
      }

      Row() {
        Button('更新成绩')
          .onClick(() => {
            this.updateScore();
          })
          .margin(5)

        Button('查询全部')
          .onClick(() => {
            this.queryAllScores();
          })
          .margin(5)
      }

      Row() {
        Button('按科目查询')
          .onClick(() => {
            this.queryScoresBySubject();
          })
          .margin(5)

        Button('清空输入')
          .onClick(() => {
            this.clearInputs();
          })
          .margin(5)
      }

      // 查询结果显示
      Scroll() {
        Text(this.queryResult)
          .fontSize(16)
          .width('90%')
          .margin(10)
      }
      .height(300)
      .width('100%')
      .margin(10)
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Start)
  }

  // 添加成绩
  private addScore() {
    if (!this.validateInput()) {
      return;
    }

    const scoreNum = parseFloat(this.score);
    this.scoreTable.addScore(
      this.studentId,
      this.studentName,
      this.subject,
      scoreNum,
      this.examDate,
      this.className,
      (err, rowId) => {
        if (err) {
          this.message = `添加失败: ${err.message}`;
          return;
        }
        this.message = `添加成功, 行ID: ${rowId}`;
        this.clearInputs();
      }
    );
  }

  // 删除成绩
  private deleteScore() {
    if (!this.studentId) {
      this.message = '请输入学号';
      return;
    }

    this.scoreTable.deleteScore(this.studentId, (err, rowsAffected) => {
      if (err) {
        this.message = `删除失败: ${err.message}`;
        return;
      }
      this.message = `已删除 ${rowsAffected} 条记录`;
      this.clearInputs();
    });
  }

  // 更新成绩
  private updateScore() {
    if (!this.validateInput()) {
      return;
    }

    const scoreNum = parseFloat(this.score);
    this.scoreTable.updateScore(
      this.studentId,
      this.studentName,
      this.subject,
      scoreNum,
      this.examDate,
      this.className,
      (err, rowsAffected) => {
        if (err) {
          this.message = `更新失败: ${err.message}`;
          return;
        }
        this.message = `已更新 ${rowsAffected} 条记录`;
        this.clearInputs();
      }
    );
  }

  // 查询所有成绩
  private queryAllScores() {
    this.scoreTable.queryAllScores((err, scores) => {
      if (err) {
        this.message = `查询失败: ${err.message}`;
        return;
      }

      if (scores.length === 0) {
        this.queryResult = '没有找到任何记录';
        return;
      }

      let result = '学生成绩记录:\n\n';
      scores.forEach(score => {
        result += `学号: ${score.studentId}\n`;
        result += `姓名: ${score.studentName}\n`;
        result += `科目: ${score.subject}\n`;
        result += `分数: ${score.score}\n`;
        result += `考试日期: ${score.examDate}\n`;
        result += `班级: ${score.className}\n\n`;
      });

      this.queryResult = result;
      this.message = `找到 ${scores.length} 条记录`;
    });
  }

  // 按科目查询成绩
  private queryScoresBySubject() {
    if (!this.subject) {
      this.message = '请输入科目名称';
      return;
    }

    this.scoreTable.queryScoresBySubject(this.subject, (err, scores) => {
      if (err) {
        this.message = `查询失败: ${err.message}`;
        return;
      }

      if (scores.length === 0) {
        this.queryResult = `没有找到${this.subject}科目的成绩记录`;
        return;
      }

      let result = `${this.subject}科目成绩:\n\n`;
      scores.forEach(score => {
        result += `学号: ${score.studentId}\n`;
        result += `姓名: ${score.studentName}\n`;
        result += `分数: ${score.score}\n`;
        result += `考试日期: ${score.examDate}\n`;
        result += `班级: ${score.className}\n\n`;
      });

      this.queryResult = result;
      this.message = `找到 ${scores.length} 条${this.subject}科目记录`;
    });
  }

  // 验证输入
  private validateInput(): boolean {
    if (!this.studentId || !this.studentName || !this.subject ||
      !this.score || !this.examDate || !this.className) {
      this.message = '请填写所有字段';
      return false;
    }

    if (isNaN(parseFloat(this.score))) {
      this.message = '分数必须是数字';
      return false;
    }

    // 简单验证日期格式
    if (!/^\d{4}-\d{2}-\d{2}$/.test(this.examDate)) {
      this.message = '日期格式应为YYYY-MM-DD';
      return false;
    }

    return true;
  }

  // 清空输入
  private clearInputs() {
    this.studentId = '';
    this.studentName = '';
    this.subject = '';
    this.score = '';
    this.examDate = '';
    this.className = '';
  }
}
```

#### 4.2 结果验证
![alt text](添加信息并查询.png)
![alt text](更新成绩并按科目查询.png)
